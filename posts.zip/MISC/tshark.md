---
title: tshark
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 108
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - MISC
categories:
  - MISC
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

tshark ⽤来提取数据很⽅便

参数

捕获接⼝:

>  -i: -i <interface> 指定捕获接⼝，默认是第⼀个⾮本地循环接⼝;
>
> 
>
>  -f: -f <capture filter> 设置抓包过滤表达式，遵循libpcap过滤语法，这个实在抓包的过程中过滤，如果是分析本地⽂件则⽤不到。
>
> 
>
> -s: -s <snaplen> 设置快照⻓度，⽤来读取完整的数据包，因为⽹络中传输有65535的限制，值0代表快照⻓度65535，默认也是这个值；
>
> 
>
> -p: 以⾮混合模式⼯作，即只关⼼和本机有关的流量。
>
> 
>
> -B: -B <buffer size> 设置缓冲区的⼤⼩，只对windows⽣效，默认是2M;
>
> 
>
> -y: -y<link type> 设置抓包的数据链路层协议，不设置则默认为-L找到的第⼀个协议，局域⽹⼀般是EN10MB等;
>
> 
>
> -D: 打印接⼝的列表并退出;
>
> 
>
> -L 列出本机⽀持的数据链路层协议，供-y参数使⽤。



捕获停⽌选项:

>   -c: -c <packet count> 捕获n个包之后结束，默认捕获⽆限个;
>   -a: -a <autostop cond.> ... duration:NUM，在num秒之后停⽌捕获;
> filesize:NUM，在numKB之后停⽌捕获;
> files:NUM，在捕获num个⽂件之后停⽌捕获;



输⼊⽂件:

> -r: -r <infile> 设置读取本地⽂件

处理选项:

> -2: 执⾏两次分析
>
> 
>
> -R: -R <read filter>,包的读取过滤器，可以在wireshark的filter语法上查看；在wireshark的视图->过滤器视图，在这⼀栏点击表达式，就会列出来对所有协议的⽀持。
>
> 
>
> -Y: -Y <display filter>,使⽤读取过滤器的语法，在单次分析中可以代替-R选项;
>
> 
>
> -n: 禁⽌所有地址名字解析（默认为允许所有）
>
> 
>
> -N: 启⽤某⼀层的地址名字解析。“m”代表MAC层，“n”代表⽹络层，“t”代表传输层，“C”代表当前异步DNS查找。如果-n和-N参数同时存在，-n将被忽略。如果-n和-N参数都不写，则默认打开所有地址名字解析。
>
> 
>
> -d: 将指定的数据按有关协议解包输出,如要将tcp 8888端⼝的流量按http解包，应该写为“-d tcp.port==8888,http”;tshark -d. 可以列出所有⽀持的有效选择器。

输出选项:
> -w: -w <outfile|-> 设置raw数据的输出⽂件。这个参数不设置，tshark将会把解码结果输出到stdout,“-w -”表⽰把raw输出到stdout。如果要把解码结果输出到⽂件，使⽤重定向“>”⽽不要-w参数。
>
> 
>
> -F: -F <output file type>,设置输出的⽂件格式，默认是.pcapng,使⽤tshark -F可列出所有⽀持的输出⽂件类型。
>
> 
>
> -V: 增加细节输出;
>
> 
>
> -O: -O <protocols>,只显⽰此选项指定的协议的详细信息。
>
> 
>
> -P: 即使将解码结果写⼊⽂件中，也打印包的概要信息；
>
> 
>
> -S: -S <separator> ⾏分割符
>
> 
>
> -x: 设置在解码输出结果中，每个packet后⾯以HEX dump的⽅式显⽰具体数据。
>
> 
>
> -T: -T pdml|ps|text|fields|psml,设置解码结果输出的格式，包括text,ps,psml和pdml，默认为text
>
> 
>
> -e: 如果-T fields选项指定，-e⽤来指定输出哪些字段;
>
> 
>
> -E: -E <fieldsoption>=<value>如果-T fields选项指定，使⽤-E来设置⼀些属性，⽐如
>     tshark 3
>     header=y|n
>     separator=/t|/s|<char>
>     occurrence=f|l|a
>     aggregator=,|/s|<char>
> -t: -t a|ad|d|dd|e|r|u|ud 设置解码结果的时间格式。“ad”表⽰带⽇期的绝对时间，“a”表⽰不带⽇期的绝对时间，“r”表⽰从第⼀个包到现在的相对时间，“d”表⽰两个相邻包之间的增量时间（delta）。
>
> 
>
> -u: s|hms 格式化输出秒；
>
> 
>
> -l: 在输出每个包之后flush标准输出
>
> 
>
> -q: 结合-z选项进⾏使⽤，来进⾏统计分析；
>
> 
>
> -X: <key>:<value> 扩展项，lua_script、read_format，具体参⻅ man pages；
>
> 
>
> -z：统计选项，具体的参考⽂档;tshark -z help,可以列出，-z选项⽀持的统计⽅式。
>
> 
>
> 其他选项:
> -h: 显⽰命令⾏帮助；
> -v: 显⽰tshark 的版本信息



例⼦：⽐如我想提取出这个流量包的modbus协议中的所有data数据

![image-20230602144152071](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306021441445.webp)

我们输⼊这个命令

```shell
tshark -r ./bus.pcap -T fields -e modbus.data -Y "modbus.data != 0 and tcp.dstport == 502"
tshark -r ./5.0.2.pcapng -T fields -e data-text-lines -Y "data-text-lines"
```



-r 表⽰指定的⽂件

-T fields -e modbus.data 这个⼀般组合起来

⽤，⽤来提取某个协议的某个属性数据

-Y 过滤器选项

![image-20230602144243925](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306021442159.webp)

不知道-e填什么的时候去这⾥找

![image-20230602144303788](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306021443152.webp)