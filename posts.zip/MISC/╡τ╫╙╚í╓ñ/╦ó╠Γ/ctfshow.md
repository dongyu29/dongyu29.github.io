---
title: ctfshow-取证
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 105
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - MISC
  - 电子取证
  -  刷题
categories:
  - MISC
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

常用命令

```
查找⽤户名密码信息。当前操作系统中的 password hash，例如 Windows 的 SAM 文件内容
vol.py -f Target.mem --profile=Win7SP0x64 hashdum

从注册表中提取LSA密钥信息（已解密)
vol.py -f Target.mem --profile=Win7SP0x64 lsadump

列举出系统进程，但它不能检测到隐藏或者解链的进程
vol.py -f Target.mem --profile=Win7SP0x64 pslist

可以找到先前已终止(不活动)的进程以及被rootkit隐藏或解链的进程
vol.py -f Target.mem --profile=Win7SP0x64 psscan

以树的形式查看进程列表，和pslist一样，也无法检测隐藏或解链的进程
vol.py -f Target.mem --profile=Win7SP0x64 pstree

提取进程, -p是进程号 -D 存储的文件夹 提取出指定进程
vol.py -f Target.mem --profile=Win7SP0x64 memdump -p xxx --dump-dir=./

查看服务
vol.py -f Target.mem --profile=Win7SP0x64 svcscan

查看ie浏览器浏览历史
vol.py -f Target.mem --profile=Win7SP0x64 iehistory

查看⽹络连接
vol.py -f Target.mem --profile=Win7SP0x64 netscan

查看命令⾏操作
vol.py -f Target.mem --profile=Win7SP0x64 cmdscan

查看⽂件
vol.py -f Target.mem --profile=Win7SP0x64 filescan

提取文件
vol.py -f Target.mem --profile=Win7SP0x64 dumpfiles -Q 0xxxxxxxx -D ./

查看当前展示的notepad内容
vol.py -f Target.mem --profile=Win7SP0x64 notepad

查看屏幕截图
vol.py -f Target.mem --profile=Win7SP0x64 screenshot --dump-dir=./

查看注册表单元
vol.py -f Target.mem --profile=Win7SP0x64 hivelist

导出注册表, -o 注册表的virtual地址
vol.py -f Target.mem --profile=Win7SP0x64 hivedump -o 0xfffff8a001032410

获取注册表信息，-K “键值”
vol.py -f Target.mem --profile=Win7SP0x64 printkey -K "xxxxxxx"

查看运⾏程序相关的记录
vol.py -f Target.mem --profile=Win7SP0x64 userassist
```





# 套的签到题

导出2911分组的http对象有一个压缩包

压缩以后是一堆php源码

a.php貌似是一个webshell



看了wp知道这个是蚁剑的流量

==这个流量特征之前见过，是蚁剑的流量特征，蚁剑命令执行的流量是通过base64混淆的==

![image-20230907121438301](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071214947.webp)





- 3166读根目录





- 3221分组

![image-20230907122217241](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071222395.webp)

![image-20230907122206019](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071222403.webp)





- 3589分组，不知道是不是

68d137cf5flag (varchar(200))	50449bc3fb5

![image-20230907122554613](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071225763.webp)





- 3664分组

50211d3a3dflag	|	

bm93X3lvdV9jYW5fc3VibWl0X2ZsYWcy	|	

79f8d7eeb

![image-20230907122706876](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071227044.webp)

![image-20230907122732760](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071227921.webp)





- 4019

  b46302euser_pass	|	

  JFAkQnFhQkUxSHFkcUpCakFLZnlWN015U3NyMHpEa2tiMQ==	|	

  cfec1

  有一个加密的用户密码



- 4400

a2dd34bae8flag

![image-20230907123400316](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071234599.webp)



- 7076

  导出html

  ![image-20230907125330996](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071253180.webp)

![image-20230907125311733](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309071253000.webp)

ctfshow{p4rt1_y00_you_crack_my_wpweb_now_you_can_submit_flag2_oh_you_got_the_part_3}





# JiaJia-CP-1

1.佳佳的电脑用户名叫什么(即C:\Users{name})

2.最后一次运行计算器的时间？(格式为yyyy-mm-dd_hh:mm:ss，注意冒号为英文冒号)

```
vol.py -f ../JiaJia_Co.raw imageinfo
vol -f ../JiaJia_Co.raw imageinfo
```

Win7SP1x64

![image-20230908173253310](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309081732738.webp)

```
./vol -f ../JiaJia_Co.raw --profile=Win7SP1x64 filescan | grep Users
```

用户名就是JiaJia

![image-20230908173912220](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309081739458.webp)

最后一次运行计算器的时间，我们可以使用timeliner插件从多个位置来搜集系统的活动信息，把得到的存到txt里
```
vol -f JiaJia_Co.raw --profile=Win7SP1x64 timeliner |grep "calc.exe"
```

![image-20230908180302141](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309081803321.webp)



然后注意要时间换算到东八区（UTC+8），也就是**2021-12-10_20:15:47**

```
echo -n "JiaJia_2021-12-10_20:15:47" |md5sum
ctfshow{079249e3fc743bc2d0789f224e451ffd}
```



# JiaJia-CP-2

1.佳佳在公司使用了一款聊天软件，请问此软件的版本号为?

2.佳佳在网页上登录了自己的邮箱，请问佳佳的邮箱是？

flag格式为ctfshow{md5(A1_A2)} format:ctfshow{[12.0.7.14098_JiaJia2233@qq.com](mailto:12.0.7.14098_JiaJia2233@qq.com)}



```
以树的形式查看进程列表，和pslist一样，也无法检测隐藏或解链的进程
vol -f JiaJia_Co.raw --profile=Win7SP1x64  pstree
```

看聊天软件版本信息，之前pslist并未看到有聊天软件，所以还是timeliner看一下，这次搜索范围限定在桌面上（一般桌面至少都有快捷方式吧）

或者直接找桌面文件

```
vol -f JiaJia_Co.raw --profile=Win7SP1x64 timeliner|grep "Desktop"
vol -f JiaJia_Co.raw --profile=Win7SP1x64 filescan |grep "Desktop"
```

Telegram.exe

![image-20230909181550835](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309091815147.webp)

```
提取文件
vol.py -f Target.mem --profile=Win7SP0x64 dumpfiles -Q 0xxxxxxxx -D ./

vol -f JiaJia_Co.raw --profile=Win7SP1x64 dumpfiles -Q 0x000000013fde26a0 -D ./ #将Telegram.exe导出
```

![image-20230909182122767](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309091821920.webp)

**导出是一个`img`文件改一下后缀`exe`查看属性得到版本号：`3.3.0.0`**

![image-20230909182301013](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309091823185.webp)

```
查看屏幕截图
vol.py -f Target.mem --profile=Win7SP0x64 screenshot --dump-dir=./

vol -f JiaJia_Co.raw --profile=Win7SP1x64 screenshot --dump-dir ./
```

![image-20230909182521998](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309091825299.webp)

**导出截图发现了邮箱：`a2492853776@163.com`进行拼接在`md5sum`一下**

![image-20230909182621256](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309091826406.webp)

```
echo -n "3.3.0.0_a2492853776@163.com" | md5sum
```

ctfshow{f1420b5294237f453b7cc0951014e45a}



# JiaJia-CP-3

1.佳佳最后一次运行固定在任务栏的google chrome的时间(格式为yyyy-mm-dd_hh:mm:ss，注意冒号为英文冒号)

2.佳佳解压了从chrome下载了一个压缩文件，此文件的相关内容信息已经写入了到环境中，请问文件的内容是？

```
vol -f JiaJia_Co.raw --profile=Win7SP1x64 timeliner |grep "chrome"
```

最晚的是：**2021-12-10_20:28:43**(注意UTC+8)

最后的一个题目提示了压缩的信息在环境中，也就是使用envars模块查看环境变量

```
存到txt里方便查找
volatility -f JiaJia_Co.raw --profile=Win7SP1x64 envars > envars.txt
直接找zip、rar之类的
```

可以看到rAR对应的值就是内容：**Th1s_i5_Ur_P5wd**





# JiaJia-PC-1

**1.产品秘钥（卷影）**

**2.windows系统版本号**

![image-20230910164529834](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309101645680.webp)

使用盘古石的计算机仿真

![image-20230910170752869](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309101707918.webp)

第一题第一问，问产品秘钥。

https://blog.csdn.net/weixin_44152939/article/details/125987843

打开注册表，win+r输入regedit，回车会打开注册表，然后找到

```
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform
```

![image-20230910171352985](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309101714634.webp)

其BackupProductKeyDefault的值就是产品秘钥，即YC7N8-G7WR6-9WR4H-6Y2W4-KBT6X
当然这是卷影中的值，不知道为啥某些软件梭出来的不一样，然后另一种方法查看的也不一样。。。居然有3个值这个 我也不知道为啥
但是这里我注册就是用到的这个值，所以以卷影中的为准

第二问问的是系统版2本号，在左下角开始菜单处右击选择系统即可
![image-20230910171601150](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309101716331.webp)



# JiaJia-PC-2

1.佳佳的QQ号是多少？

2.金额统计.rar是由哪个QQ号通过邮箱发送来的？

3.金额统计文档的作者是谁？



第二题涉及到邮箱，桌面上有一个Foxmail，于是去查找foxmail的默认存放目录

其中发现了C:\Foxmail 7.2\Storage\2492853776@qq.com

所以佳佳的QQ号就是2492853776



在mails文件夹下发现9个目录和Index，在其中发现了发送人QQ 77602440，并且还发现佳佳注册了TeamViewer

但是附件在邮件中，需要将文件夹导入到foxmail中，随便登录一个邮箱进入foxmail，看这个步骤

foxmail storage文件夹 导入新安装的Foxmail 7.2，然后重启foxmail

​	https://zhidao.baidu.com/question/2203368569887982148.html

![image-20230910174054958](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309101741664.webp)



所以flag为2492853776_77602440_mumuzi的md5值



# JiaJia-PC-3

1.佳佳使用了公司指定的聊天软件，并且使用了此软件的远控功能，请问整个远控持续了多少秒？

2.此软件是在多久被开始安装的，请将空格替换成下划线

3.除开开机密码外，佳佳喜欢使用一个通用密码，请找出此密码。



之前说到了，佳佳使用了TeamViewer，而且在最近添加 或 控制面板-卸载程序处也能看到TeamViewer，且在最近访问里面也能够看到，因此知道问的是此软件。

而此软件会存放在

C:\Program Files\TeamViewer\

C:\Users\<User Profile>\AppData\Roaming\TeamViewer\
![image-20230910174634707](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309101746397.webp)

时间是在Connections_incoming找到 为14-12-2021 14:20:52 到 14-12-2021 14:23:35

整个时间为23:35-20:52=163秒，而开始安装的时间能在Logfile找到，为2021/12/14 22:14:00.570，别去纠结啥install字段才是安装开始时间，程序开始运行写日志的时候已经算是开始安装了，这点不要去纠结（如果没有当我没说）。

第三个问题，问的是密码。这里还有的软件就是QQ、浏览器、火绒。foxmail是找不出密码了，因此在剩下的里面找，最后发现火狐浏览器里面存放了密码。

![image-20230910174752530](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309101747716.webp)

因此flag为163_2021/12/14_22:14:00.570_Miaojia123的md5值













































