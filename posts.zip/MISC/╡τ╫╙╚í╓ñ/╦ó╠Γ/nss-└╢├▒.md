---
title: NSS-蓝帽
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 106
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - MISC
  - 电子取证
  -  刷题
categories:
  - MISC
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

# 网站1

![image-20230910011654909](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309100116301.webp)



# 网站2

一种方法是直接搜127.0.0.1

![image-20230912125024033](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309121250210.webp)

装好拓展，直接调用运行即可

![image-20230912125206803](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309121252055.webp)

KBLT123



# 网站3

```
请提交数据库金额加密混淆使用的盐值。
```

在sql文件找到插入GG币的表，搜索这个表

tab_channel_order_list

发现money在插入之前做了加密

![image-20230912130658263](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309121306714.webp)

jyzg123456

![image-20230912130722841](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309121307077.webp)



# 网站4

查看王子豪和张宝的id分别 5,3

```
INSERT INTO "public"."tab_user" VALUES (3, '张宝', '967ee505bd742d713528ad2e55a04bba', 3, 1, NULL, '', 1, '', '', NULL, '158720003133', NULL, '2018-04-09 19:00:00');

INSERT INTO "public"."tab_user" VALUES (5, '王子豪', 'f783ca62ff21833fdcfe3b74e1a82e1c', 3, 1, NULL, '王子豪', 1, '', '', NULL, '', NULL, '2020-04-18 16:04:53');
```



![image-20230912131425367](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309121314466.webp)



# 计算机取证1

Passware Kit Forensic 选择内存镜像分析，勾选Windows用户进行分析

![image-20230912010459932](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309120105390.webp)

获取密码为`anxinqi`



# 计算机取证_2

取证大师内存工具分析，发现MagnetRAMCapture这个进程，这个软件是专门用来制作内存镜像的工具

![image-20230912122742380](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309121227306.webp)



![image-20230912123408173](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309121234653.webp)





或者用vol

```
vol -f 1.dmp --profile=Win7SP1x64 pslist
```

2192

![image-20230912122848345](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309121228659.webp)





# 计算机取证3

> Bitlocker是一个加密磁盘的功能，恢复密钥是加密磁盘后生成的密钥，用处是在用户忘记加密的密码是可以用来解锁磁盘。 **BitLocker 恢复密钥是一个 32 位数字**。

E01用取证大师，发现有bitlocker，但是没有恢复秘钥，因此passware梭

Passware Kit Forensic 选择内存镜像和加密卷进行解密

![image-20230912231119018](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309122311619.webp)





![image-20230912232146432](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309122321319.webp)

368346-029557-428142-651420-492261-552431-515438-338239

获得未解密版镜像，生成的这个文件就可以拿进取证大师取证了

![image-20230912232715095](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309122327375.webp)

查看磁盘信息，发现多个office文件均被加密，还有一个pass.txt，推测需要跑字典

导出pptx docx pass.txt

Passware Kit Forensic添加pass.txt字典

![image-20230912234859925](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309122349847.webp)

得到pptx文档的密码是**287fuweiuhfiute**，打开得到**flag{b27867b66866866686866883bb43536}**

![image-20230912235006701](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309122350459.webp)





或者

![image-20230912235239740](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309122352997.webp)

先使用取证大师导出内存中的bitlocker密钥

内存镜像解析工具解析1.dmp得到密钥

![image-20230913001105550](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130011816.webp)

导出它，然后可以直接用它在取证大师解密（右键有一个bitlocker解密，选择用这个文件解密）

![image-20230913001530945](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130015139.webp)



取证大师解密BitLocker加密的e01磁盘文件，发现一个pass.txt，一个加密的ppt，一个加密docx和一个可疑的新建文本文档.txt

尝试用pass.txt爆破ppt的密码，爆出出来后打开得到flag



# 计算机取证4

新建文本文档.txt是truecrypt加密文件

不知道怎么判断的，可能是看这个文件大小太大了

依旧是passware梭

![image-20230913003536937](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130035674.webp)



没梭到密码，但是文件已经被解密，然后用dg恢复，提了个哈哈哈.zip

![image-20230913004222703](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130042087.webp)

发现有密码，不是伪加密，于是爆破一下密码





取证大师提取1.dmp的TrueCrypt密钥

![image-20230913004631614](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130046867.webp)



把那个txt文件导入取证大师用密钥文件解密

![image-20230913010013511](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130100066.webp)

导出这个哈哈哈.zip

![image-20230913010102822](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130101055.webp)

爆破

![image-20230913010558621](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130106529.webp)



![image-20230913010632087](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309130106341.webp)





# domainhacker

最后下载了一个rar，把它的http对象导出

前面是webshell流量，下载这个rar流量的前一个应该打包rar的时候设置了密码，需要解密webshell

关键在`tcp.stream eq 13`这个TCP流中，看返回结果应该是执行了RAR压缩，将参数拼接并base64解码即为命令执行内容，命令内容为：`cd /d "c:\\Windows\\Temp"&rar.exe a -PSecretsPassw0rds 1.rar 1.txt`，拿到压缩包密码

不要管前面的YN,后面的base64解码就好了

![image-20230913132624212](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309131326911.webp)

这种流量好像都是不管前面两个字母base64解码

![image-20230913132743924](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309131327122.webp)

binwalk直接跑流量文件跑出RAR文件，解压，拿到哈希

```php
* NTLM : 416f89c3a5deb1d398a1a1fce93862a7
* SHA1 : 54896b6f5e60e9be2b46332b13d0e0f110d6518f
```

交NTLM



# domainhacker2

套路一样的

```
cd /d "c:\\Windows\\Temp"&rar.exe a -PFakePassword123$ ntds.rar new&echo 1d3632&cd&echo 78bc462ab
```

**这里得到三个文件 需要使用脚本 直接上链接：https://github.com/SecureAuthCorp/impacket**

```
pip install impacket
pip install -r requirements.txt
cd impacket/ #进入路径
python setup.py install #安装
```

```
脚本在\impacket\examples路径

python secretsdump.py -ntds G:/A-kali-share/domainhacker2_184c16876d41965a695f89232ae5392d/new/ntds.dit -system G:/A-kali-share/domainhacker2_184c16876d41965a695f89232ae5392d/new/SYSTEM -security G:/A-kali-share/domainhacker2_184c16876d41965a695f89232ae5392d/new/SECURITY -history LOCAL
```

![image-20230913134003638](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309131340898.webp)

![image-20230913135309196](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309131353515.webp)

NSSCTF{07ab403ab740c1540c378b0f5aaa4087}





# 手机1

盘古石打开直接搜

![image-20230913161915343](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309131619544.webp)





# 手机2

昨天买的东西单号，SF1142358694796,东西快到了，你们早点来公司

![image-20230913162248959](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309131622284.webp)































































































