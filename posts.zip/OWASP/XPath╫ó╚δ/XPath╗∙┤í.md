---
title: XPATH注入基础
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 122
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - OWASP
  - XPATH注入
categories:
  - OWASP
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter



---

<!--more-->

# 什么是xpath

XPath 即为 XML 路径语言，是 W3C XSLT 标准的主要元素，它是一种用来确定 XML（标准通用标记语言的子集）文档中某部分位置的语言。

XPath 基于 XML 的树状结构，有不同类型的节点，包括元素节点，属性节点和文本节点，提供在数据结构树中找寻节点的能力，可用来在 XML 文档中对元素和属性进行遍历。

XPath 使用路径表达式来选取 XML 文档中的节点或者节点集。这些路径表达式和我们在常规的电脑文件系统中看到的表达式非常相似。

XPath是一种用来在内存中导航整个XML树的语言,它的设计初衷是作为一种面向XSLT和XPointer的语言,后来独立成了一种W3C标准.

# XPath基础语法

[W3C  XPath教程](https://www.w3school.com.cn/xpath/index.asp)

## (1)查询基本语句

//users/user[loginID/text()=’abc’ and password/text()=’test123’] 。

这是一个XPath查询语句，获取loginID为abc的所有user数据，用户需要提交正确的loginID和password才能返回结果。如果黑客在 loginID 字段中输入：' or 1=1 并在 password 中输入：' or 1=1  就能绕过校验，成功获取所有user数据

//users/user[LoginID/text()=''or 1=1 and password/text()=''or 1=1]

## (2)节点类型

在XPath中,XML文档被作为节点树对待,XPath中有七种结点类型：元素、属性、文本、命名空间、处理指令、注释以及文档节点（或成为根节点）。 文档的根节点即是文档结点；对应属性有属性结点，元素有元素结点。

> element (元素)
>
> attribute (属性)
>
> text (文本)
>
> namespace (命名空间)
>
> processing-instruction (处理指令)
>
> comment (注释)
>
> root (根节点)

例如下面的XML文档

```XML
<?xml version="1.0" encoding="ISO-8859-1"?>
<bookstore>
<book>
<title lang="en">Harry Potter</title>
<author>J K. Rowling</author>
<year>2005</year>
<price>29.99</price>
</book>
</bookstore>
```

<bookstore>根节点

<author>J K. Rowling</author>  元素节点

lang="en"属性节点

 

## (3)表达式

XPath通过路径表达式(Path Expression)来选取节点,基本规则:

| 表达式   | 描述                                                     |
| -------- | -------------------------------------------------------- |
| nodename | 选取此节点的所有子节点                                   |
| /        | 从根节点选取                                             |
| //       | 从匹配选择的当前节点选择文档中的节点，而不考虑它们的位置 |
| .        | 选取当前节点                                             |
| ..       | 选取当前节点的父节点                                     |
| @        | 选取属性或　@*：匹配任何属性节点                         |
| *        | 匹配任何元素节点                                         |

来看一个XML实例,

```XML
<?xml version="1.0" encoding="ISO-8859-1"?>
<bookstore>
<book>
<title lang="eng">Harry Potter</title>
<price>29.99</price>
</book>
<book>
<title lang="eng">Learning XML</title>
<price>39.95</price>
</book>
</bookstore>
```

则：

路径表达式 结果

| 表达式          | 结果                                                         |
| --------------- | ------------------------------------------------------------ |
| bookstore       | 选取 bookstore 元素的所有子节点                              |
| /bookstore      | 选取根元素 bookstore                                         |
| bookstore/book  | 选取属于 bookstore 的子元素的所有 book 元素                  |
| //book          | 选取所有 book 子元素,而不管它们在文档中的位置                |
| bookstore//book | 选择属于 bookstore 元素的后代的所有 book 元素,而不管它们位于 bookstore 之下的什么位置 |
| //@lang         | 选取名为 lang 的所有属性                                     |

 

## (4)限定语

限定语是对路径表达式的附加条件,用来查找某个特定的节点或者包含某个指定的值的节点.限定语被嵌在方括号中.

路径表达式结果：

| 表达式                             | 结果                                                         |
| ---------------------------------- | ------------------------------------------------------------ |
| /bookstore/book[1]                 | 选取属于 bookstore 子元素的第一个 book 元素                  |
| /bookstore/book[last()]            | 选取属于 bookstore 子元素的最后一个 book 元素                |
| //title[@lang]                     | 选取所有拥有名为 lang 的属性的 title 元素                    |
| //title[@lang=’eng’]               | 选取所有 title 元素，且这些元素拥有值为 eng 的 lang 属性     |
| /bookstore/book[price>35.00]/title | 选取 bookstore 元素中的 book 元素的所有 title 元素，且其中的 price 元素的值须大于 35.00 |

## (5)通配符

XPath 通配符可用来选取未知的 XML 元素.

| 通配符 | 描述               |
| ------ | ------------------ |
| *      | 匹配任何元素节点   |
| @*     | 匹配任何属性节点   |
| node() | 匹配任何类型的节点 |

实例<?xml version="1.0" encoding="ISO-8859-1"?>

<bookstore>

<book>

 <title lang="eng">Harry Potter</title>

 <price>29.99</price>

</book>

<book>

 <title lang="eng">Learning XML</title>

 <price>39.95</price>

</book>

</bookstore>

| 表达式       | 结果                            |
| ------------ | ------------------------------- |
| /bookstore/* | 选取 bookstore 元素的所有子元素 |
| //*          | 选取文档中的所有元素            |
| //title[@*]  | 选取所有带有属性的 title 元素   |

## (6) 选取多个路径

可以在路径表达式中使用”|”运算符来选取若干路径.

实例,

| 表达式                        | 结果                                                         |
| ----------------------------- | ------------------------------------------------------------ |
| //book/title\|//book/price    | 选取 book 元素的所有 title 和 price 元素                     |
| bookstore/book/title\|//price | 选取属于 bookstore 元素的 book 元素的所有 title 元素，以及文档中所有的 price 元素 |

## (7) 运算符

路径表达式中可以使用一些常见的数学运算符和逻辑运算符,

| 运算符 | 描述           | 实例                      | 返回值                                                       |
| :----- | :------------- | :------------------------ | :----------------------------------------------------------- |
| \|     | 计算两个节点集 | //book \| //cd            | 返回所有拥有 book 和 cd 元素的节点集                         |
| +      | 加法           | 6 + 4                     | 10                                                           |
| -      | 减法           | 6 - 4                     | 2                                                            |
| *      | 乘法           | 6 * 4                     | 24                                                           |
| div    | 除法           | 8 div 4                   | 2                                                            |
| =      | 等于           | price=9.80                | 如果 price 是 9.80，则返回 true。如果 price 是 9.90，则返回 false。 |
| !=     | 不等于         | price!=9.80               | 如果 price 是 9.90，则返回 true。如果 price 是 9.80，则返回 false。 |
| <      | 小于           | price<9.80                | 如果 price 是 9.00，则返回 true。如果 price 是 9.90，则返回 false。 |
| <=     | 小于或等于     | price<=9.80               | 如果 price 是 9.00，则返回 true。如果 price 是 9.90，则返回 false。 |
| >      | 大于           | price>9.80                | 如果 price 是 9.90，则返回 true。如果 price 是 9.80，则返回 false。 |
| >=     | 大于或等于     | price>=9.80               | 如果 price 是 9.90，则返回 true。如果 price 是 9.70，则返回 false。 |
| or     | 或             | price=9.80 or price=9.70  | 如果 price 是 9.80，则返回 true。如果 price 是 9.50，则返回 false。 |
| and    | 与             | price>9.00 and price<9.90 | 如果 price 是 9.80，则返回 true。如果 price 是 8.50，则返回 false。 |
| mod    | 计算除法的余数 | 5 mod 2                   | 1                                                            |



## (8) 函数

|        名称        |                           结果                           |
| :----------------: | :------------------------------------------------------: |
|      ancestor      |           选取当前节点的所有先辈（父、祖父等）           |
|  ancestor-or-self  |   选取当前节点的所有先辈（父、祖父等）以及当前节点本身   |
|     attribute      |                  选取当前节点的所有属性                  |
|       child        |                选取当前节点的所有子元素。                |
|     descendant     |         选取当前节点的所有后代元素（子、孙等）。         |
| descendant-or-self | 选取当前节点的所有后代元素（子、孙等）以及当前节点本身。 |
|     following      |       选取文档中当前节点的结束标签之后的所有节点。       |
|     namespace      |              选取当前节点的所有命名空间节点              |
|       parent       |                  选取当前节点的父节点。                  |
|     preceding      |       选取文档中当前节点的开始标签之前的所有节点。       |
| preceding-sibling  |             选取当前节点之前的所有同级节点。             |
|        self        |                      选取当前节点。                      |

路径表达式可以是绝对路径，也可以是相对路径。例如：

**绝对位置路径：**

/step/step/...

**相对位置路径：**

step/step/...

其中的每一步又可以是一个表达式，包括：

轴（函数）（axis）

定义所选节点与当前节点之间的树关系

节点测试（node-test）

识别某个轴内部的节点

零个或者更多谓语（predicate）

更深入地提炼所选的节点集

|          例子          |                             结果                             |
| :--------------------: | :----------------------------------------------------------: |
|      child::book       |           选取所有属于当前节点的子元素的 book 节点           |
|    attribute::lang     |                   选取当前节点的 lang 属性                   |
|        child::*        |                   选取当前节点的所有子元素                   |
|      attribute::*      |                    选取当前节点的所有属性                    |
|     child::text()      |                 选取当前节点的所有文本子节点                 |
|     child::node()      |                   选取当前节点的所有子节点                   |
|    descendant::book    |                 选取当前节点的所有 book 后代                 |
|     ancestor::book     |                 选择当前节点的所有 book 先辈                 |
| ancestor-or-self::book | 选取当前节点的所有book先辈以及当前节点（假如此节点是book节点的话） |
| child::*/child::price  |                选取当前节点的所有 price 孙。                 |

























