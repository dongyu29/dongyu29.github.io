---
title: git学习
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 103
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter



---

<!--more-->

#  Git学习笔记

###  我的理解

git是一个版本控制工具，意思它就是一个软件，版本控制有两个作用，一是记录每次修改完的项目，方便出问题时回到原本的状态；二是多人协同开发。git是和github进行联动使用的。我们开发的时候可能会很多人协同开发，在使用git的时候输入用户名邮箱可以让Git记住你，比如你用你输入的用户名进行了项目更新，他就会有一个类似日志的东西，记录每一次更改和进行操作的人。

大致工作流程就是你在本地写完代码以后add到你在本地创造的目录中，等你觉得差不多完活了在把它push到github的仓库里。 **在每天工作的第一件事就是先git pull拉取线上最新的版本；每天下班前要做的是git push，将本地代码提交到线上仓库。** 

注意在使用的时候路径尽量不要有中文。



###  创建本地目录：

```
mkdir pro_git
cd pro_git
```

###  Git仓库初始化 

执行之后会在项目目录下创建“.git”的隐藏目录，这个目录是Git所创建的，不能删除，也不能随意更改其中的内容。它所在的文件夹就是仓库，会记录你所做的变更。

```
git init
```

```
之后再使用git status命令，可以查看当前仓库信息。
```

### 输入用户名邮箱：

```
git config --global user.name "MUNG29" //这俩最好和github的保持同步
git config --global user.email "735587142@qq.com"
```

###  将文件加入暂存区（git add)

```
查看当前状态：git status 
添加到缓存区：git add 文件名
说明：git add指令，可以添加一个文件，也可以同时添加多个文件。
语法1：git add 文件名
语法2：git add 文件名1 文件名2 文件名3 …
语法3：git add .	将所有文件加入暂存区
```

加入暂存区效果展示：

它绿了

![1656062534000](C:\Users\HP\AppData\Roaming\Typora\typora-user-images\1656062534000.png)



###  取消加入暂存区

如果你add了一个文件，但是发现不该add它的，可以使用此命令来把它去掉

```
git reset <filename>
```

这样绿色的文件就重新变红了

###  提交变更（版本更新）

```
git commit -m "注释"
```

效果：

![1656062778117](C:\Users\HP\AppData\Roaming\Typora\typora-user-images\1656062778117.png)

###  版本回退

如果你觉得新版本不如某次版本好，可以通过git reset \<hash> --<模式>, 回到某次状态（hash值可以通过日志看到）

```
git reset <hash> --<模式>
hash值很长，但是一般前7位就可以锁定是哪个版本了，所以输入前7位就好
模式有三种：
--hard:不保存所有变更，一切都回到你回退到的hash版本的状态
--soft:保留变更且变更内容处于Staged(绿)
--mixed:保留变更且变更内容处于Mdifiled（红）
```

![1656063455173](C:\Users\HP\AppData\Roaming\Typora\typora-user-images\1656063455173.png)



**那如果你又后悔了，怎么回到刚刚的新版本呢？**

这个时候git log的日志已经去掉你回到的这个版本以后的记录了，比如上面有6次提交，你回到了第五次，那git log就看不到第六次的内容了

这个时候你就可以通过 git reflog 来查看所有记录

```
git reflog
```

然后找到你想回到的版本hash值，再次git reset \<hash>

![1656063869767](C:\Users\HP\AppData\Roaming\Typora\typora-user-images\1656063869767.png)





###  查看日志

通过 git log,  我们可以知道什么人在什么时间提交了什么样的commit, 每个commit会生成一个唯一的哈希值

可以通过查看日志确定自己是否已经进行提交了

![1656062856203](C:\Users\HP\AppData\Roaming\Typora\typora-user-images\1656062856203.png)

###  使用clone指令克隆线上仓库到本地

```
语法：git clone 线上仓库地址
```

###  在仓库上做对应的操作（**提交暂存区、提交本地仓库、提交线上仓库、拉取线上仓库**） 

在首次往线上仓库shop提交内容的时候出现了403的致命错误，原因是不是任何人都可以往线上仓库提交内容，必须需鉴权。
(如果不加可以的话那就不加)
需要修改“.git/config”文件内容：

![1656047415825](C:\Users\HP\AppData\Roaming\Typora\typora-user-images\1656047415825.png)

```
提交到线上仓库：git push
拉取线上仓库：git pull
```



###  git clone和git pull的区别联系

`git clone`就是将一个库复制到本地，**是一个本地从无到有的过程**。包括里面的日志信息，git项目里的分支，你也可以直接切换、使用里面的分支等等。 

 `git pull` 作用是，**取回远程主机某个分支的更新，再与本地的指定分支合并**。 

类比一下，前者相当于你下载了一个游戏，后者相当于游戏更新。因为多人协同合作，线上仓库经常更新，就像游戏更新，你总不能每次都重新下载最新版本的游戏吧，肯定是选择更新。

###  分支

 在开发的时候往往是团队协作，多人进行开发，因此光有一个分支是无法满足多人同时开发的需求的，并且在分支上工作并不影响其他分支的正常使用，会更加安全，Git鼓励开发者使用分支去完成一些开发任务。 

掌握分支以后，如果你想回到某个版本，就可以直接切换分支，而不用再查找hashID了

```
分支相关指令：
查看所有分支：git branch （绿色的代表当前所处的分支）
创建分支：git branch 分支名   git checkout -b <分支名> <以谁为模板，可省>
切换分支： git checkout 分支名
删除分支：git branch -d 分支名
合并分支：git merge 被合并的分支名  （通常要解决冲突）
对比查看远程仓库信息：git fetch

git pull=git fetch+git merge
```

通常我们把master作为主分支

![1656065207677](C:\Users\HP\AppData\Roaming\Typora\typora-user-images\1656065207677.png)





![1656065939392](C:\Users\HP\AppData\Roaming\Typora\typora-user-images\1656065939392.png)