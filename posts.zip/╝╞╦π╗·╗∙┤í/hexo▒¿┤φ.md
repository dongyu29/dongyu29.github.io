---
title: hexo报错解决
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 104
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

# hexo d上传错误

先是出现错误：
error：spawn failed...
然后经过一些博客的操作会出现以下问题：
fatal: cannot lock ref 'HEAD': unable to resolve reference HEAD: Invalid argument error: src refspec
或者：
error: src refspec HEAD does not match any.等等
总结一下：
问题大多是因为git 进行push或者hexo d的时候改变了一些.deploy_git文件下的内容。

解决办法：
```
删除.deploy_git文件夹;
输入git config --global core.autocrlf false
然后，依次执行：
hexo clean
hexo g
hexo d
```





# git报错 10054

OpenSSL SSL_read: Connection was reset, errno 10054

修改设置，解除ssl验证

```
git config --global http.sslVerify "false"
```





# hexo g解析报错

## 一

can not read a block mapping entry; a multiline key may not be an implicit key at line 2, column 5:

原因一： 设置后面没加空格

  这些都是有空格的![image-20230512013110260](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202305120131589.webp)

原因二：

  这些值里面又英文的引号或者双引号导致文章无法按照正确yaml语法解析出错，跟sql注入差不多意思，给闭合了



## 二

hexo 报错 err: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value
err: Error [Nunjucks Error]: [Line 171, Column 179] unexpected token: }}
原因是正文里面出现了多次{% %}这样的语句，网上解释说是Nunjucks引擎会把它解释为其它意思。

当把{{与{%放进代码块里面就不会报错了。。（还有一种解决方式是加\转义）

