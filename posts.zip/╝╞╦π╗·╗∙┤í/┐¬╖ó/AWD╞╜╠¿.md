---
title: AWD平台搭建
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 75
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

# 平台安装

下载awd平台

```bash
git clone https://github.com/zhl2008/awd-platform
```

进入项目

```bash
cd awd-platform
```

下载镜像文件，改名

```bash
sudo docker pull zhl2008/web_14.04
sudo docker tag zhl2008/web_14.04 web_14.04
```



# 启动比赛

创建队伍

这里创建了3个队伍，赛题是web_yunnan_simple

```bash
cd awd-platform
python batch.py web_yunnan_simple 3
```

根据赛题修改check.py（awd-platform/check_server/目录下）文件，找到check类

```python
class check(): 
    def __init__(self): 
        print "checking host: "+host 
    def index_check(self): 
        res = http('get',host,port,'/','',headers) 
        if 'Home' in res: 
            return True 
        if debug: 
            print "[fail!] index_fail" 
        return False 
    def test_check(self): 
        res = http('get',host,port,'/about.php?file=header.php','',headers) 
        if 'About' in res: return True if debug: 
        print "[fail!] test_fail" 
        return False 
    def test_check_2(self): 
        headers['Cookie'] = '' 
        data = 'key=1' 
        res = http('get',host,port,'/services.php',data,headers) 
        if 'Services' in res: 
            return True 
        if debug: 
            print "[fail!] test_2_fail" 
            return False
```

修改flag刷新时间，同样是check.py文件中，默认120s，2分钟

![image-20230713142939539](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307131429013.webp)

开启比赛

```bash
python start.py ./ 3
```

比赛拓扑

![image-20230713143025405](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307131430675.webp)

web站点
team1:192.168.109.128:8801
team2:192.168.109.128:8802
team3:192.168.109.128:8803

ssh连接
team1:192.168.109.128:2201
team2:192.168.109.128:2202
team3:192.168.109.128:2203

ssh连接的账号密码在项目下的`pass.txt`里面



访问web站点

team1web站点

![image-20230713143140277](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307131431635.webp)

其他队伍的web站点与team1队伍完成一致，只是端口不同而已



# 得分

运行修改后的check.py文件，启动check服务器

![image-20230713143222785](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307131432016.webp)

在这里可以看到实时分数:ip:8080/score.txt

如果觉得这个页面太丑的话，可以自己换个页面，我这里用的夜莫离大佬做的页面

![image-20230713143323243](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307131433924.webp)



计分板源码下载

```bash
链接：https://pan.baidu.com/s/1xF9uZpKUZTZt_OOfpoOrOw 
提取码：qwer
```

计分板文件拷贝至awd-platform下的flag_server文件夹下。要注意将文件score.txt与result.txt文件权限调至777，这样才能刷新出分值。
记分板里面的`index.php`文件需要将IP换成自己虚拟机的IP



提交

http://主机IP地址:8080/flag_file.php?token=teamx&flag=xxxx (x为队伍号)


# 结束比赛

进入项目目录

```bash
sudo python stop_clean.py
```