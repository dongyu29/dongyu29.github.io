---
title: python IO
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 101
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
  - 语言
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter


---

<!--more-->

# JSON

使用 JSON 函数需要导入 json 库：**import json**。

| 函数       | 描述                                     |
| :--------- | :--------------------------------------- |
| json.dumps | 将 Python 对象编码成 JSON 字符串         |
| json.loads | 将已编码的 JSON 字符串解码为 Python 对象 |

## json.dumps

json.dumps 用于将 Python 对象编码成 JSON 字符串。

语法

```python
json.dumps(obj, skipkeys=False, ensure_ascii=True, check_circular=True, allow_nan=True, cls=None, indent=None, separators=None, encoding="utf-8", default=None, sort_keys=False, **kw)
```

python 原始类型向 json 类型的转化对照表：

| Python           | JSON   |
| :--------------- | :----- |
| dict             | object |
| list, tuple      | array  |
| str, unicode     | string |
| int, long, float | number |
| True             | true   |
| False            | false  |
| None             | null   |



## json.loads

json.loads 用于解码 JSON 数据。该函数返回 Python 字段的数据类型。

语法

```python
json.loads(s[, encoding[, cls[, object_hook[, parse_float[, parse_int[, parse_constant[, object_pairs_hook[, **kw]]]]]]]])
```

json 类型转换到 python 的类型对照表：

| JSON          | Python    |
| :------------ | :-------- |
| object        | dict      |
| array         | list      |
| string        | unicode   |
| number (int)  | int, long |
| number (real) | float     |
| true          | True      |
| false         | False     |
| null          | None      |



```python
import json

sampleJson = """{
   "company":{
      "employee":{
         "name":"emma",
         "payble":{
            "salary":7000,
            "bonus":800
         }
      }
   }
}"""

data = json.loads(sampleJson)
print(data['company']['employee']['payble']['salary'])
```





# 文件读写

## 文件操作模式

| 模式 | 描述                                                         |
| :--- | :----------------------------------------------------------- |
| t    | 文本模式 (默认)。                                            |
| x    | 写模式，新建一个文件，如果==该文件已存在则会报错==。         |
| b    | 二进制模式。                                                 |
| +    | 打开一个文件进行更新(==可读可写==)。                         |
| U    | 通用换行模式（不推荐）。                                     |
| r    | 以只读方式打开文件。文件的指针将会放在文件的开头。这是默认模式。 |
| rb   | 以二进制格式打开一个文件用于只读。文件指针将会放在文件的开头。这是默认模式。一般用于==非文本文件如图片==等。 |
| r+   | 打开一个文件用于==读写==。文件指针将会放在文件的开头。       |
| rb+  | 以二进制格式打开一个文件用于==读写==。文件指针将会放在文件的开头。一般用于非文本文件如图片等。 |
| w    | 打开一个文件只用于写入。如果该文件已存在则打开文件，并从开头开始编辑，即原有内容会被删除。如果该文件不存在，创建新文件。 |
| wb   | 以二进制格式打开一个文件只用于写入。如果该文件已存在则打开文件，并从开头开始编辑，即原有内容会被删除。如果该文件不存在，创建新文件。一般用于非文本文件如图片等。 |
| w+   | 打开一个文件用于==读写==。如果该文件已存在则打开文件，并从开头开始编辑，即==原有内容会被删除==。如果该文件不存在，创建新文件。 |
| wb+  | 以二进制格式打开一个文件用于读写。如果该文件已存在则打开文件，并从开头开始编辑，即原有内容会被删除。如果该文件不存在，创建新文件。一般用于非文本文件如图片等。 |
| a    | 打开一个文件用于追加。如果该文件已存在，文件指针将会放在文件的结尾。也就是说，新的内容将会被写入到已有内容之后。如果该文件不存在，创建新文件进行写入。 |
| ab   | 以二进制格式打开一个文件用于追加。如果该文件已存在，文件指针将会放在文件的结尾。也就是说，新的内容将会被写入到已有内容之后。如果该文件不存在，创建新文件进行写入。 |
| a+   | 打开一个文件用于读写。如果该文件已存在，文件指针将会放在文件的结尾。文件打开时会是追加模式。如果该文件不存在，创建新文件用于读写。 |
| ab+  | 以二进制格式打开一个文件用于追加。如果该文件已存在，文件指针将会放在文件的结尾。如果该文件不存在，创建新文件用于读写。 |

## 读写text数据

```python3
with open(filename, 'rt', encoding='utf-8') as f:
    data = f.read()

with open(filename, 'rt', encoding='utf-8') as f:
    for line in f:
        print(line)

with open(filename, 'wt', encoding='utf-8') as f:
    f.write(text1)

with open(filename, 'wt', encoding='utf-8') as f:
    # 也可以使用print函数，指定file参数即可
    print(text1,file=f)
```

如果是追加模式，**wt**换成**at**即可。

使用`sys.getdefaultencoding()`可以获取到系统默认的编码方式，一般是**utf-8**，尽量使用`with`来操作文件，因为它自动帮你管理了文件的打开和关闭，如果不用with，自己不要忘记了关闭文件。



## 读写二进制数据

> 在Python中，`b'Hello World'` 表示一个字节字符串。字节字符串是类似于文本字符串的数据类型，但是它们以字节为单位存储数据，而不是Unicode字符。
>
> 在Python 3中，所有的字符串都默认是Unicode字符串。如果你需要使用字节字符串，则需要在字符串前加上 `b` 字符来指明这是一个字节字符串。
>
> 例如，以下两个字符串在 Python 中具有相同的值，但是不同的数据类型：
>
> ```python
> python复制代码s1 = 'Hello, world!'    # 文本字符串
> s2 = b'Hello, world!'   # 字节字符串
> ```
>
> 在某些情况下，你需要使用到了底层 I/O 操作、网络编程或与其他语言通信时，需要使用字节字符串来处理二进制数据。

```python3
with open(filename, 'rb') as f:
    data = f.read()

with open(filename, 'wb') as f:
    f.write(b'Hello World')

with open(filename, 'rb') as f:
    data = f.read(16)
    text = data.decode('utf-8')

with open(filename, 'wb') as f:
    text = 'Hello World'
    f.write(text.encode('utf-8'))
```



## 操作CSV和Excel

> csv是最通用的文件格式，本质是文本文件，用记事本即可打开。同一行中每个字段间用逗号分隔，在csv中显示的是在不同单元格中，在记事本中显示的是一行中用逗号分隔。
>
> xls是excel专用格式，是二进制文件，只有excel才能打开。

### CSV

**csv写入**

**1.写入列表（list）数据**

使用 csv.writer 对象

delimiter 指定同一行每个字段的分隔字符。若不指定，默认以英文逗号(,)分隔，在csv文件中显示的是不同单元格，若以其他符号分隔，则显示在csv同一单元格中

```python3
import csv
with open(r'e:\zarten.csv', 'w', newline='') as csvfile:
    csv_writer = csv.writer(csvfile, delimiter=' ')

    csv_writer.writerow(['a', 'b', 'c'])
    csv_writer.writerow(['d', 'e', 'f'])
```

**2.写入字典（dict）数据**

使用 csv.DictWriter 对象

```python3
import csv
with open(r'e:\zarten.csv', 'w', newline='') as csvfile:
    fieldnames = ['name', 'age']
    csv_writer = csv.DictWriter(csvfile, fieldnames= fieldnames, delimiter=' ')#csv中默认,分隔单元格，delimiter可以不指定

    csv_writer.writeheader()
    
    csv_writer.writerow({'name' : 'Zarten1', 'age' : 1})
    csv_writer.writerow({'name' : 'Zarten2', 'age' : 2})
```

**csv读取**

**1.读取普通csv**

使用 csv.reader 对象

```python3
import csv
with open(r'e:\zarten.csv', 'r', newline='') as csvfile:
    csv_reader = csv.reader(csvfile, delimiter= ' ')
    headers = next(csv_reader) #获取第一行，可能是头
    print(headers)
    for row in csv_reader:
        print(row)
        
#输出结果：
# ['name', 'age']
# ['Zarten1', '1']
# ['Zarten2', '2']
```

**2.读取字典（dict）csv**

使用 csv.DictReader 对象

```python3
import csv
with open(r'e:\zarten.csv', 'r', newline='') as csvfile:
    csv_reader = csv.DictReader(csvfile, delimiter= ' ')
    for row in csv_reader:
        print(row['name'], row['age'])
```



### EXCEL

之前写的

```python
#注意把母本excel和此脚本放在同一文件夹里！

import openpyxl
import random
wb=openpyxl.load_workbook('./母本.xlsx')  #注意！这个名字是母本，自己根据自己的改一下
sheet=wb.worksheets[0]
num=int(input('请输入班级人数：'))
def bilibili(abc):
  for n in range(5,num+5):
     sheet['H'+str(n)].value=str(round(random.uniform(36,37),1))+'℃'
     sheet['I'+str(n)].value=str(round(random.uniform(36,37),1))+'℃'
     sheet['J'+str(n)].value=str(round(random.uniform(36,37),1))+'℃'
  wb.save(f'{abc}.xlsx') 

numm=int(input('请输入你希望创建的表的个数：'))
for w in range(1,numm+1):
    abc=f'计算机信息工程学院学生体温监测表({w})'
    bilibili(abc)
```



**安装**

```python
pip3 install openpyxl
```



**excel写入**

```python
import openpyxl

file_path = r'e:\zarten.xlsx'

wb = openpyxl.Workbook()
sheet = wb.active
sheet.title = 'Zarten_info'

headers = ['name', "age"]
sheet.cell(1, 1, value=headers[0])
sheet.cell(1, 2 ,value=headers[1])

rows1 = ['Zarten1', 1]
sheet.append(rows1)

rows2 = ['Zarten2', 2]
sheet.append(rows2)
```



**excel读取**

```python
import openpyxl

file_path = r'e:\zarten.xlsx'

wb = openpyxl.load_workbook(file_path)
sheet = wb['Zarten_info']

for row in sheet.rows:
    row_info = [row[0].value, row[1].value]
    print(row_info)

    for cell in row:
        print(cell.value)
```



## 小技巧

如果要求对一个不存在的文件进行写操作，而存在的文件则不进行操作。（这样可以防止覆盖了已存在文件的内容）

常规写法：

```python
import os
if not os.path.exists(filename):
    with open(filename, 'wt') as f:
        f.write('Hello\n')
else:
    print('File already exists!')
```

更简单的写法，使用open的**x模式**

```python
with open(filename, 'xt') as f:
    f.write('Hello\n')
```



# 文件压缩

## zipfile

https://www.liujiangblog.com/course/python/62

zipfile模块其实很简单，记住下面几个重要的方法就可以了。

| 方法                  | 用途                        |
| --------------------- | --------------------------- |
| z = zipfile.ZipFile() | 打开或者新建一个zip文件对象 |
| z.write()             | 添加文件到压缩包内          |
| z.infolist()          | 查看压缩包内的文件信息      |
| z.extract()           | 解压单个文件                |
| z.extractall()        | 解压所有文件                |
| z.close()             | 关闭压缩文件                |
| z.writestr()          | 将字符串写入 ZIP 归档文件   |

```python
class zipfile.ZipFile(file, mode='r', compression=ZIP_STORED, allowZip64=True)
打开一个ZIP文件。返回的也是一个类似文件的ZipFile对象，可以读写。
file可以是一个文件地址字符串、文件类对象或地址类对象。compression指明压缩格式
压缩方式：
ZIP_STORED（无压缩）：不对文件进行压缩，直接将原始文件存储到 ZIP 归档文件中
ZIP_DEFLATED（默认压缩方式）
ZIP_BZIP2（BZIP2 压缩）
ZIP_LZMA（LZMA 压缩）

zipfile.is_zipfile(filename)
如果文件是个ZIP文件则返回True，否则False。

ZipFile.write(filename, arcname=None, compress_type=None)
往ZIP文件里添加新文件，单个文件可以重复添加，但是会弹出警告。如果指定arcname参数，则在ZIP文件内部将原来的filename改成arcname。例如z.write("test/111.txt", "test22/111.txt")

ZipFile.close()
确保压缩文件被正确关闭。

ZipFile.namelist()
返回ZIP文件内所有成员名字列表。

ZipFile.open(name, mode='r', pwd=None, *, force_zip64=False)
访问档案中的指定文件。pwd是解压密码。该方法也是个上下文管理器，支持with语法。
with ZipFile('spam.zip') as myzip:
    with myzip.open('eggs.txt') as myfile:
        print(myfile.read())

ZipFile.extract(member, path=None, pwd=None)
解压单个文件。核心方法之一。将ZIP文件中的某个成员解压到当前目录。member必须是完整名，path是指定的解压目录。解压的过程不会破坏原压缩文件。

ZipFile.extractall(path=None, members=None, pwd=None)
批量解压文件。默认是全部解压。核心方法之一。


```





# 路径

## 处理路径问题

```python
import os
path='C:\\User\\yan\\paper.txt'
print(os.path.basename(path))
print(os.path.dirname(path))
print(os.path.splitext(path))
```

Output:

```python
paper.txt
C:\User\yan
('C:\\User\\yan\\paper', '.txt')
```

## 判断文件或文件夹是否存在

```python
os.path.exists(filename)# 检查文件或目录是否存在
os.path.isfile(filename)# 判断路径是否为文件 
os.path.isdir(dirname)# 判断路径是否为目录 
os.path.getsize(filename)# 获取文件大小
os.path.getmtime(filename) #文件修改时间
import time
time.ctime(os.path.getmtime(filename)) #转换为易读的方式
os.listdir(dirname) # 列出dir所有的文件
```



# 查找文件名

```python
import glob
 
py_files = glob.glob('*.py') # 以list输出当前路径下所有后缀名为py的文件
print(py_files) # ['hehe.py', 'haha.py']
```



# 复制和移动

```python
import shutil
shutil.move('/tmp/20170223/new','/tmp/20170223/test')   # 移动文件, 重命名等
shutil.copyfile(oldfilename, newfilename) #从源src复制到dst中去。当然前提是目标地址是具备可写权限。
shutil.copy(oldfilename, newfilename)# 复制一个文件到一个文件或一个目录.copy第二个参数既可以指定文件名，也可以指定文件夹名
```

> 1. `shutil.copyfile(src, dst)`函数用来复制单个文件的内容，并将其写入到另一个文件中。==仅复制源文件的内容数据==，不包括所有的元数据（如文件模式、访问时间和修改时间等）。目标文件存在，则覆盖目标文件。如果目标文件不存在，则新建目标文件。使用`shutil.copyfile`时，必须保证源文件和目标文件都是存在的。
> 2. `shutil.copy(src, dst)`函数用来复制单个文件。该函数复制了源文件的内容数据和所有元数据，如权限、时间戳等。与`shutil.copyfile`不同的是，目标文件已经存在时不会覆盖旧文件，而是会报错。如果目标文件不存在，则新建目标文件。



# 文件夹操作

获取当前的工作文件夹

```python
os.getcwd()
```

改变当前工作文件夹

```python
os.chdir(dirname)
```

新建文件夹

```python
os.mkdir(dirname)  #创建单级目录
os.makedirs(dirname/subdirname) #创建多级目录
```

删除文件夹

```python
os.rmdir(dirname) #删除单级空目录
os.removedirs(dirname/subdirname) #删除多级空目录
import shutil
shutil.rmtree(dirname) #删除目录，不管是空还是非空，是单级目录还是多级目录
```

复制文件夹

```python
shutil.copytree(oldfoldername, newfoldername)
```

移动文件夹/文件

```python
shutil.move(oldpos, newp)
```



# 字符串字面值表示方式

```python
字符串前面加‘u’，表示以Unicode格式进行编码，一般用在中文字符前面，防止因为源码储存问题，导致再次使用时出现乱码
a = u'好好学习'
b = u'天天向上'

字符串前面加‘b’，表示该字符串是bytes类型
print(type(b'aaa'))     # <class 'bytes'>
print(type('aaa'))      # <class 'str'>

字符串前面加‘r’，表示去掉字符串中反斜杠的转义机制
print(r'\n\b\t')        # \n\b\t
print('\n\b\t')

在字符串前边加上‘f’表示字符串中可以使用{}括起来的变量
a = '今天'
b = '晴天'
print(f"{a}是{b}")       # 今天是晴天
```



参考：

https://zhuanlan.zhihu.com/p/497988788

https://www.runoob.com/python/python-files-io.html



