---
title: python 脚本编写
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 100
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
  - 语言
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter


---

<!--more-->

# requests问题解决

- request超时error Read timed out. 可以尝试：
  - `headers={'Connection':'close'}`
  - try  except语句

- 写脚本的时候在前面加一行`requests.packages.urllib3.disable_warnings()`可以去掉requests 警告：InsecureRequestWarning: Unverified HTTPS request is being made.
- verify=False可以忽略ssl验证（https）



# 进制转换

## int 转10

```python
s = '1001'
print(int(s,2)) #二进制转10进制
print(int(s,8)) #八进制转10进制
print(int(s,16)) #十六进制转10进制
```



## hex 转16

```python
print(hex(1033)) #十进制转十六进制
```



## bin 转2

```python
print(bin(10)) #十进制转二进制
```



## oct 转8

```python
print(oct(100))
```



# 格式化

## format

关键字

```python
print('{name} is {age} years old!'.format(name='xiaoming',age=10))
输出: xiaoming is 10 years old!
```

位置

```python
print('{0} is {1} years old'.format('xiaohua','21'))
# 输出: xiaohua is 21 years old
```

精度

```python
print('{:.1f}'.format(4.234324525254))
print('{:.4f}'.format(4.1))
# 输出
4.2
4.1000
```





## %

> 进制

%o ——八进制

%d ——十进制

%x ——十六进制

```python
>>> print('%o' % 20)
24
>>> print('%d' % 20)
20
>>> print('%x' % 20)
14
```



> 浮点数

%f ——保留小数点后面六位有效数字
%.3f ——保留小数点后面三位有效数字
%e ——保留小数点后面六位有效数字,科学计数法输出
%.3e ——保留3位小数位,科学计数法输出
%g ——在保证六位有效数字的前提下,使用小数方式,否则使用科学计数法
%.3g保留3位有效数字,使用小数或科学计数法

```python
print("%.2f"%m)
```





# ZipFile

常用于批量处理压缩包、解压目录穿越

```python
import requests
import zipfile

z = zipfile.ZipFile(f'test.zip', 'w', zipfile.ZIP_DEFLATED)
z.writestr(f'../../../test.txt', b'qwe')
z.close()

url = 'http://x.x.x.x:8888/file-unarchiver'
files = [('file', ('test.tar.gz', open('test.zip', 'rb'), 'application/zip'))]
resp = requests.post(url, files=files)
```





# binascii

读取文件的16进制

```python
import binascii

def read_hex_file(file_path):
    with open(file_path, 'rb') as file:
        hex_data = binascii.hexlify(file.read())
        return hex_data.decode('utf-8')

# 替换为你要读取的文件路径
file_path = 'data'
hex_data = read_hex_file(file_path)
print(hex_data)

```





# argparse  解析命令行选项

为了解析命令行选项，你首先要创建一个 `ArgumentParser` 实例， 并使用 `add_argument()` 方法声明你想要支持的选项。 在每个 `add_argument()` 调用中，`dest` 参数指定解析结果被指派给属性的名字。 `metavar` 参数被用来生成帮助信息。`action` 参数指定跟属性对应的处理逻辑， 通常的值为 `store` ,被用来存储某个值或将多个参数值收集到一个列表中。 下面的参数收集所有剩余的命令行参数到一个列表中。在本例中它被用来构造一个文件名列表：

```
parser.add_argument(dest='filenames',metavar='filename', nargs='*')
```

下面的参数根据参数是否存在来设置一个 `Boolean` 标志：

```
parser.add_argument('-v', dest='verbose', action='store_true',
                    help='verbose mode')
```

下面的参数接受一个单独值并将其存储为一个字符串：

```
parser.add_argument('-o', dest='outfile', action='store',
                    help='output file')
```

下面的参数说明允许某个参数重复出现多次，并将它们追加到一个列表中去。 `required` 标志表示该参数至少要有一个。`-p` 和 `--pat` 表示两个参数名形式都可使用。

```
parser.add_argument('-p', '--pat',metavar='pattern', required=True,
                    dest='patterns', action='append',
                    help='text pattern to search for')
```

最后，下面的参数说明接受一个值，但是会将其和可能的选择值做比较，以检测其合法性：

```
parser.add_argument('--speed', dest='speed', action='store',
                    choices={'slow','fast'}, default='slow',
                    help='search speed')
```

一旦参数选项被指定，你就可以执行 `parser.parse()` 方法了。 它会处理 `sys.argv` 的值并返回一个结果实例。 每个参数值会被设置成该实例中 `add_argument()` 方法的 `dest` 参数指定的属性值。

还很多种其他方法解析命令行选项。 例如，你可能会手动的处理 `sys.argv` 或者使用 `getopt` 模块。 但是，如果你采用本节的方式，将会减少很多冗余代码，底层细节 `argparse` 模块已经帮你处理了。 你可能还会碰到使用 `optparse` 库解析选项的代码。 尽管 `optparse` 和 `argparse` 很像，但是后者更先进



`nargs`参数用于指定命令行参数的数量。它可以接受以下几种不同的取值：

1. `nargs=None`（默认值）：表示参数接受一个值，并将其存储为单个值。这是默认的行为。
2. `nargs='?'`：表示参数可以接受零个或一个值。如果命令行中没有提供该参数，则使用默认值（如果已设置），否则将其存储为一个值。
3. `nargs='*'`：表示参数可以接受零个或多个值。命令行中提供的所有值将被存储为列表。
4. `nargs='+'`：表示参数必须接受一个或多个值。命令行中提供的所有值将被存储为列表。
5. `nargs=N`：其中N是一个整数值。表示参数必须接受N个值。命令行中提供的所有值将被存储为列表。



下面一个简单例子演示了最基本的用法：

```python
# search.py
'''
Hypothetical command-line tool for searching a collection of
files for one or more text patterns.
'''
import argparse
parser = argparse.ArgumentParser(description='Search some files')

parser.add_argument(dest='filenames',metavar='filename', nargs='*')

parser.add_argument('-p', '--pat',metavar='pattern', required=True,
                    dest='patterns', action='append',
                    help='text pattern to search for')

parser.add_argument('-v', dest='verbose', action='store_true',
                    help='verbose mode')

parser.add_argument('-o', dest='outfile', action='store',
                    help='output file')

parser.add_argument('--speed', dest='speed', action='store',
                    choices={'slow','fast'}, default='slow',
                    help='search speed')

args = parser.parse_args()

# Output the collected arguments
print(args.filenames)
print(args.patterns)
print(args.verbose)
print(args.outfile)
print(args.speed)
```

该程序定义了一个如下使用的命令行解析器：

```python
python3 search.py -h
usage: search.py [-h] [-p pattern] [-v] [-o OUTFILE] [--speed {slow,fast}]
                 [filename [filename ...]]

Search some files

positional arguments:
  filename

optional arguments:
  -h, --help            show this help message and exit
  -p pattern, --pat pattern
                        text pattern to search for
  -v                    verbose mode
  -o OUTFILE            output file
  --speed {slow,fast}   search speed
```

# pty





# socket





# 字符串处理

## ord

ascii值

## len

返回字符串、列表、字典、元组等长度



## split

语法：str.split(str="",num=string.count(str))[n]

参数说明：
str:表示为分隔符，==默认为空格==，但是不能为空(’’)。若字符串中没有分隔符，则把整个字符串作为列表的一个元素
num:表示分割次数。如果存在参数num，则仅分隔成 num+1 个子字符串，并且每一个子字符串可以赋给新的变量

n:表示选取第n个分片

注意：当使用空格作为分隔符时，对于中间为空的项会自动忽略

```python
input().split()
```



## 去掉换行和空格

```python
"···xyz···".strip()            # returns "xyz"  
"···xyz···".lstrip()           # returns "xyz···"  
"···xyz···".rstrip()           # returns "···xyz"  
"··x·y·z··".replace(' ', '')   # returns "xyz" 
```



## 替换

Python replace() 方法把字符串中的 old（旧字符串） 替换成 new(新字符串)，如果指定第三个参数max，则替换不超过 max 次。

```python
str.replace(old, new[, max])
```

- old -- 将被替换的子字符串。
- new -- 新字符串，用于替换old子字符串。
- max -- 可选字符串, 替换不超过 max 次



## string（爆破）

letters = string.printable

```python
print(letters = string.printable)
0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
```





## count

```
str.count(sub, start= 0,end=len(string))
```

- sub -- 搜索的子字符串
- start -- 字符串开始搜索的位置。默认为第一个字符,第一个字符索引值为0。
- end -- 字符串中结束搜索的位置。字符中第一个字符的索引为 0。默认为字符串的最后一个位置。

该方法返回子字符串在字符串中出现的次数。

## dedupe

消除重复元素

```
>>> a = [1, 5, 2, 1, 9, 1, 5, 10]
>>> list(dedupe(a))
[1, 5, 2, 9, 10]
```





## replace

Python replace() 方法把字符串中的 old（旧字符串） 替换成 new(新字符串)，如果指定第三个参数max，则替换不超过 max 次。

```python
str.replace(old, new[, max])
```

- old -- 将被替换的子字符串。
- new -- 新字符串，用于替换old子字符串。
- max -- 可选字符串, 替换不超过 max 次







## re

### match对象

Match对象是一次匹配的结果，包含匹配的很多信息

属性

| 属性    | 说明                                 |
| ------- | ------------------------------------ |
| .string | 待匹配的文本                         |
| .re     | 匹配时使用的patter对象（正则表达式） |
| .pos    | 正则表达式搜索文本的开始位置         |
| .endpos | 正则表达式搜索文本的结束位置         |

方法

| 方法      | 说明                             |
| --------- | -------------------------------- |
| .group(0) | 获得匹配后的字符串               |
| .start()  | 匹配字符串在原始字符串的开始位置 |
| .end()    | 匹配字符串在原始字符串的结束位置 |
| .span()   | 返回(.start(), .end())           |



### 主要方法

| 函数          | 说明                                                         |
| ------------- | ------------------------------------------------------------ |
| re.search()   | 从一个字符串中搜索匹配正则表达式的==第一个==位置，返回match对象 |
| re.match()    | 从一个字符串的开始位置起匹配正则表达式，返回match对象        |
| re.findall()  | 搜索字符串，以==列表==类型返回==全部==能匹配的子串           |
| re.split()    | 将一个字符串按照正则表达式匹配结果进行==分割==，返回==列表==类型 |
| re.finditer() | 搜索字符串，返回一个匹配结果的迭代类型，每个迭代元素是match对象 |
| re.sub()      | 在一个字符串中替换所有匹配正则表达式的子串，返回替换后的字符串 |

### 正则表达式

| 操作符 | 说明                             | 实例                                      |
| ------ | -------------------------------- | ----------------------------------------- |
| .      | 表示任何单个字符（默认除换行符） |                                           |
| []     | 字符集，对单个字符给出取值范围   | [abc]表示a、b、c，[a-z]表示a到z的单个字符 |
| [^]    | 非字符集，对单个字符给出排除范围 | [^abc]表示非a或非b或非c的单个字符         |
| *      | 前一个字符0次或无限次扩展        | abc*表示ab、abc、abcc、abccc等            |
| +      | 前一个字符1次或无限次扩展        | abc+表示abc、abcc、abccc等                |
| ?      | 前一个字符0次或1次扩展           | abc*表示ab、abc                           |
| \|     | 左右表达式任意一个               | abc\|def表示abc、def                      |
| {m}    | 扩展前一个字符m次                | ab{2}c表示abbc                            |
| {m,n}  | 扩展前一个字符m至n次（含n）      | ab{1,2}c表示abc,abbc                      |
| ^      | 匹配字符串开头                   | abc且在一个字符串的开头                   |
| $      | 匹配字符串结尾                   | abc且在一个字符串的结尾                   |
| ()     | 分组标记，内部只能使用\|操作符   | (abc)表示abc,(abc\|def)表示abc、def       |
| \d     | 数字，等价于[0-9]                |                                           |
| \w     | 单词字符，等价于[A-Za-z0-9_]     |                                           |

**经典实例**

| 正则表达式               | 意义                          |
| ------------------------ | ----------------------------- |
| ^[A-Za-z]+$              | 由26个字母组成的字符串        |
| ^[A-Za-z0-9]+$           | 由26个字母和数字组成的字符串  |
| ^-?\d+$                  | 整数形式的字符串              |
| ^ [1-9]\*[0-9]\*$        | 正整数形式的字符串            |
| [1-9]\d{5}               | 中国境内邮政编码，6位         |
| [\u4e00-\u9fa5]          | 匹配中文字符                  |
| \d{3}-\d{8}\|\d{4}-\d{7} | 国内电话号码 3位-8位或4位-7位 |









# 编码

str1.decode('utf-8')





# 排序

## sorted

对列表排序

```python
list = [1, 2 ,5, 7, 2, 4]
print(sorted(list))

Output：
[1, 2, 2, 4, 5, 7]

list = ['d', 'c', 'f', 'a', 'z']
print(sorted(list))

Output：
['a', 'c', 'd', 'f', 'z']

list = ['vz', '1bf', 'gc', 'ak', '2qz']#若为字符串，则跟据第一位的数字-字母顺序来排列
print(sorted(list))

Output：
['1bf', '2qz', 'ak', 'gc', 'vz']

```



# 数据类型



python有6大数据类型:Numbers（数字）String（字符串）List（列表）Tuple（元组）Dictionary（字典）Set（集合）

> 不可变数据（3 个）：Number（数字）、String（字符串）、Tuple（元组）；
> 可变数据（3 个）：List（列表）、Dictionary（字典）、Set（集合）。

> 列表[ ]（list）：有序可改变集合，允许重复数据。
> 元组( )（tuple）：有序不可改变集合，允许重复数据。
> 集合{ }（set）：无序无索引（索引为键值）集合，无重复数据。
> 字典{ }（dictionary）：无序，可变，有索引集合，无重复数据。

> 转换
>
> int(x) 
>
> float(x)
>
> str(x)
>
> tuple(s)
>
> list(s)
>
> set(s)
>
> dict()



## set-转换为集合

```python
list=['1','1']
print(set(list))

{'1'}
```



## 列表转字符串

```python
my_list = ['apple', 'banana', 'orange']
my_string = ''.join(my_list)
print(my_string)
```

```python
for i in list:
  print(i,end="")
```





# 切片

切片可以应用于任何序列类型，切片的索引是从0开始的。如果你想要获取从第二个元素到第四个元素，应该使用切片`my_list[1:4]`，而不是`my_list[2:4]`。

```
sequence[start:stop:step]
```

其中，`start` 表示起始位置（默认为 0），`stop` 表示结束位置（默认为序列的长度），`step` 表示步长（默认为 1）。

例如，对于一个列表 `my_list`，可以使用以下语法来获取前 3 个元素：

```
my_list[:3]
```

如果要获取从第 3 个元素到第 6 个元素（不包括第 6 个元素），可以使用以下语法：

```
my_list[2:5]
```

如果要获取从第 1 个元素到最后一个元素，可以省略 `stop` 参数：

```
my_list[1:]
```

如果要获取从第 2 个元素到倒数第 2 个元素，可以使用以下语法：

```
my_list[1:-1]
```

如果要以步长为 2 获取所有元素，可以使用以下语法：

```
my_list[::2]
```

需要注意的是，切片语法中的 `stop` 参数所指定的位置是不包括在切片结果中的。因此，如果要获取所有元素，可以省略 `start` 和 `stop` 参数，而只指定步长。

切片也可以用于字符串和元组等序列类型，语法和使用方法与列表类似。





# 精确浮点数运算

```python
>>> from decimal import Decimal
>>> a = Decimal('4.2')
>>> b = Decimal('2.1')
>>> a + b
Decimal('6.3')
>>> print(a + b)
6.3
>>> (a + b) == Decimal('6.3')
True
```



# json







