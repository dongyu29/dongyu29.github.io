---
title: linux-目录和文件
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 84
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
  - 操作系统
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

# 目录角度看文件结构

```php
目录	预期的内容
/bin	二进制文件，存放了基本的指令，依据先后顺序。
/sbin	超级管理员专用指令，依据先后顺序。
/usr	用户安装的软件和文件。
/usr/bin	也存放指令，依据先后顺序。
/usr/sbin	也存放指令，依据先后顺序。
/usr/local/	系统用户级管理员在本机自行安装自己下载的软件。
/root	系统管理员用户root主目录。
/home	除root用户的所有用户文件存储在这里，命名为其用户名。
/proc	进程信息，虚拟目录，实际上为内存的映射，不占据空间，可用于获取进程的信息，修改会发生作用。
/etc	主要放所有的系统管理所需要的配置文件和子目录。
/tmp	存放系统产生的临时文件，这个目录任何人都能访问并且创建数据。
/var	存放程序、缓存、登陆文件、系统日志文件，主要是经常被修改的那些。
/var/log/	重要日志。
/boot	Linux启动相关的文件。
/dev	存放Linux的外部设备(Device)，操控方法和文件相同，使用需要挂载。
/mnt	外部设备挂载时，将设备(有自己的文件系统)挂载在mnt当中。
/lib	基本的动态链接共享库。
/sys	一个虚拟文件系统，记录与内核相关的信息。
/lost+found	非正常关机产生的文件。
/opt	一些大型的或第三方的软件放置目录
/media	软盘、光盘等设备。
/srv	网络服务启动后所需要的数据目录。
…	…
```



# 关键文件
- `/etc/passwd`

  ```
  /etc/passwd中一行记录对应着一个用户，每行记录又被冒号(:)分隔为7个字段，其格式和具体含义如下：
  root:x:0:0:root:/root:/bin/bash
  用户名:口令:用户标识号:组标识号:注释性描述:主目录:登录Shell
  
  第一个参数（root）：用户名称。
  第二个参数（x）：密码。x代表有密码，密码存储在/etc/shadow文件中。若此参数为空，则代表不用密码就可以登录此用户。
  第三个参数（0）：用户ID（UID）。0：超级用户 UID。1~499：系统用户UID。500 ~ 65535：普通用户 UID。
  第四个参数（0）：用户组ID（GID）。
  第五个参数 （root）:用户的简单说明。可为空。
  第六个参数（/root）：用户家目录。用户登录后具有操作权限的访问目录。
  第七个参数（/bin/bash）：用户登录shell。/bin/bash为可登录系统的shell，/sbin/nologin为禁止登录的shell（很多系统用户为禁止登录shell）。
  
  所有用户都可读，只有root用户可写
  ```

  写入/etc/passwd

  ```
  使用openssl passwd -1 生成加密的密码：-1表示使用MD5算法对密码redhat进行加密
  openssl passwd -1 -salt demon 123456
  echo 'demon:$1$demon$Mspg7FhbFwGLZ4T2s/qI6/:0:0:root:/bin/bash' >> /etc/pas
  ```

  

- `/etc/shadow`

  ```
  /etc/shadow 文件，用于存储 Linux 系统中用户的密码信息，又称为“影子文件”。
  
  前面介绍了 /etc/passwd 文件，由于该文件允许所有用户读取，易导致用户密码泄露，因此 Linux 系统将用户的密码信息从 /etc/passwd 文件中分离出来，并单独放到了此文件中。
  ```

  

- `$PATH`

  ```
   系统会按照PATH定义的目录搜索可执行文件，以分号分割。
  修改后，需要重启生效。
  $PATH中添加./很危险。
  /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
  env命令可查看终端的全部环境变量。
  ```

  

- `/etc/hosts`

  ```
  包含了IP地址、域名和主机别名间的映射关系，可以获得内网的一些主机信息，可以为SSRF提供便利。
  网络IP 主机名/域名 主机别名
  ```

  

- `/etc/issue`

  ```
  /etc/issue是一个用于显示系统信息的文件，通常位于Linux系统的根目录下。它可以包含系统的版本、发行版、内核信息等内容
  内网渗透常用
  ```

- `/etc/knockd.conf`

  端口敲门

  这个讲的很好https://blog.csdn.net/nzjdsds/article/details/112476120
  
  ```
  端口敲门服务，即：knockd服务。该服务通过动态的添加iptables规则来隐藏系统开启的服务，使用自定义的一系列序列号来“敲门”，使系统开启需要访问的服务端口，才能对外访问。不使用时，再使用自定义的序列号来“关门”，将端口关闭，不对外监听。进一步提升了服务和系统的安全性。
  
  敲门：for x in 7000 8000 9000;do nmap -Pn --max-retries 0 -p $x 192.168.61.135;done
  甚至依次 nmap ip -p portye'kje'y
  ```
  
- `/etc/profile`

  ```
  在/etc/profile文件中修改环境变量，在这里修改的内容是对所有用户起作用的。
  ```

  | 项                                                           | 描述                   |
  | :----------------------------------------------------------- | :--------------------- |
  | **/etc/passwd**                                              | 包含基本用户属性。     |
  | [**/usr/lib/security/mkuser.default**](https://www.ibm.com/docs/zh/ssw_aix_73/filesreference/mkuser.default.html#mkuser.default) | 包含新用户的缺省属性。 |
  | [**/etc/group**](https://www.ibm.com/docs/zh/ssw_aix_73/filesreference/group_security.html#group_security) | 包含组的基本属性。     |
  | [**/etc/security/group**](https://www.ibm.com/docs/zh/ssw_aix_73/filesreference/group.html#group) | 包含组的扩展属性。     |
  | [**/etc/security/passwd**](https://www.ibm.com/docs/zh/ssw_aix_73/filesreference/passwd_security.html#passwd_security) | 包含密码信息。         |
  | [**/etc/security/user**](https://www.ibm.com/docs/zh/ssw_aix_73/filesreference/user.html#user) | 包含用户的扩展属性。   |
  | [**/etc/security/environ**](https://www.ibm.com/docs/zh/ssw_aix_73/filesreference/environ.html#environ) | 包含用户的环境属性。   |
  | [**/etc/security/limits**](https://www.ibm.com/docs/zh/ssw_aix_73/filesreference/limits.html#limits) | 包含用户进程资源限制。 |

# 环境变量

```
PATH：决定了shell将到哪些目录中寻找命令或程序

HOME：当前用户主目录

MAIL：是指当前用户的邮件存放目录。

SHELL：是指当前用户用的是哪种Shell。

HISTSIZE：是指保存历史命令记录的条数。

LOGNAME：是指当前用户的登录名。

HOSTNAME：是指主机的名称，许多应用程序如果要用到主机名的话，通常是从这个环境变量中来取得的。

LANG/LANGUGE：是和语言相关的环境变量，使用多种语言的用户可以修改此环境变量。

PS1：是基本提示符，对于root用户是#，对于普通用户是$。

PS2：是附属提示符，默认是“>”。
```







# 程序环境变量
进程 `/proc/$PID/environ`

表示的是运行时进程的环境变量，其中一个特殊的是/proc/self/，它等价于/proc/自己的PID/environ，适用于某个进程获取自己的IP，以适应不同用户不同PID，或PID发生变化的情况。

pgrep命令可查看进程相关的PID，如

```
$ pgrep nginx
1111
18888
23333
```

export设置临时的环境变量，修改配置文件为永久修改。



----



# Web服务器重要文件
Apache

```php
/etc/apache2/apache2.conf	# 主配置文件
/etc/apache2/site-available/000-defaut.con  # 网站站点根目录配置文件
/etc/apache2/sites-enabled  # apache2正在使用的网站配置文件
/etc/apache2/site-available # apache2可用的网站配置文件
/var/www/html/ 				# 默认根目录
/var/log/apache2/access.log # Apache服务器的访问日志文件 
/var/log/apache2/error.log 	# Apache服务器的错误日志文件
```


nginx

```php
/var/log/nginx		# 日志默认存放位置
/etc/nginx/conf/nginx.conf		# 主配置文件
/usr/local/nginx/conf/nginx.conf	# 配置文件
/var/log/nginx/access.log		# 访问日志
/var/log/nginx/error.log		# 错误日志
/usr/local/var/log/nginx/access.log # 没看到？？
```


PHP
`/www/server/php/版本/etc/php.ini`



# Proc 目录在 CTF 中的利用

在 CTF 中经常会用到 `/proc` 这个目录来进行绕过，利用它里面的一些子目录或文件读取网站源码或者环境信息等，甚至直接读取flag或者直接Getshell。

| cmdline |           获取启动指定进程的完整命令           |
| :-----: | :--------------------------------------------: |
|   cwd   |        获取目标指定进程环境的`运行目录`        |
|   exe   |      获得指定进程的`可执行文件的完整路径`      |
| environ |          获取`指定进程的环境变量信息`          |
|   fd    | 获得`指定进程打开的每个文件的路径以及文件内容` |



## /proc 目录

Linux系统上的/proc目录是一种文件系统，即proc文件系统。与其它常见的文件系统不同的是，/proc 是一种伪文件系统（也即虚拟文件系统），存储的是当前内核运行状态的一系列特殊文件，用户可以通过这些文件查看有关系统硬件及当前`正在运行进程的信息`，甚至可以通过更改其中某些文件来改变内核的运行状态。

简单来讲，`/proc` 目录即保存在系统内存中的信息，大多数虚拟文件可以使用文件查看命令如cat、more或者less进行查看，有些文件信息表述的内容可以一目了然，但也有文件的信息却不怎么具有可读性。

/proc 目录中包含许多以数字命名的子目录，这些数字表示系统当前正在运行进程的进程号(PID)，里面包含对应进程相关的多个信息文件：

```
ls -al /proc
```

![image-20220530222553170](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112334.png)

下面我们简单介绍一下 `/proc` 目录中的常见文件夹与文件。

上面列出的是 /proc 目录中一些进程相关的目录，每个目录中是其进程本身相关信息的文件。下面是系统上运行的一个PID为11的进程的相关文件，其中有些文件是每个进程都会具有的：

```
ls -al /proc/11
```

![image-20220530222849639](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112329.png)

这里简单讲几个与题目相关的进程文件：

### cmdline

cmdline 文件存储着启动当前进程的完整命令，但僵尸进程目录中的此文件不包含任何信息。可以通过查看cmdline目录获取`启动指定进程的完整命令`：

```
cat /proc/1/cmdline
```

![image-20220530223141042](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112325.png)

可知PID为1的进程的启动命令为`/init`。

### cwd

cwd 文件是一个指向当前进程运行目录的符号链接。可以通过查看cwd文件获取目标指定进程环境的`运行目录`：

```
ls -al /proc/1/cwd
```

![image-20220530223354747](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112320.png)

可见PID为1的进程的运行目录为`/`，然后我们可以直接使用`ls`目录查看该进行运行目录下的文件：

```
ls /proc/1/cwd
```

![image-20220530223755196](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112030.png)

如上图所示，与直接查看`/`目录的效果是一样的。

### exe

exe 是一个指向启动当前进程的可执行文件（完整路径）的符号链接。通过exe文件我们可以获得指定进程的`可执行文件的完整路径`：

```
ls -al /proc/1/exe
```

![image-20220530223952567](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112016.png)

### environ

environ 文件存储着当前进程的环境变量列表，彼此间用空字符（NULL）隔开。变量用大写字母表示，其值用小写字母表示。可以通过查看environ目录来获取`指定进程的环境变量信息`：

```
cat /proc/1/environ
```

![image-20220530224329815](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img/20220531111309.png)

常用来读取环境变量中的`SECRET_KEY或FLAG`。

### fd

fd 是一个目录，里面包含这当前进程打开的每一个文件的文件描述符（file descriptor），这些文件描述符是指向实际文件的一个符号链接，即每个通过这个进程打开的文件都会显示在这里。所以我们可以通过fd目录里的文件获得`指定进程打开的每个文件的路径以及文件内容`。

查看指定进程打开的某个文件的路径：

```
ls -al /proc/1/fd
```

![image-20220530224447949](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img/20220531111230.png)

查看指定进程打开的某个文件的内容：

```
cat /proc/1/fd/3
```

![image-20220530224606017](https://testingcf.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img/20220531110119.png)

==这个fd比较重要，因为在 linux 系统中，如果一个程序用 **open()** 打开了一个文件但最终没有关闭他，即便从外部（如os.remove(SECRET_FILE)）删除这个文件之后，在 /proc 这个进程的 pid 目录下的 fd 文件描述符目录下还是会有这个文件的文件描述符，通过这个文件描述符我们即可得到被删除文件的内容。==

### self

上面这些操作列出的都是目标环境指定进程的信息，但是我们在做题的时候往往需要的`当前进程的信息`，这时候就用到了 `/proc` 目录中的 self 子目录。

`/proc/self` 表示当前进程目录。前面说了通过 `/proc/$pid/` 来获取指定进程的信息。如果某个进程想要获取当前进程的系统信息，就可以通过进程的pid来访问/proc/$pid/目录。但是这个方法还需要获取进程pid，在fork、daemon等情况下pid还可能发生变化。为了更方便的获取本进程的信息，linux提供了 `/proc/self/` 目录，这个目录比较独特，不同的进程访问该目录时获得的信息是不同的，内容等价于 `/proc/本进程pid/` 。进程可以通过访问 `/proc/self/` 目录来获取自己的系统信息，而不用每次都获取pid。

有了self目录就方便多了，下面我们演示一下self的常见使用。

- 获取当前启动进程的完整命令：

```
cat /proc/self/cmdline
```

![image-20220530224825090](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112419.png)

- 获取目标当前进程环境的运行目录与目录里的文件：

```
ls -al /proc/self/cwd
ls /proc/self/cwd
```

![image-20220530224946632](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112417.png)

当不知道目标网站的Web路径或当前路径时，这经常使用

- 获得当前进程的可执行文件的完整路径：

```
ls -al /proc/self/exe
```

![image-20220531112528384](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112529.png)

- 获取当前进程的环境变量信息：

```
cat /proc/self/environ
```

![image-20220531112551693](https://cdn.jsdelivr.net/gh/JOHN-FROD/PicGo/blog-img2/20220531112552.png)

- 获取当前进程打开的文件内容：

```
cat /proc/self/fd/{id}
```

**注意：**在真正做题的时候，我们是不能通过命令的方式执行通过`cat`命令读取cmdline的，因为如果是`cat`读取/proc/self/cmdline的话，得到的是cat进程的信息，所以我们要通过题目的当前进程使用读取文件（如文件包含漏洞，或者SSTI使用file模块读取文件）的方式读取/proc/self/cmdline。
