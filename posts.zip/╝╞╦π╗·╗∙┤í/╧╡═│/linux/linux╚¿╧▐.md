---
title: linux-权限学习
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 85
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
  - 操作系统
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

# 使用者和群组

通常情况下，一个文件只能归属于一个用户和组， 如果其它的用户想有这个文件的权限，则可以将该用户加入具备权限的群组，==一个用户可以同时归属于多个组==。

- 文件所有者

Linux 是一个多用户多任务系统，多用户就意味着有些用户创建的文件是否对其他用户可见，这是一种可见性问题，同时也是一种隐私性问题，为了考虑到每个人的隐私权，Linux 设计了文件所有者的角色。如果你有一些资料和文件的隐私性比较高，你就可以把文件设置成 "只有我自己可见" ，这就是文件所有者的作用。

- 群组

群组的这个概念用在团队开发中，用处比较多的就是为项目设置权限，比如你就职于一个银行的外包部门，你和其他外包部门共同为某个银行服务，所有的外包团体都使用一台服务器，这就会涉及到群组权限的问题，你们外包部门开发的项目不想让其他外包部门所看到，就会把该项目设置成群组可见。但是银行是总负责人，所有银行具有查看你们所有外包部门项目的权限，因此，你还需要设置银行的权限。

- 其他人所属

其他人和群组是相对的，其他人在群组之外，没有权限查看群组内文件的一种权限关系。

除了上面三个概念之外，还有一个权限级别最高的大佬，它就是 root，这个 root 权限是最高的。

> 当一个用户创建一个文件时，该文件的所有权和所属组将与创建者的用户ID和组ID相关联。如果在创建文件a时，用户test属于用户组A，那么文件a将被分配给用户组A作为其所属组。但是，当用户test被移动到另一个用户组B时，文件a的所属组不会自动更改。文件a仍然保持原来的所属组A

# Linux 文件权限

在聊完上面使用者和群组的概念之后，接下来我们就来谈一下文件权限要如何设置的问题，这块内容是很重要的，因为这部分内容是很好解决 permission denied 问题的关键。

## 权限属性

### 十位权限

首先登录 Linux 系统，使用 su - 可以切换成为 root 身份，然后执行 ls -al 会看到下面这些

从左到右的列依次是权限、链接、所属人、所属群组、文件大小、修改日期、文件名

![image-20230719204217662](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307192042024.webp)



权限用10个字符表示，如`drwxr-xr-x`

- 第一个字符代表文件类型

  d代表的是目录(directroy)
  -代表的是文件(regular file)
  s代表的是套字文件(socket)
  p代表的管道文件(pipe)或命名管道文件(named pipe)
  l代表的是符号链接文件(symbolic link)
  b代表的是该文件是面向块的设备文件(block-oriented device file)
  c代表的是该文件是面向字符的设备文件(charcter-oriented device file)

- 剩下的9个字符三个一组分别表示文件所有者权限，文件群组权限，其他所有者权限



Linux下文件的权限类型一般包括

读，写，执行 对应字母为 r、w、x，如果是横杠-则代表没有这项权限



## 数字权限

规定 数字 4 、2 和 1表示读、写、执行权限

即 r=4，w=2，x=1 

此时其他的权限组合也可以用其他的八进制数字表示出来，如：

```
rwx = 4 + 2 + 1 = 7
rw = 4 + 2 = 6
rx = 4 +1 = 5
```

即

若要同时设置 rwx (可读写运行） 权限则将该权限位 设置 为 4 + 2 + 1 = 7

若要同时设置 rw- （可读写不可运行）权限则将该权限位 设置 为 4 + 2 = 6

若要同时设置 r-x （可读可运行不可写）权限则将该权限位 设置 为 4 +1 = 5



### 十二位权限-linux附加权限

> 设置了SUID权限的权限的值是4000（八进制表示）。这指示当用户执行该文件时，将使用文件的所有者的权限而不是执行用户的权限。

linux除了设置正常的读写操作权限外，还有关于一类设置也是涉及到权限，叫做Linxu附加权限。包括 ==SET位权限（suid，sgid）==和==粘滞位权限（sticky）==，前者是放松，后者是限制。

> **SET位权限：**
>
> suid/sgid是为了使“没有取得特权用户要完成一项必须要有特权才可以执行的任务”而产生的。
>
> 一般用于给可执行的程序或脚本文件进行设置，其中SUID表示对==属主用户==增加SET位权限，SGID表示对==属组内用户==增加SET位权限。
>
> 执行文件被设置了SUID、SGID权限后，==任何用户执行该文件时，将获得该文件属主、属组账号对应的身份==。
>
> suid(set User ID,set UID)的意思是进程执行一个文件时通常保持进程拥有者的UID。然而，如果设置了可执行文件的suid位，进程就获得了该文件拥有者的UID。
>
> sgid(set Group ID,set GID)意思也是一样，只是把上面的进程拥有者改成了文件拥有组（group）。
> 在许多场景下，使用suid 和 sgid 非常实用，但是不恰当地使用这些权限可能为系统带来安全风险。所以应该尽量避免使用SET位权限程序。（passwd 命令是为数不多的必须要使用“suid”的命令之一）。



>**粘滞位权限：**
>
>粘滞位权限即sticky。一般用于为目录设置特殊的附加权限，==当目录被设置了粘滞位权限后，即便用户对该目录有写的权限，也不能删除该目录中其他用户的文件数据==。设置了粘滞位权限的目录，是用ls查看其属性时，其他用户权限处的x将变为t。 使用chmod命令设置目录权限时，+t、-t权限模式可分别用于添加、移除粘滞位权限。
>
>粘滞位权限表示形式（10位权限）：
>
>一个文件或目录被设置了粘滞位权限，会表现在其他组用户的权限的可执行位上。如果文件设置了sticky还设置了x（执行）位，其他组用户的权限的可执行位为t(小写)。但是，如果没有设置x位，它将表示为T(大写)。如：
>
>```
>1、-rwsr-xr-t 表示设置了粘滞位且其他用户组有可执行权限
>
>2、-rwSr--r-T 表示设置了粘滞位但其他用户组没有可执行权限
>```
>
>设置方式：
>
>sticky权限同样可以通过chmod命令设置：
>
>```
>chmod +t <文件列表..>
>```

---



#### SET位权限表示形式（10位权限）

如果一个文件被设置了suid或sgid位，会==分别表现在所有者或同组用户的权限的可执行位上==；如果文件设置了suid还设置了x（执行）位，则相应的执行位表示为s(小写)。但是，如果没有设置x位，它将表示为S(大写)。如：

```
1、-rwsr-xr-x 表示设置了suid，且拥有者有可执行权限
2、-rwSr--r-- 表示suid被设置，但拥有者没有可执行权限
3、-rwxr-sr-x 表示sgid被设置，且群组用户有可执行权限
4、-rw-r-Sr-- 表示sgid被设置，但群组用户没有可执行权限
```

设置方式：

SET位权限可以通过chmod命令设置，给文件加suid和sgid的命令如下(类似于上面chmod赋予一般权限的命令)：
```
chmod u+s filename 	设置suid位
chmod u-s filename 	去掉suid设置
chmod g+s filename 	设置sgid位
chmod g-s filename 	去掉sgid设置
```



---

#### 十二位权限表示方法

附加权限除了用十位权限形式表示外，还可以用用十二位字符表示。

```
11 10 9 8 7 6 5 4 3 2 1 0
S  G  T r w x r w x r w x
```

SGT分别表示SUID权限、SGID权限、和 粘滞位权限，这十二位分别对应关系如下：

第11位为SUID位，第10位为SGID位，第9位为sticky位，第8-0位对应于上面的三组rwx位（后九位）。

在这十二位的每一位上都置值。如果有相应的权限则为1， 没有此权限则为0。

```
-rw-r-Sr-- 的值为： 0 1 0  1 1 0  1 0 0  1 0 0
-rwsr-xr-x 的值为： 1 0 0  1 1 1  1 0 1  1 0 1
-rwsr-sr-x 的值为： 1 1 0  1 1 1  1 0 1  1 0 1 
-rwsr-sr-t 的值为： 1 1 1  1 1 1  1 0 1  1 0 1
```

如果将则前三位SGT也转换成一个二进制数，则

- suid 的八进制数字是4
- sgid 的代表数字是 2
- sticky 位代表数字是1

这样我们就可以将十二位权限三位三位的转化为4个八进制数。其中

最高的一位八进制数就是suid，sgdi，sticky的权值。

第二位为 拥有者的权值

第三位为 所属组的权值

最后一位为 其他组的权值



---



#### 附加权限的八进制形式
通过上面，我们知道，正常权限和附加权限可以用4位八进制数表示。类似于正常权限的数字权限赋值模式（使用三位八进制数字赋值）

```
chmod <abc> file...
```

我们可以进一步使用4位八进制数字同时赋值正常权限和附加权限。

````
chmod <sabc> file...
````

其中s是表示附加权限的把八进制数字，abc与之前一致，分别是对应User、Group、及Other（拥有者、群组、其他组）的权限。因为SUID对应八进制数字是4，SGID对于八进制数字是2，则“4755”表示设置SUID权限，“6755”表示同时设置SUID、SGID权限。

我们进一步将上小节的例子中的二进制数转变为八进制表示形式，则

```
-rw-r-Sr-- = 0 1 0 1 1 0 1 0 0 1 0 0 = 2644 
-rwsr-xr-x = 1 0 0 1 1 1 1 0 1 1 0 1 = 4755
-rwsr-sr-x = 1 1 0 1 1 1 1 0 1 1 0 1 = 6755
-rwsr-sr-t = 1 1 1 1 1 1 1 0 1 1 0 1 = 7755
```



对比范例：

设置 netlogin 的权限为拥有者可读写执行，群组和其他权限为可读可执行

```
chmod 755 netlogin
```





设置 netlogin 的权限为拥有者可读写执行，群组和其他权限为可读可执行，并且设置suid

```
chmod 4755 netlogin

chmod 4755与chmod 755对比多了附加权限值4，这个4表示其他用户执行文件时，具有与所有者同样的权限（设置了SUID）。
```











# 权限更改-chmod

chmod命令格式

```
chmod [可选项] <mode> <file...>
```

参数

```
参数说明：
 
[可选项]
  -c, --changes     若该档案权限确实已经更改，才显示其更改动作
  -f, --silent, --quiet  若该档案权限无法被更改也不要显示错误讯息
  -v, --verbose    显示权限变更的详细资料
       --no-preserve-root  do not treat '/' specially (the default)
       --preserve-root    fail to operate recursively on '/'
       --reference=RFILE  use RFILE's mode instead of MODE values
  -R, 以递归的方式对目前目录下的所有档案与子目录进行相同的权限变更
       --help		显示此帮助信息
       --version		显示版本信息
[mode] 
    权限设定字串，详细格式如下 ：
    [ugoa...][[+-=][rwxX]...][,...]，
    其中
    [ugoa...]
    u 表示该档案的拥有者，g 表示与该档案的拥有者属于同一个群体(group)者，o 表示其他以外的人，a 表示所有（包含上面三者）。
    [+-=]
    + 表示增加权限，- 表示取消权限，= 表示唯一设定权限。
    [rwxX]
    r 表示可读取，w 表示可写入，x 表示可执行，X 表示只有当该档案是个子目录或者该档案已经被设定过为可执行。
 	
[file...]
    文件列表（单个或者多个文件、文件夹）
```



---



采用==数字方式==更改权限看起来更加简洁一些

```
chmod <abc> file...
```

其中

a,b,c各为一个数字，分别代表User、Group、及Other的权限。

相当于简化版的chmod u=权限,g=权限,o=权限 file...

而此处的权限将用8进制的数字来表示User、Group、及Other的读、写、执行权限

范例：

设置所有人可以读写及执行

```
chmod 777 file  (等价于  chmod u=rwx,g=rwx,o=rwx file 或  chmod a=rwx file)
```

设置拥有者可读写，其他人不可读写执行

```
chmod 600 file (等价于  chmod u=rw,g=---,o=--- file 或 chmod u=rw,go-rwx file )
```



# 更改文件拥有者-chown

一般只有系统管理员(root)拥有此操作权限，而普通用户则没有权限将自己或者别人的文件的拥有者设置为别人。

语法格式：

```
chown [可选项] user[:group] file...
```

```
使用权限：root
 
说明：
[可选项] : 同上文chmod
user : 新的文件拥有者的使用者 
group : 新的文件拥有者的使用者群体(group)
```



范例：

设置文件 d.key、e.scrt的拥有者设为 users 群体的 tom

```
chown tom:users file d.key e.scrt
```



设置当前目录下与子目录下的所有文件的拥有者为 users 群体的 James

```
chown -R James:users  *
```



# 目录权限

linux下每个目录的权限也是不同的，有些命令需要特定的权限下才能执行，我们可以用find命令找到特定权限的目录

```
find / -user www-data -type d
```













































