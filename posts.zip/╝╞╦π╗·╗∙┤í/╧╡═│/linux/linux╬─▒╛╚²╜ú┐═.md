---
title: linux-文本命令
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 86
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
  - 操作系统
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

> awk、grep、sed是linux操作文本的三大利器，合称文本三剑客，也是必须掌握的linux命令之一。三者的功能都是处理文本，但侧重点各不相同，其中属==awk功能最强大==，但也最复杂。==grep更适合单纯的查找或匹配文本==，==sed更适合编辑匹配到的文本==，==awk更适合格式化文本==，对文本进行较复杂格式处理。

# grep-查找或匹配文本

## 概述

Linux系统中grep命令是一种强大的文本搜索工具，它能使用**正则表达式**搜索文本，并把匹配的行打印出来（匹配到的标红）。grep全称是Global Regular Expression Print，表示全局正则表达式版本，它的使用权限是所有用户。

grep的工作方式是这样的，它在一个或多个文件中搜索字符串模板。如果模板包括空格，则必须被引用，模板后的所有字符串被看作文件名。搜索的结果被送到标准输出，不影响原文件内容。

grep可用于shell脚本，因为grep通过返回一个状态值来说明搜索的状态，如果模板搜索成功，则返回0，如果搜索不成功，则返回1，如果搜索的文件不存在，则返回2。我们利用这些返回值就可进行一些自动化的文本处理工作。

**egrep = grep -E：扩展的正则表达式** （除了**\< , \> , \b** 使用其他正则都可以去掉\）



----

## 命令格式

```shell
grep [option] pattern file
```

用于过滤/搜索的特定字符。可使用正则表达式能多种命令配合使用，使用上十分灵活。



-----

## 命令参数

常用参数已加粗

-  -A<显示行数>：除了显示符合范本样式的那一列之外，并显示该行之后的内容。
-  -B<显示行数>：除了显示符合样式的那一行之外，并显示该行之前的内容。
-  -C<显示行数>：除了显示符合样式的那一行之外，并显示该行之前后的内容。
-  ==-c：统计匹配的行数==
-  ==**-e ：实现多个选项间的逻辑or 关系**==
-  ==**-E：扩展的正则表达式**==
-  -f FILE：从FILE获取PATTERN匹配
-  -F ：相当于fgrep
-  ==-i --ignore-case #忽略字符大小写的差别。==
-  ==-n：显示匹配的行号==
-  ==-o：仅显示匹配到的字符串==
-  -q： 静默模式，不输出任何信息
-  -s：不显示错误信息。
-  ==**-v：显示不被pattern 匹配到的行，相当于[^] 反向匹配**==
-  -w ：匹配 整个单词

![image-20230718233759616](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307182337794.webp)

![image-20230718233713098](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307182337275.webp)



---

## 正则表达式

格式

-  . 匹配任意单个字符，不能匹配空行
-  [] 匹配指定范围内的任意单个字符
-  [^] 取反
-  [:alnum:] 或 [0-9a-zA-Z]
-  [:alpha:] 或 [a-zA-Z]
-  [:upper:] 或 [A-Z]
-  [:lower:] 或 [a-z]
-  [:blank:] 空白字符（空格和制表符）
-  [:space:] 水平和垂直的空白字符（比[:blank:]包含的范围广）
-  [:cntrl:] 不可打印的控制字符（退格、删除、警铃...）
-  [:digit:] 十进制数字 或[0-9]
-  [:xdigit:]十六进制数字
-  [:graph:] 可打印的非空白字符
-  [:print:] 可打印字符
-  [:punct:] 标点符号

匹配次数

-  *****  匹配前面的字符任意次，**包括0次**，贪婪模式：尽可能长的匹配
-  **.\*** 任意长度的任意字符，**不包括0次**
-  **?**  匹配其前面的字符**0 或 1次**
-  **\+** 匹配其前面的字符**至少1次**
-  \{n\}  匹配前面的字符n次
-  \{m,n\}  匹配前面的字符至少m 次，至多n次
-  \{,n\}  匹配前面的字符至多n次
-  \{n,\}  匹配前面的字符至少n次

定位位置

-  ^  行首锚定，用于模式的最左侧
-  $  行尾锚定，用于模式的最右侧
-  ^PATTERN$，用于模式匹配整行
-  ^$ 空行
-  ^[[:space:]].*$  空白行
-  \< 或 \b  词首锚定，用于单词模式的左侧
-  \> 或 \b  词尾锚定；用于单词模式的右侧
-  \<PATTERN\>

# sed-编辑匹配到的文本

## 概述

sed 是一种流编辑器，它一次处理一**行**内容。处理时，把当前处理的行存储在临时缓冲区中，称为“**模式空间**”（patternspace ），接着用sed 命令处理缓冲区中的内容，处理完成后，把缓冲区的内容送往屏幕。然后读入下行，执行下一个循环。如果没有使诸如‘D’ 的特殊命令，那会在两个循环之间清空模式空间，但不会清空**保留空间**。这样不断重复，直到文件末尾。**文件内容并没有改变**，除非你使用**重定向存储输出或-i**。

功能：主要用来自动编辑一个或多个文件, 简化对文件的反复操作

## 命令格式

```shell
sed [options] '[地址定界] command' file(s)
```



## 命令参数

[options]

-  **-n**：不输出模式空间内容到屏幕，即不自动打印，只打印匹配到的行

-  **-e：**多点编辑，对每行处理时，可以有多个Script

-  **-f**：把Script写到文件当中，在执行sed时-f 指定文件路径，如果是多个Script，换行写

-  **-r**：支持**扩展的正则**表达式

-  **-i**：直接将处理的结果写入文件

-  **-i.bak**：在将处理的结果写入文件之前备份一份

  

---



[地址定界]

-  不给地址：对全文进行处理
- 单地址：
  -  \#: 指定的行
  -  /pattern/：被此处模式所能够匹配到的每一行
- 地址范围：
  -  \#,#
  -  \#,+#
  -  /pat1/,/pat2/
  -  \#,/pat1/
- ~：步进
  -  sed -n **'1~2p'** 只打印奇数行 （1~2 从第1行，一次加2行）
  -  sed -n **'2~2p'** 只打印偶数行



---



command

-  **d：删除**模式空间匹配的行，并立即启用下一轮循环
-  **p：打印**当前模式空间内容，追加到默认输出之后
-  **a**：在指定行**后面追加**文本，支持使用\n实现多行追加
-  **i**：在行**前面插入**文本，支持使用\n实现多行追加
-  **c**：**替换**行为单行或多行文本，支持使用\n实现多行追加
-  w：保存模式匹配的行至指定文件
-  r：读取指定文件的文本至模式空间中匹配到的行后
-  =：为模式空间中的行打印行号
-  **!**：模式空间中匹配行**取反**处理
- s///：查找替换，支持使用其它分隔符，如：s@@@，s###；
  -  **加g表示行内全局替换；**
  -  在替换时，可以加一下命令，实现大小写转换
  -  \l：把下个字符转换成小写。
  -  \L：把replacement字母转换成小写，直到\U或\E出现。
  -  \u：把下个字符转换成大写。
  -  \U：把replacement字母转换成大写，直到\L或\E出现。
  -  \E：停止以\L或\U开始的大小写转换

















# awk-格式化文本

## 概述

awk是一种编程语言，用于在linux/unix下对文本和数据进行处理。数据可以来自标准输入(stdin)、一个或多个文件，或其它命令的输出。它**支持用户自定义函数**和动态正则表达式等先进功能，是linux/unix下的一个强大编程工具。它在命令行中使用，但更多是作为脚本来使用。**awk有很多内建的功能**，比如数组、函数等，这是它和C语言的相同之处，灵活性是awk最大的优势。

awk其实不仅仅是工具软件，还是一种编程语言。



## 命令格式

```
awk` `[options] ``'program'` `var=value ``file``…
awk` `[options] -f programfile var=value ``file``…
awk` `[options] ``'BEGIN{ action;… } pattern{ action;… } END{ action;… }'` `file` `...
```



## 命令参数

-  -F fs：fs指定输入分隔符，fs可以是字符串或正则表达式，如-F:
-  -v var=value：赋值一个用户定义变量，将外部变量传递给awk
-  -f scripfile：从脚本文件中读取awk命令

https://www.cnblogs.com/along21/p/10366886.html





























