---
title: linux学习
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 81
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
  - 操作系统
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

# 目录

Linux的文件系统时采用层级式的树状目录结构，在此结构中的最上层时根目录“/"

==Linux中，一切皆文件==

```
目录	预期的内容
/bin	二进制文件，存放了基本的指令，依据先后顺序。
/sbin	超级管理员专用指令，依据先后顺序。
/usr	用户安装的软件和文件。
/usr/bin	也存放指令，依据先后顺序。
/usr/sbin	也存放指令，依据先后顺序。
/usr/local/	系统用户级管理员在本机自行安装自己下载的软件。
/root	系统管理员用户root主目录。
/home	除root用户的所有用户文件存储在这里，命名为其用户名。
/proc	进程信息，虚拟目录，实际上为内存的映射，不占据空间，可用于获取进程的信息，修改会发生作用。
/etc	主要放所有的系统管理所需要的配置文件和子目录。
/tmp	存放系统产生的临时文件，这个目录任何人都能访问并且创建数据。
/var	存放程序、缓存、登陆文件、系统日志文件，主要是经常被修改的那些。
/var/log/	重要日志。
/boot	Linux启动相关的文件。
/dev	存放Linux的外部设备(Device)，操控方法和文件相同，使用需要挂载。
/mnt	外部设备挂载时，将设备(有自己的文件系统)挂载在mnt当中。
/lib	基本的动态链接共享库。
/sys	一个虚拟文件系统，记录与内核相关的信息。
/lost+found	非正常关机产生的文件。
/opt	一些大型的或第三方的软件放置目录
/media	软盘、光盘等设备。
/srv	网络服务启动后所需要的数据目录。
…	…
```



# 基础命令

## 文件目录类命令

```
pwd 显示当前目录的绝对路径
ls  -a 所有的，包括隐藏文件  -l 列表方式呈现 -h列出文件大小
cd ~  返回当前用户的home目录
mkdir 创建目录  -p创建多级目录
rmdir 删除空目录  若非空，则带上-rf参数
rm    -r递归  -f强制
touch 创建空文件
cp    拷贝文件到某目录
mv    移动
cat   -n显示行号
more   基于vi，全屏幕显示 
       空格    下一页 
       enter   下一行
       q       退出
       ctrl b   上一页
less   类似于more ，更强大       
echo   输出内容
head    -n 行数   显示文件开头内容  
tail   -n  行数   显示文件结尾内容  
>      重定向（覆盖）
>>     重定向（追加）
ln     软连接（符号链接）  ln -s 文件或目录 软连接名
history  查看执行过的历史命令  加上数字几就显示几条
         执行历史编号为5的指令   !5
```



## 时间日期类指令 data cal

```
date  时间日期
cal   日历
```



## 查找指令 find locate which grep

- find

  http://c.biancheng.net/view/779.html

  ```
  find 搜索路径 [选项] 搜索内容
  
  -name 查询文件名  -iname表示忽略大小写
  -user 用户名  查找属于某用户的所有文件
  -size 文件大小  +大于 -小于 不写 等于
  -type d 表示只查找目录 f 表示只查找文件
  -perm-权限模式
  ```

```
locate 快速定位文件路径 使用前用updatedb创建locate数据库
which  查找某个指令在哪个目录下
grep [option] pattern file 详见文本三剑客那个笔记  往往跟管道一块用
```



linux下每个目录的权限也是不同的，有些命令需要特定的权限下才能执行，我们可以用find命令找到特定权限的目录

```
find / -user www-data -type d
```

寻找特权文件

```
find / -user root -perm -4000 -print 2>/dev/null
```

整个系统找文件名

```
find / -name "*.hosts"
```





## 压缩和解压 gzip zip tar

```
gzip/gunzip
gzip 压缩文件，只能将文件压缩为*.gz文件
gunzip 文件.gz  解压文件

zip/unzip
zip [选项] XXX.zip -r 递归压缩
unzip      -d 指定解压后文件的存放目录

tar
可以打包，也可以解压，打包的文件是 .tar.gz
tar [选项] XXX.tar.gz 打包的内容
    -c    产生.tar打包文件
    -v    显示详细信息
    -f    指定压缩后的文件名
    -z    打包同时压缩
    -x    解包.tar文件
    tar -zcvf 打包
    tar -zxvf 解包
```



## 用户 user

linux系统是一个多用户多任务的操作系统，任何一个要使用系统资源的用户，都必须首先向系统管理员申请一个账号，然后以这个账号的身份进入系统

==添加用户==

```
useradd 用户名
```

当创建用户成功后，会自动创建和用户同名的home目录

也可以通过`useradd -d 指定目录 用户名`，给新创建的用户指定home目录

-m 　创建用户的主目录



==删除用户==

```
userdel 用户名
```

如果加上 -r 则把它的home目录下也删掉



==修改密码==

```
passwd 用户名
```



==用户信息==

```
id 用户名

#当前用户
whoami
```



==创建用户并用来登录==

```
1. useradd -m 用户名
2. passwd 用户名
3. 输入两遍密码
4. usermod -a -G sudo 用户名
5. chsh -s /usr/bin/bash 用户名  （改变该用户的shell  cat /etc/shells查看当前所有shell）
```



## 用户组

类似于角色，系统可以对有共性的多个用户进行统一的管理

```
1.新增组
groupadd 组名

2.删除组
groupdel 组名

3.增加用户时直接加上组
useradd -g 用户组 用户名

4.修改用户的组
usermod -g 用户组 用户名

5.修改用户的home目录
usermod -d 目录名 用户名

6.列出所有组
cut -d: -f1 /etc/group
```

用户和组相关文件

- /etc/passwd  用户的配置文件，记录用户的各种信息

  用户名:口令:用户标识号:组标识号:注释性描述:主目录:登录shell

- /etc/shadow  口令的配置文件

  登录名:加密口令:最后一次修改时间:最小时间间隔:最大时间间隔:警告时间:不活动时间:失效时间:标志

- /etc/group   组的配置文件

  组名:口令:组标识号:组内用户列表



# 运行级别

基本运行级别：

0：关机

1：单用户【找回丢失密码】

2∶多用户状态没有网络服务

3∶多用户状态有网络服务

4∶系统未使用保留给用户

5∶图形界面

6∶系统重启

常用运行级别是3和5 ，也可以指定默认运行级别

通过`init 数字`切换级别

![image-20230727221603811](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307272216154.webp)





# 组和权限

linux中的每个用户必须属于一个组，不能独立于组外

linux有所有者、所在组、其他组的概念，用户所在的组是可以改变的



- 文件/目录 所有者

  一般为文件的创建者

  - 查看文件的所有者 `ls -ahl`
  - 修改文件所有者  `chown 用户名 文件名`

- 所在组

  - 修改文件所在的组 `chgrp 组名 文件名`
  - 修改用户所在的组 `usermod -g 用户组 用户名`

- 其他组

  除文件的所有者和所在组的用户外，系统的其他用户都是文件的其他组

  - 修改用户所在的组   `usermod -g 用户组 用户名`
  - 修改用户的home目录 `usermod -d 目录名 用户名`

> 当一个用户创建一个文件时，该文件的所有权和所属组将与创建者的用户ID和组ID相关联。如果在创建文件a时，用户test属于用户组A，那么文件a将被分配给用户组A作为其所属组。但是，当用户test被移动到另一个用户组B时，文件a的所属组不会自动更改。文件a仍然保持原来的所属组A



# 文件描述符

标准输入（stdin）、标准输出（stdout）和标准错误（stderr）在Linux中分别被分配了文件描述符0、1和2





# 定时任务 crontab at

crontab 进行定时任务的设置

## 概述

任务调度：是指操作系统在某个时间执行的特定的命令或程序

任务调度分类：

1、系统工作：有些重要的工作必须周二不是的执行，如病毒扫描等

2、个别用户工作：用户希望执行的程序，比如数据库定时备份



## 语法

crontab

```
crontab [ -u user ] [ -i ] { -e | -l | -r }

-e 编辑crontab定时任务
-l 查询crontab任务
-r 删除当前用户所有的crontab任务

service crond restart [重启任务调度]
```

at

```
at [选项] [时间]
Ctrl + D 结束at命令
```



## 使用

### crond

设置任务调度文件：/etc/crontab

设置个人任务调度：执行`crontab -e`命令

接着输入任务到调度文件

如`*/1****ls -l \etc\ > /tmp/to.txt`

意思是每分钟执行ls -l \etc\ > /tmp/to.txt命令

```
* 0,3,10,13 1 * * sudo apt-get update&&sudo apt-get upgrade >> /tmp/apt-upgrade.txt
```



==参数==

5个占位符

| 项目    | 含义                 | 范围                  |
| ------- | -------------------- | --------------------- |
| 第一个* | 一小时当中的第几分钟 | 0-59                  |
| 第二个* | 一天当中的第几小时   | 0-23                  |
| 第三个* | 一个月当中的第几天   | 1-31                  |
| 第四个* | 一年当中的第几月     | 1-12                  |
| 第五个* | 一周当中的星期几     | 0-7(0和7都代表星期日) |



特殊符号

| 特殊符号 | 含义                                                         |
| -------- | ------------------------------------------------------------ |
| *        | 代表任何时间，比如第一个 * 就代表一小时中每分钟都执行一次    |
| ,        | 代表不连续的时间，比如 0 8,12,16***， 代表在每天的8点0分，12点0分，16点0分都执行一次 |
| -        | 代表连续的时间范围，比如 0 5 * * 1-6, 代表周一到周六的5点.分执行命令 |
| */n      | 代表没隔多久执行一次，比如 */10 * * * * 代表每隔10分钟执行一次命令 |



![image-20230724115330903](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307241153548.webp)



### at

1. at命令是一次性==定时计划任务==，at的守护进程atd会以后台模式运行，检查作业队列来运行。
2. 默认情况下，atd守护进程每60秒检查作业队列，有作业时，会检查作业运行时间，如果时间与当前时间匹配，则运行此作业。 n.
3. at命令是==一次性定时计划任务==，执行完一个任务后不再执行此任务了
4. 在使用at命令的时候，一定要保证atd进程的启动，可以使用相关指令来查看



#### 命令格式

```
at [选项] [时间]
ctrl + d结束at命令的输入

可以使用 ps -ef | grep atd查看at命令是否运行
```

#### 命令选项

<img src="https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307271148564.webp" alt="image-20230727114843148" style="zoom:67%;" />



#### 时间表达式

前面提到过，`at` 命令使用的是我们日常生活中所使用的时间格式，非常方便：

- YYMMDDhhmm[.ss]
  （缩写年、月、日、小时、分钟[秒]）
- CCYYMMDDhhmm[.ss]
  （完整年、月、日、小时、分钟和[秒]）
- now
- midnight
- noon
- teatime`（下午4点）
- AM
- PM

时间和日期可以是绝对的，也可以添加一个加号 ( *+* ) 使它们相对于*现在*。在指定相对时间时，下面这些日常生活中所使用的词汇都可以使用：

- minutes
- hours
- days
- weeks
- months
- years

下面是一些 `at` 命令有效表达式的示例：

```shell
$ echo "rsync -av /home/tux me@myserver:/home/tux/" | at 3:30 AM tomorrow
$ echo "/opt/batch.sh ~/Pictures" | at 3:30 AM 08/01/2022
$ echo "echo hello" | at now + 3 days
```



#### 查询和删除

随时时间的推移，我们可以忘记在 `at` 命令队列时设置了多少个任务，如果你想进行查看，可以使用 `atq` 命令：

```yaml
$ atq
10 Thu Jul 29 12:19:00 2021 a tux
9  Tue Jul 27 03:30:00 2021 a tux
7  Tue Jul 27 00:00:00 2021 a tux
```

要从队列中删除任务，请使用 `atrm` 命令和任务编号。例如要删除任务 7 ：

```ruby
$ atrm 7
$ atq
10 Thu Jul 29 12:19:00 2021 a tux
9  Tue Jul 27 03:30:00 2021 a tux
```

如果想要查看计划任务中的具体内容，就必须查看 `at spool` 。只有 root 用户才能查看`at` spool，因此你必须使用 `sudo` 来查看 `spool` 或 `cat` 任务的内容。





# 磁盘

## 磁盘分区

对linux来说无论有几个分区，分给哪一个目录使用，它都只有一个根目录，一个独立且唯一的文件结构，linux中每个分区都用来组成文件系统的一部分。

linux采用了一种叫==“载入”==的处理方法，它的整个文件系统中包含了一整套文件和目录，并且将一个分区和一个目录联系起来，这时要载入的一个分区将使它的存储空间在一个目录下获得。



查看挂载情况：

```
lsblk
```



磁盘说明

- linux硬盘分IDE硬盘和SCSI硬盘，目前基本上是SCSI硬盘
  - 对于IDE硬盘，驱动器标识符为 `hdx~`，其中“hd"表明分区所在设备的类型，这里是指IDE硬盘，”x“为盘号（a为基本盘，b为基本从属盘，c为辅助主盘，d为辅助从属盘），”~“代表分区，前四个分区用数字1-4表示，他们是主分区或扩展分区，从5开始就是逻辑分区。如 hda3 表示第一个IDE硬盘上的第三个主分区或扩展分区。
  - 对于SCSI硬盘则标识为`sdx~`，SCSI硬盘用“sd”表示分区所在设备的类型，其余则和IDE硬盘的表示方法一样。





# 网络配置

## ip配置

- 自动获取，缺点是每次登录获得的ip可能不一样，那就不能作服务器

- 手动配置

  - 直接修改配置文件，`vi /etc/sysconfig/network-scripts/ifcfg-ens33`

    要求：将ip地址配置成静态的

  - `ifcfg-ens33`文件说明

    DEVICE=eth0  接口名（设备、网卡）

    HWADDR=00:0C:2x:6x:0x:xx  mac地址

    TYPE=Ethernet    网络类型，通常是Ethernet

    UUID=XXXXXXXXX   随机id

    ONBOOT=yes    系统启动的时候网络接口是否有效

    BOOTPROTO=static    [none|static|bootp|dhcp]\(引导时不使用协议|静态分配ip|bootp协议|dhcp协议)

    IPADDR=        ip地址

    GATEWAY=       网关

    DNS1=          域名解析服务器ip



----



kali网络配置

```
ifconfig命令用于显示当前主机中状态为“激活”的网络接口信息。
ifconfig -a命令用于显示当前主机中所有网络接口信息（包括未激活的网络接口）

route命令用于显示当前Linux系统中的路由信息，从route命令的显示结果可以看到当前主机所在的子网和默认网关的地址

网卡的启用和停用：
ifconfig up
ifconfig down

"/etc/network/"目录下的”interfaces"文件是kali linux中最重要的网络配置文件之一，该文件用于描述主机中所有的网络接口的信息，不论Linux主机中作为DHCP客户端还是配置使用静态IP地址，都需要对该文件进行修改。
auto lo
iface lo inet loopback
auto eth0
iface eth0 inet static //配置eth0使用默认的静态地址
address 192.168.77.133 //设置eth0的IP地址
netmask 255.255.255.0 //配置eth0的子网掩码
gateway 192.168.77.254 //配置当前主机的默认网关

Kali Linux的DNS服务器地址使用文件“/etc/resovl.conf”进行配置，用户可以通过“nameserver”配置项设置DNS服务器的 IP地址；“resolv.conf”文件中最多可以使用
的DNS服务器IP地址进行域名的解析。
在resolv.conf中的格式如下：
domain
nameserver 10.10.10.10
nameserver 102.54.16.2
```



## 主机名和host映射

windows配置`C:\Windows\System32\drivers\etc\hosts`

kali 配置`/etc/hosts`



windows查看系统DNS记录和清理缓存

`ipconfig /displaydns`

`ipconfig /flushdns`





# 进程 ps kill lsof

linux中每个进程都会分配一个pid号

## ps命令

ps是用来查看当前系统中有哪些进程正在执行以及执行状况，可以不加参数

```
ps -a  显示所有终端下执行的进程，包含其他用户的进程
ps -A  显示所有进程
ps -e  和-A功能一样
ps -H  显示树状结构，表示程序间的相互关系
ps -f  全格式显示进程
ps -L  根据进程查看线程

ps a   显示当前终端下执行的进程
ps c   显示进程的真实名称
ps e   列出程序所使用的环境变量
ps f   用ASCII字符显示树状结构，表达程序间的相互关系
ps x   显示所有进程，无论是否运行在终端上
ps u   显示用户相关的进程或者与用户相关的属性
ps r   只显示正在运行的进程
```



```
USER，用户名称；
PID，进程号；
PPID 父进程
%CPU，该进程所占用CPU百分比；
%MEM，该进程所占用内存百分比；
VSZ，进程所占用的虚拟内存大小；
RSS，进程所占用的实际内存大小；
TTY，该进程运行在哪个终端上面，若与终端无关，则显示 ?；
STAT，进程状态；
START，进程启动时间；
TIME，进程实际占用CPU的时间；
COMMAND，该进程对应的执行程序；
```



运行状态 stat

| 状态 | 定义                                              |
| ---- | ------------------------------------------------- |
| R    | Running.运行中                                    |
| S    | Interruptible Sleep.等待调用                      |
| D    | Uninterruptible Sleep.等待磁盘IO                  |
| T    | Stoped.暂停或者跟踪状态                           |
| X    | Dead.即将被撤销                                   |
| Z    | Zombie.进程已经结束，仅映像名留存，所谓的僵尸进程 |
| W    | Paging.内存交换                                   |
| N    | 优先级低的进程                                    |
| <    | 优先级高的进程                                    |
| s    | 进程的领导者                                      |
| L    | 锁定状态                                          |
| l    | 多线程状态                                        |
| +    | 前台进程                                          |



## kill&killall

`kill [选项] 进程号` 通过进程号杀进程

`killall 进程名称`  通过进程名称杀死进程，支持通配符



常用选项

`-9` 强迫进程立即停止



### 查询

通过端口号查询pid

`lsof -i:端口号`

根据pid查进程名

`ps -p PID -o comm=`

根据进程名查pid

`ps -C 进程名 -o pid=`

## pstree

```
pstree [选项]    可以更直观的查看进程信息
-p    显示进程的pid
-u    显示进程的所属用户
```





# 服务 service systemctl chkconfig firewall

服务(service)本质就是进程，是运行在后台的，通常会监听某个端口，等待其他程序的请求，比如mysql,ssh,防火墙等，因此我们又称为守护进程。



## service

`service 服务名 [start|stop|restart|reload|status]`

在centOS7后，很多服务器不再用service而是`systemctl`

service指令管理的服务在`/etc/init.d`查看



## chkconfig

该命令可以给服务的==各个运行级别==设置自 启动、关闭

chkconfig 指令管理的服务在`/etc/init.d`查看

在centOS7后，很多服务器不再用chkconfig而是`systemctl`



基本语法

```
chkconfig --list[|grep xxx] 查看服务
chkconfig 服务名 config
chkconfig --level 5 服务名 on/off
```



## systemctl

systemctl管理指令

1.基本语法:systemctl [start | stop | restart | status]服务名

2.systemctl指令管理的服务在/usr/lib/systemd/system查看



systemctl设置服务的自启动状态

```
1. systemctl list-unit-files [l grep服务名](查看服务开机启动状念, grep 可以进行过滤)
2.systemctl enable 服务名(设置服务开机启动)
3. systemctl disable 服务名(关闭服务开机启动)
4.systemctl is-enabled服务名(查询某个服务是否是自启动的)
```





## firewall

- 打开或者关闭指定端口
  在真正的生产环境，往往需要将防火墙打开，但问题来了，如果我们把防火墙打开，那么外部请求数据包就不能跟服务器监听端口通讯。这时，需要打开指定的端口。比如80、22、8080等

  

- firewall指令

  - 打开端口: `firewall-cmd --permanent --add-port=端口号/协议`
  - 关闭端口:`firewall-cmd --permanent --remove-port=端口号/协议`
  - 重新载入,才能生效: `firewall-cmd --reload`
  - 查询端口是否开放:`firewall-cmd --query-port=端口/协议`



# 动态监控 top netstat

## 进程

top和ps指令类似，不同在于top在执行以后可以更新正在运行的进程,类似于win的任务管理器

```
top [选项]
-d 秒数  每隔几秒更新，默认为3
-i      不显示任何闲置或者将死的进程
-p pid  通过监控某一进程

交互操作
p       以cpu的使用率排序
M       以内存使用率排序
N       以PID排序
q       退出top
u或U：用于筛选显示特定用户的进程。
k或kill：向top当前选中的进程发送信号，可以用于终止或暂停某个进程。
```



## 网络

netstat

```
-a  所有连接
-t -u  TCP/UDP
-n  只用ip
-l  显示监听
-p  pid
-s  统计
```



# 软件包 rpm yum

## rpm

rpm用于互联网下载包的打包及安装工具，它包含在某些Linux分发版中。它生成具有.RPM扩展名的文件。RPM是RedHat Package Manager (`RedHat`软件包管理工具）的缩写，类似windows的setup.exe，这一文件格式名称虽然打上了RedHat的标志，但理念是通用的。

Linux的分发版本都有采用(suse,redhat, centos等等），可以算是公认的行业标准了。



rpm包的简单查询指令

查询已安装的rpm列表 rpm -qa|grep xx

rpm包名基本格式

```
一个rpm包名:firefox-60.2.2-1.el7.centos.x86_64
名称:firefox
版本号:60.2.2-1
适用操作系统: el7.centos.x86_64
表示centos7.x的64位系统
如果是i686、i386表示32位系统，noarch表示通用。
```

![image-20230728135303700](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307281353011.webp)





## yum

介绍:

Yum是一个Shell前端软件包管理器。基行于RPM包管理，能够从指定的服务器自动下载RPM包并且安装，可以自动处理依赖性关系，并且一次安装所有依赖的软件包。

yum的基本指令
查询yum服务器是否有需要安装的软件

`yum listlgrep xx软件列表`

安装指定的yum包
`yum install xxx`





# 环境

安装jdk

![image-20230728135647856](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307281356147.webp)









