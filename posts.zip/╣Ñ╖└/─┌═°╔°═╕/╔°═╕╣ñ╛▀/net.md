---
title: net
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 46
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 工具
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

> NET命令是一个命令行命令，Net 命令有很多函数用于实用和核查计算机之间的NetBIOS连接，可以查看我们的管理网络环境、服务、用户、登陆等信息内容；要想获得Net 的HELP可以(1)在Windows下可以用图形的方式，开始->帮助->索引->输入NET；(2)在COMMAND下可以用字符方式：NET /?或NET或NET HELP取得相应的方法的帮助。所有Net命令接受选项/yes和/no(可缩写为/y和/n)。

基础语法：

```javascript
NET [ ACCOUNTS | COMPUTER | CONFIG | CONTINUE | FILE | GROUP | HELP | HELPMSG | LOCALGROUP | PAUSE | SESSION | SHARE | START | STATISTICS | STOP | TIME | USE | USER | VIEW ]
#Dos下获取帮助：
net /? | net command /? | net help
```

| NET View    | NET User     | NET Use    | NET Time       | Net Start      |
| ----------- | ------------ | ---------- | -------------- | -------------- |
| Net Pause   | Net Continue | NET Stop   | Net Statistics | Net Share      |
| Net Session | Net Send     | Net Print  | Net Name       | Net Localgroup |
| Net Group   | Net File     | Net Config | Net Computer   | Net Accounts   |



# user

作用：添加或更改用户帐号或显示用户帐号信息。

```javascript
命令格式：Net user [username [password | *] [options]] [/domain]
```

有关参数说明：

  - 键入不带参数的Net user查看计算机上的用户帐号列表
  - username添加、删除、更改或查看用户帐号名
  - password为用户帐号分配或更改密码
  - 提示输入密码
  - `/domain`在计算机主域的主域控制器中执行操作。该参数仅在 Windows NT Server 域成员的 Windows NT Workstation 计算机上可用。默认情况下，Windows NT Server 计算机在主域控制器中执行操作。注意：在计算机主域的主域控制器发生该动作。它可能不是登录域。
    例如：`Net user ghq123`查看用户GHQ123的信息。

# USE

　作用：连接计算机或断开计算机与共享资源的连接，或显示计算机的连接信息。

```javascript
命令格式：Net use [devicename | *] [\\computername\sharename[\volume]] [password|*]][/user:[domainname\]username][[/delete]| [/persistent:{yes | no}]]
```

有关参数说明：
　　- 键入不带参数的Net use列出网络连接
　　- devicename指定要连接到的资源名称或要断开的设备名称
　　- `\\computername\sharename`服务器及共享资源的名称
　　- password访问共享资源的密码
　　- *提示键入密码
　　- `/user`指定进行连接的另外一个用户
　　- `domainname`指定另一个域
　　- `username`指定登录的用户名
　　- `/home`将用户连接到其宿主目录
　　- `/delete`取消指定网络连接
　　- `/persistent`控制永久网络连接的使用。
　　例如：`Net use f: \\GHQ\TEMP` 将\GHQ\TEMP目录建立为F盘
　　　　　　　　　　　`Net use f: \GHQ\TEMP` /delete 断开连接。

```javascript
net use \\ip\ipc$ " " /user:" "         建立IPC空链接
net use \\ip\ipc$ "密码" /user:"用户名"  建立IPC非空链接

net use h: \\ip\c$ "密码" /user:"用户名" 直接登陆后映射对方C：到本地为H:
net use h: \\ip\c$                      登陆后映射对方C：到本地为H:

net use \\ip\ipc$ /del                  删除IPC链接
net use h: /del                         删除映射对方到本地的为H:的映射
```



# localgroup

作 用：添加、显示或更改本地组。”本地组”则只能在本地计算机上使用

```javascript
命令格式：Net localgroup groupname {/add [/comment:"text "] | /delete} [/domain]

net localgroup Users              #查看Users组里的组员
net localgroup Admin  [ /add | /delete ]                 #添加或者删除一个组
net localgroup administrators 用户名 [ /add | /delete ]    #添加用户到管理员组
net localgroup test /comment:"test comment"     #添加注释
```



# view

示域列表、计算机列表或指定计算机的共享资源列表。

```javascript
net view \\ip #查看对方局域网内开启了哪些共享资源
Net view [\\computername | /domain[:domainname]]
```

有关参数说明：
　　- 键入不带参数的`net view`显示当前域的计算机列表
　　- `\\computername` 指定要查看其共享资源的计算机
　　- `/domain[:domainname]`指定要查看其可用计算机的域
　　例如：`Net view \\GHQ`查看GHQ计算机的共享资源列表。
　　　　　　　　　　　`Net view /domain:XYZ`查看XYZ域中的机器列表。

# share

作用：创建、删除或显示共享资源。

```javascript
命令格式：Net share sharename=drive:path [/users:number | /unlimited] [/remark:"text"]
                                                                  
net share  #查看本地开启的共享
#添加共享
net share sharename=drive:path [/users:number | /unlimited ] [ /remark:"test" ] /GRANT:用户,权限
         #c$=c:\users(必须绝对路径) 用于设置同时访问用户数 | 最大的访问数 [用于添加资源的备注] 
net share test=c:\test /GRANT:Administrator,full   #带有权限  full = read | change(修改)      

net share ipc$   #开启ipc$共享
net share ipc$ /del #删除ipc$共享
net share c$ /del #删除C：共享
```

　有关参数说明：
输入不带参数的Net share显示本地计算机上所有共享资源的信息
　　 `sharename`是共享资源的网络名称
　　 `drive:path`指定共享目录的绝对路径
　　 `/users:number`设置可同时访问共享资源的最大用户数
　　 `/unlimited`不限制同时访问共享资源的用户数
　　 `/remark:"text "`添加关于资源的注释，注释文字用引号引住
　　例如： `Net share yesky=c:\temp /remark:"my first share"`
　　以yesky为共享名共享C:\temp
　　`Net share yesky /delete`停止共享yesky目录

常见共享服务:

- IPC$： 适用于远程管理计算机和查看共享资源，在网上最好不要用 ；
- Admin$： 实际上就是 c:\winnt也没有必要共享 ；
- CUndefined control sequence \计”的方式访问C盘，虽然仅限于局域网，但是远程黑客也有办法伪装成局域网的登录用户，所以都应该关掉；
- Print$：这是放打印机驱动程序的目录，与上面的一样也是个很危险的入口；
- Netlogon： 这是处理域登录请求的共享。如果你的机器为主域控制器，域内有其他机器要登录进来，就不要删除它，否则照样可以删除。



# file

功能：显示某服务器上所有打开的共享文件名及锁定文件数。该命令也可以关闭个别文件并取消文件锁定

```javascript
net file [id [/close]]
#Parameters:
-输入不带参数的 net file 可获得服务器上打开文件的列表。
-id 文件标识号
/close 关闭打开的文件并释放锁定记录,请从共享文件的服务器中键入该命令。
```



# 服务操作

描述:利用`net start | stop | pause`命令进行开启/停止/暂停服务

```javascript
#开启服务 
net start telnet 
net start schedule

# 停止某服务
net stop SCardSvr # rem 关闭智能卡服务
net stop  policyagent    #停止IPSEC策略
net stop  sharedaccess   #Intemet连接共享和防火墙服务

# 暂停某服务
net pause 服务名
```

continue

描述:net continue 重新激活挂起的服务

```javascript
net continue service
#参数 service 能够继续运行的服务，包括：
file server for macintosh(该服务仅限于 Windows NT Server)，ftp publishing service,lpdsvc,net logon,network dde，network dde dsdm，ntlm security support provider，remoteboot(该服务仅限于 Windows NT Server)，
remote access server,schedule，server，simple tcp/ip services 及 workstation
```



# session

作用：列出或断开本地计算机和与之连接的客户端的会话。

```javascript
命令格式：Net session [\\computername] [/delete]
                                   
net sessions | net sess
net sessions [\computername] [/DELETE]

#要显示计算机名为 Shepherd 的客户端会话信息:
net session \shepherd

#要结束服务器与连接到服务器的客户端的所有会话,当显示会话信息时，信息将以类似下面的格式显示:
net session /delete
```



# config

描述:net config 显示系统服务器和工作站设置,

- 服务器的计算机名、描述注释和软件版本
- 网络描述
- 服务器的隐藏设置
- 可以使用服务器的共享资源的最多用户数
- 可以打开的服务器文件的最大数量
- 空闲会话时间设置

```javascript
命令格式：Net config [service [options]]

net config server [/autodisconnect:time] [/srvcomment:"text "] [/hidden:{yes | no}]
#设置在断开连接前用户会话可以不活动的最大分钟数
net config server /autodisconnect:10     # 命令设置 autodisconnect 功能 10分钟
#显示服务服务器和工作站配置
net config server
net config workstation
```



# statistics

　作用：显示本地工作站或服务器服务的统计记录。

```javascript
命令格式：Net statistics [workstation | server]

net statistics
-server ：用于显示本地服务器服务的统计信息
-Workstation ：用于显示本地工作站服务的统计信息

#工作站数据
net statistics Workstation
```

有关参数说明：
　　·键入不带参数的Net statistics列出其统计信息可用的运行服务
　　·`workstation`显示本地工作站服务的统计信息
　　·`server`显示本地服务器服务的统计信息
　　例如：Net statistics server | more显示服务器服务的统计信息。

# time

　作用：使计算机的时钟与另一台计算机或域的时间同步。

```javascript
命令格式：Net time [\\computername | /domain[:name]] [/set]
                 
net time \\目标ip 查看对方时间
net time 目标ip /set 设置本地计算机时间与“目标IP”主机的时间同步,加上参数/yes可取消确认信息
```

　有关参数说明：
　　- `\\computername`要检查或同步的服务器名
　　-`/domain[:name]`指定要与其时间同步的域
　　- `/set`使本计算机时钟与指定计算机或域的时钟同步。

# accounts

描述：更新用户帐户数据库并修改所有帐户的密码和登录请求、

```javascript
命令格式：Net accounts [/forcelogoff:{minutes | no}] [/minpwlen:length] [/maxpwage:{days | unlimited}] [/minpwage:days] [/uniquepw:number] [/domain]
```

有关参数说明：

- 输入不带参数的Net accounts显示当前密码设置、登录时限及域信息
- `/forcelogoff:{minutes | no}`设置当用户帐号或有效登录时间过期时
- `/minpwlen:length`设置用户帐号密码的最少字符数
- `/maxpwage:{days | unlimited}`设置用户帐号密码有效的最大天数
- `/minpwage:days`设置用户必须保持原密码的最小天数
- `/uniquepw:number`要求用户更改密码时，必须在经过number次后才能重复使用与之相同的密码
- `/domain`在当前域的主域控制器上执行该操作、
- `/sync`当用于主域控制器时，该命令使域中所有备份域控制器同步

实际案例:

```javascript
#显示当前用户设置的密码以及服务器角色信息
net accounts

#要设置不少于7个字符的用户账号密码
net accounts /minpwlen:7

#防止用户再7天内更改密码而且强制用户每30天才能更改一次密码，并在登录实际到期后用5分钟强制警告用户注销
net accounts /minpwage:7 /maxpwage:30 /forcelogoff:5
```



# computer

Windows Vista 中内置的命令行工具，以前都没有

作用：从域数据库中添加或删除计算机。

```javascript
net computer \\<ComputerName> {/add | /del}

# 下面的命令将 Grizzlybear 的计算机添加到域数据库中：
net computer \\grizzlybear /add

有关参数说明：
　　·\\computername指定要添加到域或从域中删除的计算机
　　·/add将指定计算机添加到域
　　·/del将指定计算机从域中删除
　　例如：Net computer \\js /add将计算机js 添加到登录域。
```



# group

描述:在 Windows NT Server 域中添加、显示或更改全局组.该命令仅在 Windows NT Server 域中可用。

Net group 建立的组就是“全局组”,”全局组”的意思是所建立的组可以在本域和有信任关系的其它域中使用

```javascript
命令格式：Net group groupname {/add [/comment:"text "] | /delete} [/domain]
                                                              
NET GROUP [groupname [/COMMENT:"text"]] [/DOMAIN] groupname {/ADD [/COMMENT:"text"] | /DELETE} [/DOMAIN]
NET GROUP groupname username [...] {/ADD | /DELETE} [/DOMAIN] 
#参数解释：
groupname:指需要添加、扩充或删除的组的名称。只要给出组名就可以浏览该组中的用户列表
username[ ...]:列出一个或多个需要从一个组中添加或删除的用户名。可以用空格来将多个用户名分隔开
/COMMENT:"text":为一个新的或已存在的组添加注释。注释最多可以是 48 个字符，文本应包含在引号中
/DOMAIN:在当前域的主域控制器上执行操作。否则在本地计算机上执行该操作
/ADD 添加一个组，或将一个用户名添加到一个组中
/DELETE 删除一个组，或将一个用户名从一个组中删除
```

基础实例:

```javascript
#要将组 Exec 添加到本地用户帐户数据库:
net group exec /add

#要将组Exec 添加到域数据库:
net group exec /add /domain

#要将备注添加到 exec 组记录:
net group exec /comment:"The executive staff."

#查询当前域管理员的组 下面是没有域得
net group "domain admins" /domain
```

*Net localgroup和Net group区别?* 例如:创建一个普通用户hanjiangit，`把该用户加入“Users（本地组）”中则只能在本地计算机上使用`, 如果把hanjiangit加入“Domain Users（全局组）”，则该用户就可以在全域中使用。



# print

描述：net print 显示有关指定的打印机队列或指定的打印作业的信息或控制指定的打印作业。 但是，您可以执行许多相同的任务使用 Prnjobs.vbs、 Windows 管理规范 (WMI) 或 Windows PowerShell 的 cmdlet。

基础语法:

```javascript
命令格式：Net print [\\computername ] job# [/hold | /release | /delete]

                 net print {\\<ComputerName>\<ShareName> | \\<ComputerName><JobNumber> [/hold | /release | /delete] [help]}
#参数
 <JobNumber>   指定您希望控制打印作业的数量
[/hold | /release | /delete]    指定要打印的作业执行的操作
/hold 可以延迟打印作业，允许其他打印作业将忽略它直到发布
/release  版本已延迟打印作业（进行释放）
/delete 删除/参数从打印队列中删除打印作业
```

如果您指定作业编号，但没有指定操作，将显示有关打印作业的信息。

```javascript
Net print \\Production\Dotmatrix    #显示打印作业
Net print \\Production 35            #进入作业编号详情
Net print \\Production 263 /hold    #延迟
Net print \\Production 263 /release  #释放延迟
```



# send

作用：向网络的其他用户、计算机或通信名发送消息。
```
命令格式：Net send {name | * | /domain[:name] | /users} message
```

　　有关参数说明:

- `name`要接收发送消息的用户名、计算机名或通信名

　　* *将消息发送到组中所有名称
　　`/domain[:name]`将消息发送到计算机域中的所有名称
　　　　　　`/users`将消息发送到与服务器连接的所有用户
　　　　　　`message`作为消息发送的文本
  * 例如：`Net send /users server will shutdown in 10 minutes`.给所有连接到服务器的用户发送消息。







































