---
title: wfuzz
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 47
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 工具
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

# 简介

在刷src时候我们经常会对一些的参数进行fuzz，WFuzz是用于Python的Web应用程序安全性模糊工具和库。它基于一个简单的概念：它将给定有效负载的值替换对FUZZ关键字的任何引用。是一款很好的辅助模糊测试工具。它允许在HTTP请求里注入任何输入的值，针对不同的WEB应用组件进行多种复杂的爆破攻击。比如：参数、认证、表单、目录/文件、头部等等。

wfuzz提供了简洁的编程语言接口来处理wfuzz或Burpsuite获取到的HTTP请求和响应。这使得你能够在一个良好的上下文环境中进行手工测试或半自动化的测试，而不需要依赖web形式的扫描器。

- 递归（目录发掘）
- Post数据爆破
- 头部爆破
- 输出HTML（详细报告，点击链接查看内容，POST数据也能阅览）
- 多彩输出
- 返回码、词数、行数等等来隐藏结果。
- URL编码
- Cookie
- 多线程
- 代理支持
- 多参数fuzz
  在平常的渗透测试中，用好Wfuzz对我们的帮助非常大。



简单使用

```
pip install wfuzz #安装wfuzz
wfuzz -w test_dict.txt https://gh0st.cn/FUZZ 	#这里大写的FUZZ相当于burp的参数
```

`ID、Response、 Lines、Word、Chars、Payload`这一行，从左往右看，依次是`编号、响应状态码、响应报文行数、响应报文字数、响应报文正字符数、测试使用的Payload`。

![image-20230806201102080](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202308062011577.webp)





# 参数

```
wfuzz -h # 获取帮助

--hc 	过滤状态码
--sc 	需要显示的状态码
-c 		带颜色显示
-w		指定使用字典
-z 		设置payload 【比如:字典】
-z 	file,1.txt（以文件形式，导入1.txt）
-z 	range,1-10（以范围形式，1到10）
-z 	list,1-2-3-10（列表形式，1,2,3,10）
-t 		设置线程 默认10
-s 		请求间隔时间
-d 		设定POST量
-d 	“uname=admin&passwd=admin”
-b 		设定cookie量
-b 	“cookie=”
-H 		参数来指定HTTP请求的请求头，多次指定多次使用。
-H 	“User-Agent: firfox”
-f 		输出到文件的格式，格式有raw,json,csv,magictree,html
-f 	/tmp/1,html （将结果输出到tmp目录下的1，以html格式）
-X 		设定请求方法
-X 	GET
-R 		递归深度，探测目录很好
递归深度为1也就是说当发现某一个目录存在的时候，在存在目录下再递归一次字典。
-R 	1（深度为1）
```

**显示或隐藏信息**
使用 --hc --hl --hw --hh 可以隐藏相应结果

```
--hc 503	隐藏响应码为503的
--hl 20		隐藏响应信息行数为20行的
--hw 30		隐藏响应信息中字数为30的
--hh 50		隐藏响应信息中字符数为50的

使用 --sc --sl --sw --sh 可以特别显示相应结果
--sc 405：显示响应码405
```



# wfuzz常见用法

```
# 查找公共目录
wfuzz -w wordlist/general/common.txt http://testphp.vulnweb.com/FUZZ

# 查找文件
wfuzz -w wordlist/general/common.txt http://testphp.vulnweb.com/FUZZ.php

# 数据模糊测试
wfuzz -z range,0-10 --hl 97 http://testphp.vulnweb.com/listproducts.php?cat=FUZZ

# 模糊 POST 请求
wfuzz -z file,wordlist/others/common_pass.txt -d "uname=FUZZ&pass=FUZZ"  --hc 302 http://testphp.vulnweb.com/userinfo.php

# 对各种 COOKIE 重复
wfuzz -z file,wordlist/general/common.txt -b cookie=value1 -b cookie2=value2 http://testphp.vulnweb.com/FUZZ

# 模糊 COOKIE
wfuzz -z file,wordlist/general/common.txt -b cookie=FUZZ http://testphp.vulnweb.com/

# 重复 HTTP头
wfuzz -z file,wordlist/general/common.txt -H "myheader: headervalue" -H "myheader2: headervalue2" http://testphp.vulnweb.com/FUZZ

# 使用不同请求方法
wfuzz -z list,GET-HEAD-POST-TRACE-OPTIONS -X FUZZ http://testphp.vulnweb.com/

# 使用代理
wfuzz -z file,wordlist/general/common.txt -p localhost:2222:SOCKS5 -p localhost:9090 http://testphp.vulnweb.com/FUZZ

# 身份验证
wfuzz -z list,nonvalid-httpwatch --basic FUZZ:FUZZ https://www.httpwatch.com/httpgallery/authentication/authenticatedimage/default.aspx

# 将结果写入 JSON 文件
wfuzz -f /tmp/outfile,json -w wordlist/general/common.txt http://testphp.vulnweb.com/FUZZ

# 以 JSON 格式输出
wfuzz -o json -w wordlist/general/common.txt http://testphp.vulnweb.com/FUZZ
```



------

#### 模糊查询GET请求参数

```none
wfuzz -u "http://192.168.1.104/test.php?FUZZ=/etc/passwd" -w /usr/share/wfuzz/wordlist/general/common.txt --hh 80
```

![img](https://img2023.cnblogs.com/blog/2328330/202212/2328330-20221226142848547-223230452.png)

#### 模糊查询POST请求参数

```none
wfuzz -w /usr/share/wfuzz/wordlist/general/common.txt -d "uname=FUZZ&pass=FUZZ"  --hc 302 http://192.168.1.102/user.php
wfuzz -w /usr/share/wfuzz/wordlist/general/common.txt -d "payload=FUZZ"  --hc 302 http://172.35.20.71/vul/test/post
```

#### 添加cookie发起请求

```none
wfuzz -w /usr/share/wfuzz/wordlist/general/common.txt -b cookie=value1 -b cookie2=value2 http://192.168.1.102/FUZZ
```

#### 添加请求头

```none
wfuzz -w /usr/share/wfuzz/wordlist/general/common.txt -H "Referer: 127.0.0.1" http://192.168.1.102/FUZZ
```

#### 子域名扫描

```none
wfuzz -w /usr/share/amass/wordlists/subdomains-top1mil-5000.txt -u cc123.com -H "Host:FUZZ.cc123.com" --hw 53
```

![img](https://img2023.cnblogs.com/blog/2328330/202212/2328330-20221226143021514-991814098.png)

#### 爆破401认证界面

```none
wfuzz -c -w /usr/share/wordlists/rockyou.txt --basic mum:FUZZ -u http://192.168.1.106:631/admin/ -b "org.cups.sid=f607a41978fbca423d4de60f686fe8f5" -d "org.cups.sid=f607a41978fbca423d4de60f686fe8f5&OP=add-printer" -Z --hc 401
```

![img](https://img2023.cnblogs.com/blog/2328330/202212/2328330-20221226143331996-581483830.png)



#### 多个载荷

```
# 指定多个有效负载  FUZnZ : n 是指有效负载编号
wfuzz -w wordlist/general/common.txt -w wordlist/general/common.txt -w wordlist/general/extensions_common.txt --hc 404 http://testphp.vulnweb.com/FUZZ/FUZ2ZFUZ3Z
```



#### 遍历枚举

```
wfuzz -z range,000-999 --hl 20 http://127.0.0.1/getuser.php?uid=FUZZ
```

















