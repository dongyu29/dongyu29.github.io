---
title: php phar反序列化
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 28
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 代码审计
  -  php安全
categories:
  - 代码审计
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter

---

<!--more-->

# 文件结构

phar文件是php里类似于JAR的一种打包文件本质上是一种压缩文件，在PHP 5.3 或更高版本中默认开启，一个phar文件一个分为四部分

```sql
1.a stub
可以理解为一个标志，格式为xxx<?php xxx; __HALT_COMPILER();?>，前面内容不限，但必须以__HALT_COMPILER();来结尾，否则phar扩展将无法识别这个文件为phar文件
2.a manifest describing the contents
phar文件本质上是一种压缩文件，其中每个被压缩文件的权限、属性等信息都放在这部分。这部分还会以序列化的形式存储用户自定义的meta-data，这是上述攻击手法最核心的地方
3.the file contents
被压缩文件的内容
4.[optional] a signature for verifying Phar integrity (phar file format only)
签名，放在文件末尾
```



# 生成phar

需要提前配置php.ini

<img src="https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/image-20230403163145658.webp" alt="image-20230403163145658" style="zoom:67%;" />

```php
<?php
    class TestObject {
    }

    @unlink("phar.phar");
    $phar = new Phar("phar.phar"); //后缀名必须为phar
    $phar->startBuffering();
    $phar->setStub("<?php __HALT_COMPILER(); ?>"); //设置stub
    $o = new TestObject();
    $phar->setMetadata($o); //将自定义的meta-data存入manifest 核心
    $phar->addFromString("test.txt", "test"); //添加要压缩的文件
    //签名自动计算
    $phar->stopBuffering();
?>
```



# 利用

## 触发phar的函数

```php
fopen()
unlink()
stat()
fstat()
rename()
opendir()
rmdir()
mkdir()

以及，基于文件操作的其他函数
file_put_contents()
file_get_contents()
file_exists()
fileinode()
include()
require()
include_once()
require_once()
filemtime()
fileowner()
fielperms()

甚至看起来不行其实可以的函数，比如
filesize()
is_dir()
scandir()

更离谱的是这样也可以触发反序列化
  class hack{
  public function __destruct(){
     echo "hack class destruct";
   }
}
new DirectoryIterator("phar://flag.phar");

甚至
class hack{
  public function __destruct(){
       echo "hack class destruct";
     }
}
highlight_file("phar://flag.phar");
```





## 用法

- 上传phar文件的时候可以把后缀改成gif之类
- 调用我们上传的phar文件的功能点文件前面加上phar://







