---
title: php审计练习 熊海cms_v1.0
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 19
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 代码审计
  -  php安全
categories:
  - 代码审计
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter



---

<!--more-->

# 

# 安装系统

访问/install/路径进行安装

本次配置如下，注意php版本不能太高，不然系统是装不上的，这里用的php5.3

![image-20230602002030549](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306020020750.webp)



# 项目目录









# 文件包含

/index.php有一个很明显的文件包含，并且可以进行目录穿越

![image-20230602005740326](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306020057484.webp)



此外/admin/index.php也有一个一样的文件包含



# SQL注入

## 登录

后台登陆地址没有进行过滤，但是进行了两次if判断，不过漏洞点在于用户名的if判断进行了sql报错，可以报错注入

登录逻辑大概就是走index.php然后跳到login.php,进行用户名和密码的两个if验证，成功的话就设置一个cookie，然后再回到index进行中转，之后在进入后台页面之前先进行checklogin的判断，判断的规则是根据cookie，这里的判断也是存在漏洞的，判定存在cookie就放行进入后台页面

```php
if ($login<>""){
$query = "SELECT * FROM manage WHERE user='$user'";
$result = mysql_query($query) or die('SQL语句有误：'.mysql_error());
$users = mysql_fetch_array($result);

if (!mysql_num_rows($result)) {  
echo "<Script language=JavaScript>alert('抱歉，用户名或者密码错误。');history.back();</Script>";
exit;
}else{
$passwords=$users['password'];
if(md5($password)<>$passwords){
echo "<Script language=JavaScript>alert('抱歉，用户名或者密码错误。');history.back();</Script>";
exit;	
	}
```

![image-20230602114348894](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306021143003.webp)



## 链接

这个cms真的是漏洞百出

?r=editcolumn&type=2&id=1%27%20and%20updatexml(1,concat(0x7e,(select%20database()),0x7e),1)--+

![image-20230602114822716](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306021148934.webp)

![image-20230602114604946](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306021146060.webp)





# XSS

## /files/contact.php

漏洞位置：files/contact.php 第12~15行

```
$page=addslashes($_GET['page']);
if ($page<>""){
if ($page<>1){
$pages="第".$page."页 - ";
```

这里的$page经过addslashes处理一次带入了页面



























